      <footer class="main-footer">
        <strong>Copyright &copy; 2019 | All rights reserved.
      </footer>
