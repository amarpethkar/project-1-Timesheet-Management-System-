<!DOCTYPE html>
<html>
  <head>
    <title>Quantsoft</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/input_style.css">
    <link rel="stylesheet" href="css/font-awesome.css">
  </head>

  <body>
    <div class="login_main_div">
      <h2 class="login_our_logo">New Password</h2>
      <div class="col-md-4 col-md-offset-4">
        <form action="" method="post">
          <div class="communication_input card">
            <div class="form-group input-container">
              <input type="password" id="" required="required">
              <label for="To">New Password</label>
              <div class="bar"></div>
            </div>
            <div class="form-group input-container">
              <input type="password" id="" required="required">
              <label for="To">Confirm Password</label>
              <div class="bar"></div>
            </div>
          </div>
          <input type="submit" value="Submit" class="form-control submit_button">
        </form>
        <div class="border_1px"></div>
        <p class="login_copy"><a href="http://www.quantsoft.co.in/Home" target="_blank">Quantsoft Engineering Solutions Pvt. Ltd.</a></p>
      </div>
    </div>
    <script src="js/jQuery-2.1.4.min.js"></script>
    <script src="js/bootstrap.js"></script>
  </body>
</html>
