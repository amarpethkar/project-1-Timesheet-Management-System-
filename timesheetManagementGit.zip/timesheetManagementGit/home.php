<?php 
include_once('auth.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Timesheet Management System</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/input_style.css">
    <link rel="stylesheet" href="css/maxcdn.css">
    <link rel="stylesheet" href="css/AdminLTE.min.css">
    <link rel="stylesheet" href="css/all-skins.min.css">
    <link rel="stylesheet" href="css/CustomScrollbar.css">
    <link rel="stylesheet" href="css/font-awesome.css">
  </head>
  <body>

<div class="wrapper">   
<?php include_once('header.php');?>
<?php include_once('sidenav.php');?>
<?php include_once('main_content.php');?>
<?php include_once('loader.php');?>
</div>

<?php include_once('footer.php');?>
  
	<script src="js/admin_val.js"></script>
    <script src="js/user_value.js"></script> 
	<script src="js/user_function.js"></script> 	   
    <script src="js/quantsoft_fun.js"></script>
	<script src="js/msg.js"></script>
	
	<script src="js/jQuery-2.1.4.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/app.min.js"></script>	  
    <script src="js/chart.js"></script>  
    <script src="js/CustomScrollbar.js"></script> 
	<script type="text/javascript">
	$(document).ready(function () {	
	  
	  get_emp_info_details();
	  get_project_info_details();
	  get_category_info();
	  get_sub_category_info();
	  get_leave_type_info();
	  getUserProfileInfo();
	  getAdminInfo();
	  getUserAppliedLeaveInfo();
	  getEmpLogActivity();
	  getDailyTimesheetInfo(todayDate);
	  empProjProductivity();
	  project_productivity();
	  //empProductivityByDate();
	  getEmpLeaveHistory();
	  startTimeLeaveNoti();
	  startTimeTimShetNoti();
	  startTimeTimShetNotiEmp();
	  startTimeLeaveNotiEmp() ;
	  getLeaveNotiCount(loginId);
	  getTimShetNotiCount();
	  getTimShetNotiEmpCount(); 
	  getLeaveNotiCountEmp();
	  getApprovalPenddingTimesheetInfo();
	  getEmpAttendanceByIdAjax();
	  
 
});	


var loginId = '<?php echo $id; ?>'; 
var userType = '<?php echo $user_type; ?>'; 

if(userType == "admin"){
	analytics();
 }if(userType == "employee"){
	timesheetEntry();
 }
    </script> 	

 <!-- Modal -->
  <div class="modal fade" id="actionAlertPopup" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header popup_header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body popup_body" id="msgBox">
          <!-- your msg here --> 
        </div>
      </div>
      
    </div>
  </div>	
<!-- -->
  </body>
</html>
