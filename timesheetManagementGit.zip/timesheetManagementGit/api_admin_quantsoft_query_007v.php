<?php 
	ob_start();
	include_once('auth.php');
	
	// allow cross browser request
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	

$quantsoftAdminMethod = $_REQUEST['METHOD'];


	$AdminVersion = $_REQUEST['VERSION'];
	$AdminToken = $_REQUEST['QUANTSOFTTOKEN'];

// Check Version & Token at server side
if($AdminVersion == 1.00 && $AdminToken == "adminquantsoft2015esya" && $id!='')


{

include_once('classes/query_class.php');
$qc = new queryClass();
/*.............................     ......................*/

/*  GET LEAVE NOTIFICATION ADMIN */
if($quantsoftAdminMethod == "GET_LEAVE_NOTIFICATION"){

		$approve_incharge  = $qc->clean($_REQUEST['approve_incharge']);
		
		$data=$qc->get_leave_notification($approve_incharge);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_LEAVE_NOTIFICATION&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=GET_LEAVE_NOTIFICATION&RESPONSE=";
		}
} //

/*  GET LEAVE NOTIFICATION ADMIN */
if($quantsoftAdminMethod == "GET_TIMESHEET_NOTIFICATION"){		
		
		$data=$qc->get_timesheet_notification($id);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_TIMESHEET_NOTIFICATION&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=GET_TIMESHEET_NOTIFICATION&RESPONSE=";
		}
} //

/*  GET TIMESHEET DISAPPROVE NOTIFICATION EMP  */
if($quantsoftAdminMethod == "GET_TIMESHEET_DISAPRV_NOTIFICATION_EMP"){		
		
		$data=$qc->get_timesheet_disAprv_notification_emp($id);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_TIMESHEET_DISAPRV_NOTIFICATION_EMP&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=GET_TIMESHEET_DISAPRV_NOTIFICATION_EMP&RESPONSE=";
		}
} //

/*  GET LEAVE NOTIFICATION EMP */
if($quantsoftAdminMethod == "GET_LEAVE_NOTIFICATION_EMP"){		
		
		$data=$qc->get_leave_notification_emp($id);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_LEAVE_NOTIFICATION_EMP&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=GET_LEAVE_NOTIFICATION_EMP&RESPONSE=";
		}
} //

/*  GET LEAVE NOTIFICATION EMP */
if($quantsoftAdminMethod == "EMP_NOTI_SEEN"){		
		
		$data=$qc->update_emp_seen_noti($id);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=EMP_NOTI_SEEN&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=EMP_NOTI_SEEN&RESPONSE=";
		}
} //

/*  ONLOG IN GET PROFILE INFO  */
if($quantsoftAdminMethod == "GET_USER_PROFILE"){		
		//echo $id;
		//echo $user_type;
		$data=$qc->get_user_profile($id,$user_type);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_USER_PROFILE&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=GET_USER_PROFILE&RESPONSE=";
		}
} //


/*  CHANGE PASSWORD  */
if($quantsoftAdminMethod == "CHANGE_PASSWORD"){		
		//echo $id;
		//echo $user_type;
		$old_password  = $qc->clean($_REQUEST['old_password']);
		$new_password  = $qc->clean($_REQUEST['new_password']);
		
		$data=$qc->change_password($id,$user_type,$old_password,$new_password);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=CHANGE_PASSWORD&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=CHANGE_PASSWORD&RESPONSE=";
		}
} //

/*  GET ADMIN PROFILE INFO  */
if($quantsoftAdminMethod == "GET_ADMIN_PROFILE"){		
	
		$data=$qc->get_admin_profile();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_ADMIN_PROFILE&RESPONSE=".$data;
	    }else{
			echo "RESULT=ERROR&REQUEST=GET_ADMIN_PROFILE&RESPONSE=";
		}
} //

/* DAILY TIMESHEET ENTRY */
/* 
Note: 
 flag = 0 -> time sheet submit
 flag = 1 -> time sheet approve 
 flag = 2 -> time sheet disapprove 
*/
// get emp log activity 
if($quantsoftAdminMethod == "GET_EMP_LOG_ACTIVITY_INFO"){		
		
		$data=$qc->get_emp_log_activity_info();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_LOG_ACTIVITY_INFO&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_LOG_ACTIVITY_INFO&RESPONSE=";
		}
} //

// get dail timesheet info 
if($quantsoftAdminMethod == "GET_DAILY_TIMESHEET_INFO"){		
		//echo $id;
		//echo $user_type;user_date
		$user_date  = $qc->clean($_REQUEST['user_date']);
		$data=$qc->get_daily_timesheet_info($user_date);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_DAILY_TIMESHEET_INFO&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_DAILY_TIMESHEET_INFO&RESPONSE=";
		}
} //
// Get approval pendding timesheets 
if($quantsoftAdminMethod == "GET_APPROVAL_PENDDING_TIMESHEETS"){		
		
		$data=$qc->get_approval_pendding_timesheet_info();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_APPROVAL_PENDDING_TIMESHEETS&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_APPROVAL_PENDDING_TIMESHEETS&RESPONSE=";
		}
} //

// 	Add daily timesheet by employee 
if($quantsoftAdminMethod == "ADD_EMPLOYEE_DAILY_TIMESHEET"){
	
	$timesheet_entry_date        = $qc->clean($_REQUEST['timesheet_entry_date']);
	$sr_no					     = $qc->clean($_REQUEST['sr_no']);
	$project_id				     = $qc->clean($_REQUEST['project_id']);
	$project_category_id	     = $qc->clean($_REQUEST['project_category_id']);
	$project_sub_category_id     = $qc->clean($_REQUEST['project_sub_category_id']);
	$drawing_no				     = $qc->clean($_REQUEST['drawing_no']);
	$model_no				     = $qc->clean($_REQUEST['model_no']);
	$timesheet_hrs			     = $qc->clean($_REQUEST['timesheet_hrs']);
	$timesheet_min			     = $qc->clean($_REQUEST['timesheet_min']);
	$timesheet_msg			     = $qc->clean($_REQUEST['timesheet_msg']);
	
	$data = $qc->add_daily_timesheet_info($sr_no,$id,$timesheet_entry_date,$project_id,$project_category_id,$project_sub_category_id,$drawing_no,$model_no,$timesheet_hrs,$timesheet_min,$timesheet_msg);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_EMPLOYEE_DAILY_TIMESHEET&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_EMPLOYEE_DAILY_TIMESHEET&RESPONSE=";
		}
}// 

// 	Add daily activity timesheet by employee 
if($quantsoftAdminMethod == "ADD_EMPLOYEE_DAILY_ACTIVITY_TIMESHEET"){
	
	$timesheet_entry_date        = $qc->clean($_REQUEST['timesheet_entry_date']);
	$sr_no					     = $qc->clean($_REQUEST['sr_no']);
	$activity_id				 = $qc->clean($_REQUEST['activity_id']);
	$timesheet_hrs			     = $qc->clean($_REQUEST['timesheet_hrs']);
	$timesheet_min			     = $qc->clean($_REQUEST['timesheet_min']);
	$timesheet_msg			     = $qc->clean($_REQUEST['timesheet_msg']);
	
	$data = $qc->add_daily_activity_timesheet_info($sr_no,$id,$timesheet_entry_date,$activity_id,$timesheet_hrs,$timesheet_min,$timesheet_msg);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_EMPLOYEE_DAILY_ACTIVITY_TIMESHEET&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_EMPLOYEE_DAILY_ACTIVITY_TIMESHEET&RESPONSE=";
		}
}// 

// approve daily time sheet 
if($quantsoftAdminMethod == "APPROVE_DAILY_TIMESHEET"){	

	$sr_no  = $qc->clean($_REQUEST['sr_no']);
	$admin_msg  = $qc->clean($_REQUEST['admin_msg']);
	
	$data = $qc->approve_daily_timesheet($sr_no,$id,$admin_msg);		

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=APPROVE_DAILY_TIMESHEET&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=APPROVE_DAILY_TIMESHEET&RESPONSE=";
		}

}//
// disapprove daily time sheet 
if($quantsoftAdminMethod == "DISAPPROVE_DAILY_TIMESHEET"){	

	$sr_no  = $qc->clean($_REQUEST['sr_no']);
	$admin_msg  = $qc->clean($_REQUEST['admin_msg']);
	
	$data = $qc->disapprove_daily_timesheet($sr_no,$id,$admin_msg);
	
		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=DISAPPROVE_DAILY_TIMESHEET&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=DISAPPROVE_DAILY_TIMESHEET&RESPONSE=";
		}

}//

// emp project productivity  
if($quantsoftAdminMethod == "GET_EMP_PROJ_PRODUCTIVITY"){	
	
	$data = $qc->emp_project_productivity();
	
		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_PROJ_PRODUCTIVITY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_PROJ_PRODUCTIVITY&RESPONSE=";
		}
}//

// emp project productivity by search 
if($quantsoftAdminMethod == "GET_EMP_PRODUCTIVITY_BY_SEARCH"){	

	$emp_id         = $qc->clean($_REQUEST['emp_id']);
	$emp_from_date  = $qc->clean($_REQUEST['emp_from_date']);
	$emp_to_date    = $qc->clean($_REQUEST['emp_to_date']);
	
	$data = $qc->emp_project_productivity_search($emp_id,$emp_from_date,$emp_to_date);
	
		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_PRODUCTIVITY_BY_SEARCH&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_PRODUCTIVITY_BY_SEARCH&RESPONSE=";
		}

}//

//  project wise productivity  
if($quantsoftAdminMethod == "GET_PROJECT_PRODUCTIVITY"){	
	
	$data = $qc->project_productivity();
	
		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=GET_PROJECT_PRODUCTIVITY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_PROJECT_PRODUCTIVITY&RESPONSE=";
		}

}//

/* MY PACKAGE */
// get apply leave details 
if($quantsoftAdminMethod == "GET_APPLIED_LEAVE_INFO"){		
		
		$data=$qc->get_emp_apply_leave_info();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_APPLIED_LEAVE_INFO&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_APPLIED_LEAVE_INFO&RESPONSE=";
		}
} //

// get apply leave details 
if($quantsoftAdminMethod == "GET_APPLIED_LEAVE_INFO_BYDATE"){		
		$leaveSearchDate  = $qc->clean($_REQUEST['leaveSearchDate']);
		$data=$qc->get_emp_apply_leave_info_bydate($leaveSearchDate);
		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_APPLIED_LEAVE_INFO_BYDATE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_APPLIED_LEAVE_INFO_BYDATE&RESPONSE=";
		}
} //

//apply leave
if($quantsoftAdminMethod == "APPLY_FOR_LEAVE"){
	
	$no_of_days      = $qc->clean($_REQUEST['no_of_days']);
	$from_date		 = $qc->clean($_REQUEST['from_date']);
	$to_date	     = $qc->clean($_REQUEST['to_date']);
	$leave_type_id   = $qc->clean($_REQUEST['leave_type_id']);
	$leave_msg	     = $qc->clean($_REQUEST['leave_msg']);
	$leave_incharge_id = $qc->clean($_REQUEST['leave_incharge_id']);
	
	$data = $qc->apply_for_leave($id,$no_of_days,$from_date,$to_date,$leave_type_id,$leave_msg,$leave_incharge_id);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=APPLY_FOR_LEAVE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=APPLY_FOR_LEAVE&RESPONSE=";
		}
}//

// Leave Request Accept
if($quantsoftAdminMethod == "LEAVE_REQUEST_ACCEPT"){
	$emp_id    		   = $qc->clean($_REQUEST['emp_id']);
	$leave_id  = $qc->clean($_REQUEST['leave_id']);
	
	
	$data =  $qc->leave_request_accept($id,$emp_id,$leave_id);

		if($data == true){
			
			echo "RESULT=SUCCESS&REQUEST=LEAVE_REQUEST_ACCEPT&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=LEAVE_REQUEST_ACCEPT&RESPONSE=";
		}
}//
// Leave Request Accept
if($quantsoftAdminMethod == "LEAVE_REQUEST_REJECT"){
	$emp_id    		   = $qc->clean($_REQUEST['emp_id']);
	$leave_applied_id  = $qc->clean($_REQUEST['leave_applied_id']);
	
	$data =  $qc->leave_request_reject($id,$emp_id,$leave_applied_id);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=LEAVE_REQUEST_REJECT&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=LEAVE_REQUEST_REJECT&RESPONSE=";
		}
}//

// delete applied leave by employee 
if($quantsoftAdminMethod == "DELETE_APPLIED_LEAVE"){
	$leave_id = $qc->clean($_REQUEST['leave_id']);
	
	    $data  =  $qc->delete_leave_request($leave_id);
		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=DELETE_APPLIED_LEAVE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=DELETE_APPLIED_LEAVE&RESPONSE=";
		}
}//

/*  GET EMP LEAVE HISTORY by id */
if($quantsoftAdminMethod == "GET_EMP_LEAVE_HISTORY"){		
		//echo $id;
		
		$data=$qc->get_emp_leave_history($id);

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_LEAVE_HISTORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_LEAVE_HISTORY&RESPONSE=";
		}
} //

/*  GET ALL EMP LEAVE HISTORY  */
if($quantsoftAdminMethod == "GET_ALL_EMP_LEAVE_HISTORY"){		
		//echo $id;
		
		$data=$qc->get_all_emp_leave_history();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_ALL_EMP_LEAVE_HISTORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_ALL_EMP_LEAVE_HISTORY&RESPONSE=";
		}
} //

/* QUANTSOFT EMPLOYEE DIRECTORY */

// get employee details 

if($quantsoftAdminMethod == "GET_EMP_INFO_DETAILS"){		
		
		$data=$qc->get_emp_info_details();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_INFO_DETAILS&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_INFO_DETAILS&RESPONSE=";
		}
} //

// add new employee
 
if($quantsoftAdminMethod == "ADD_NEW_QUANTSOFT_EMPLOYEE"){	
		
		$emp_id                  = $qc->clean($_REQUEST['emp_id']);
		$emp_first_name          = $qc->clean($_REQUEST['emp_first_name']);
		$emp_last_name           = $qc->clean($_REQUEST['emp_last_name']);
		$emp_gender         	 = $qc->clean($_REQUEST['emp_gender']);
		$emp_email_id        	 = $qc->clean($_REQUEST['emp_email_id']);
		$emp_mobile_no        	 = $qc->clean($_REQUEST['emp_mobile_no']);
		$emp_blood_grp           = $qc->clean($_REQUEST['emp_blood_grp']);
		$emp_city         		 = $qc->clean($_REQUEST['emp_city']);
		$emp_state        		 = $qc->clean($_REQUEST['emp_state']);
		$emp_country        	 = $qc->clean($_REQUEST['emp_country']);
		$emp_pincode       		 = $qc->clean($_REQUEST['emp_pincode']);
		$emp_emges_cont_name     = $qc->clean($_REQUEST['emp_emges_cont_name']);
		$emp_emges_cont_no  	 = $qc->clean($_REQUEST['emp_emges_cont_no']);
		$emp_start_date 		 = $qc->clean($_REQUEST['emp_start_date']);
		$emp_title               = $qc->clean($_REQUEST['emp_title']);
		$emp_team 			     = $qc->clean($_REQUEST['emp_team']);
		$employee_id 		     = $qc->clean($_REQUEST['employee_id']);
		$emp_intial_password     = $qc->clean($_REQUEST['emp_intial_password']);
		$access_type		     = $qc->clean($_REQUEST['access_type']);
		$emp_dob			     = $qc->clean($_REQUEST['emp_dob']);

$salt = 'abcdefjhighklmnopqurstuzdfsjnsdn@!12314567809';
$emp_intial_password = $emp_intial_password.$salt;
$emp_intial_password = sha1($emp_intial_password);

	$data = $qc->add_new_quantsoft_emp_info($emp_id,$emp_first_name,$emp_last_name,$emp_gender,$emp_email_id,$emp_mobile_no,$emp_blood_grp,$emp_city,$emp_state,$emp_country,$emp_pincode,$emp_emges_cont_name,$emp_emges_cont_no,$emp_start_date,$emp_title,$emp_team,$employee_id,$emp_intial_password,$access_type,$emp_dob);

		if($data == true){
				
$mailto = $emp_email_id; //Enter recipient email address here

$subject = "QUANTSOFT...Employee Password !";

$from="kapilpatil8055@gmail.com"; //Your valid email address here

$message_body = "Your company password:". $emp_intial_password;

mail($mailto,$subject,$message_body,"From:".$from);
			
			echo "RESULT=SUCCESS&REQUEST=ADD_NEW_QUANTSOFT_EMPLOYEE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_NEW_QUANTSOFT_EMPLOYEE&RESPONSE=";
		}
}//

// delete employee details 

if($quantsoftAdminMethod == "DELETE_EMP_INFO_DETAILS"){
	$emp_id = $qc->clean($_REQUEST['emp_id']);
	
	$data = $qc->delete_quantsoft_emp_info($emp_id);
	if($data == true){
			echo "RESULT=SUCCESS&REQUEST=DELETE_EMP_INFO_DETAILS&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=DELETE_EMP_INFO_DETAILS&RESPONSE=";
		}
}//

/* QUANTSOFT PROJECT DIRECTORY */

// get quantsoft project details 
if($quantsoftAdminMethod == "GET_PROJ_INFO_DETAILS"){		
		
		$data=$qc->get_proj_info_details();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_PROJ_INFO_DETAILS&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_PROJ_INFO_DETAILS&RESPONSE=";
		}
} //

// add new project 
if($quantsoftAdminMethod == "ADD_NEW_QUANTSOFT_PROJECT"){
	
	    $project_id              = $qc->clean($_REQUEST['project_id']);
	    $project_no              = $qc->clean($_REQUEST['project_no']);
		$project_name            = $qc->clean($_REQUEST['project_name']);
		$project_start_date      = $qc->clean($_REQUEST['project_start_date']);
		$project_allcated_hrs    = $qc->clean($_REQUEST['project_allcated_hrs']);
		$project_incharge        = $qc->clean($_REQUEST['project_incharge']);
	
	$data = $qc->add_new_quantsoft_project_info($project_id,$project_no,$project_name,$project_start_date,$project_allcated_hrs,$project_incharge);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_NEW_QUANTSOFT_PROJECT&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_NEW_QUANTSOFT_PROJECT&RESPONSE=";
		}
} //

// Active Project
if($quantsoftAdminMethod == "ACTIVE_PROJECT"){	

	$project_id  = $qc->clean($_REQUEST['project_id']);
	
	$data = $qc->active_project($project_id);		

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ACTIVE_PROJECT&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ACTIVE_PROJECT&RESPONSE=";
		}

}// 

// Deactive Project
if($quantsoftAdminMethod == "DEACTIVE_PROJECT"){	

	$project_id  = $qc->clean($_REQUEST['project_id']);
	
	$data = $qc->deactive_project($project_id);		

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ACTIVE_PROJECT&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ACTIVE_PROJECT&RESPONSE=";
		}

}// 

/* CATEGORY */

// get category  
if($quantsoftAdminMethod == "GET_CATEGORY_INFO"){		
		
		$data=$qc->get_category_info();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_CATEGORY_INFO&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_CATEGORY_INFO&RESPONSE=";
		}
} //

// add category 
if($quantsoftAdminMethod == "ADD_NEW_CATEGORY"){
	    $category_name  = $qc->clean($_REQUEST['category_name']);
		
	    $data = $qc->add_new_category($category_name);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_NEW_CATEGORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_NEW_CATEGORY&RESPONSE=";
		}
} // 

// edit category 
if($quantsoftAdminMethod == "EDIT_CATEGORY"){
	    $cat_id  = $qc->clean($_REQUEST['cat_id']);
	    $category_name  = $qc->clean($_REQUEST['category_name']);
		
	    $data = $qc->edit_category($cat_id,$category_name);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=EDIT_CATEGORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=EDIT_CATEGORY&RESPONSE=";
		}
} // 

// Remove category
if($quantsoftAdminMethod == "REMOVE_CATEGORY"){	
	$cat_id  = $qc->clean($_REQUEST['cat_id']);
	
	$data = $qc->remove_category($cat_id);		
	$data1 = $qc->remove_cat_sub_cat($cat_id);		

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=REMOVE_CATEGORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=REMOVE_CATEGORY&RESPONSE=";
		}

}//

// edit sub category 
if($quantsoftAdminMethod == "EDIT_SUB_CATEGORY"){
	    $sub_cat_id         = $qc->clean($_REQUEST['sub_cat_id']);
	    $sub_category_name  = $qc->clean($_REQUEST['sub_category_name']);
		
	    $data = $qc->edit_sub_category($sub_cat_id,$sub_category_name);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=EDIT_SUB_CATEGORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=EDIT_SUB_CATEGORY&RESPONSE=";
		}
} // 

// Remove sub category
if($quantsoftAdminMethod == "REMOVE_SUB_CATEGORY"){	
	$sub_cat_id  = $qc->clean($_REQUEST['sub_cat_id']);
	
	$data = $qc->remove_sub_category($sub_cat_id);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=REMOVE_SUB_CATEGORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=REMOVE_SUB_CATEGORY&RESPONSE=";
		}

}//
/* SUB CATEGORY */

// get sub category  
if($quantsoftAdminMethod == "GET_SUB_CATEGORY_INFO"){		
		
		$data=$qc->get_sub_category_info();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_SUB_CATEGORY_INFO&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_SUB_CATEGORY_INFO&RESPONSE=";
		}
} //

// add sub category 

if($quantsoftAdminMethod == "ADD_NEW_SUB_CATEGORY"){
	
	    $category_id  		= $qc->clean($_REQUEST['category_id']);
		$sub_category_nameSTR  = $qc->clean($_REQUEST['sub_category_nameSTR']);
		
		$sub_category_name = explode("@@@@",$sub_category_nameSTR);
		$val = count($sub_category_name);
		
		for($i=0;$i<($val-1);$i++){
			$data = $qc->add_new_sub_category($category_id,$sub_category_name[$i]);
		}	
		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_NEW_SUB_CATEGORY&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_NEW_SUB_CATEGORY&RESPONSE=";
		}
} // 

/* TYPE OF LEAVE */
// get leave type  
if($quantsoftAdminMethod == "GET_LEAVE_TYPE_INFO"){		
		
		$data=$qc->get_leave_type_info();

		if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_LEAVE_TYPE_INFO&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_LEAVE_TYPE_INFO&RESPONSE=";
		}
} //

// add leave type
if($quantsoftAdminMethod == "ADD_NEW_LEAVE_TYPE"){
	
	    $leave_type_name  = $qc->clean($_REQUEST['leave_type_name']);
	    $no_of_days  = $qc->clean($_REQUEST['no_of_days']);
		
	$data = $qc->add_new_leave_type($leave_type_name,$no_of_days);

		if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_NEW_LEAVE_TYPE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_NEW_LEAVE_TYPE&RESPONSE=";
		}
} // 

// delete leave type 
if($quantsoftAdminMethod == "DELETE_LEAVE_TYPE"){
	$leave_id = $qc->clean($_REQUEST['leave_id']);
	
	$data = $qc->delete_leave_type($leave_id);
	if($data == true){
		$delete_emp_leave = $qc->delete_emp_leav($leave_id);
			echo "RESULT=SUCCESS&REQUEST=DELETE_LEAVE_TYPE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=DELETE_LEAVE_TYPE&RESPONSE=";
		}
}//

// ASSIGN_LEAVE_DAYS
if($quantsoftAdminMethod == "ASSIGN_LEAVE_DAYS_TO_EMP"){
	$leave_emp_id = $qc->clean($_REQUEST['leave_emp_id']);
	$leave_id     = $qc->clean($_REQUEST['leave_id']);
	$no_of_days   = $qc->clean($_REQUEST['no_of_days']);

	
	$data = $qc->assign_leave_days($leave_emp_id,$leave_id,$no_of_days);

	if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ASSIGN_LEAVE_DAYS_TO_EMP&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ASSIGN_LEAVE_DAYS_TO_EMP&RESPONSE=";
		}
}//

// GET_EMP_LEAVE_QUOTA 
if($quantsoftAdminMethod == "GET_EMP_LEAVE_QUOTA"){

	$data = $qc->get_emp_leave_quota();

	if($data == true){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_LEAVE_QUOTA&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_LEAVE_QUOTA&RESPONSE=";
		}
}//

// add emp attendance manualy by admin 
if($quantsoftAdminMethod == "ADD_MANUAL_ATTENDANCE"){
	$punching_code = $qc->clean($_REQUEST['punching_code']);
	$log_date     = $qc->clean($_REQUEST['log_date']);
	$log_time   = $qc->clean($_REQUEST['log_time']);

	
	$data = $qc->add_manual_attendance($punching_code,$log_date,$log_time);

	if($data == true){
			echo "RESULT=SUCCESS&REQUEST=ADD_MANUAL_ATTENDANCE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=ADD_MANUAL_ATTENDANCE&RESPONSE=";
		}
}//

// get emp attendance
if($quantsoftAdminMethod == "GET_EMP_ATTENDANCE"){
	$attendance_date = $qc->clean($_REQUEST['attendance_date']);
	$data = $qc->get_emp_attendance($attendance_date);
	if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_ATTENDANCE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_ATTENDANCE&RESPONSE=";
		}
}//

// get emp attendance by id
if($quantsoftAdminMethod == "GET_EMP_ATTENDANCE_BY_ID"){
	
	$data = $qc->get_emp_attendance_by_id($id);
	if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_ATTENDANCE_BY_ID&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_ATTENDANCE_BY_ID&RESPONSE=";
		}
}//

// get emp  monthly attendance by id and year and month 
if($quantsoftAdminMethod == "GET_EMP_MONTHLY_ATTENDANCE"){
	$punching_code       = $qc->clean($_REQUEST['punching_code']);
	$attendance_year     = $qc->clean($_REQUEST['attendance_year']);
	$attendance_month    = $qc->clean($_REQUEST['attendance_month']);
	
	$data = $qc->get_emp_monthly_attendance($punching_code,$attendance_year,$attendance_month);
	
	if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_MONTHLY_ATTENDANCE&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_MONTHLY_ATTENDANCE&RESPONSE=";
		}
}//

// get emp timesheet by id, year, and month
if($quantsoftAdminMethod == "GET_EMP_MONTHLY_TIMESHEET"){
	$emp_id      		= $qc->clean($_REQUEST['emp_id']);
	$timesheet_year     = $qc->clean($_REQUEST['timesheet_year']);
	$timesheet_month    = $qc->clean($_REQUEST['timesheet_month']);
	
	$data = $qc->get_emp_monthly_timesheet($emp_id,$timesheet_year,$timesheet_month);
	
	if($data!=''){
			echo "RESULT=SUCCESS&REQUEST=GET_EMP_MONTHLY_TIMESHEET&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=GET_EMP_MONTHLY_TIMESHEET&RESPONSE=";
		}
}//

}else{
	exit();
}