<!DOCTYPE html>
<html>
  <head>
    <title>Forgot Password</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/input_style.css">
    <link rel="stylesheet" href="css/font-awesome.css">
  </head>

  <body>
    <div class="login_main_div">
    <h2 class="login_our_logo">Reset Password</h2>
      <div class="col-md-4 col-md-offset-4">
        <p class="reset_password_line">Enter your registered email address and you will get a mail with new password.</p>
        <form method="post">
          <div class="communication_input card margin_top_25">
            <div class="form-group input-container">
              <input type="text" id="emp_email_id" required="required">
              <label for="To">Email</label>
              <div class="bar"></div>
            </div>
          </div>
          <input type="button" value="button" class="form-control submit_button" onclick="forgotPassword();">
          <div class="width_100">
            <span class="forgot_password"><a href="index.php" class="login_links"><i class="fa fa-user" aria-hidden="true"></i> Login</a></span>
          </div>
        </form>
        <div class="border_1px"></div>
      </div>
    </div>
<!-- Modal -->
  <div class="modal fade" id="actionAlertPopup" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header popup_header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
        </div>
        <div class="modal-body popup_body" id="msgBox">
          <!-- your msg here --> 
        </div>
      </div>
      
    </div>
  </div>	
<!-- -->
   
	<script src="js/jQuery-2.1.4.min.js"></script>
	 <script src="js/bootstrap.js"></script>
<script>
function forgotPassword(){
	
	
	var emp_email_id = $("#emp_email_id").val();
		//alert(emp_email_id);
    $.ajax({
            type : "POST",
            url  : "cp_query.php",
			async: false,
            data : {
                "VERSION"               : "1.00",
                "QUANTSOFTTOKEN"        : "adminquantsoft2015esya",
                "emp_email_id"          : emp_email_id,
                "METHOD"				        : "FORGOT_PASSWORD"
            }
        })
        .done(function(data) {
			console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){	
				$('#emp_email_id').val();
					$('#msgBox').html('<p>Congratulations! Your new password have been successfully sent to your registered email id, kindly check your inbox.</p>');
					$('#actionAlertPopup').modal('show');
					
					
						
                } // SUCCESS
            }else{
					
					$('#msgBox').html('<p>Sorry! Please confirm your registered email id, else contact to Administrator.</p>');
				$('#actionAlertPopup').modal('show');
				$('#emp_email_id').val();
				
			}// fail 
        })
        .fail(function(data) {
			//window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	
}

</script>	

  </body>
    
</html>
