<!DOCTYPE html>
<html>
  <head>
    <title>Timesheet Management</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/input_style.css">
    <link rel="stylesheet" href="css/landing_mystyle.css">
    <link rel="stylesheet" href="css/font-awesome.css">
  </head>

  <body>
    <div class="col-md-offset-3 col-sm-offset-3 col-md-6 col-sm-6 col-xs-12">
        <div class="landing_bg">
            <span style="text-align: center;"><h2>Timesheet Management System</h2></span>
            <div class="col-md-6 col-md-offset-3">
  <form name="register_form"  method="post" action="check_login.php">
      <div class="communication_input card">
        <div class="form-group input-container">
              <input type="email"  name="username" pattern="[a-zA-Z0-9._]+@[a-zA-Z0-9.-]+\.[a-z]{2,3}$" id="" required="required">
              <label for="To">Email Id</label>
              <div class="bar"></div>
        </div>
                    <p>example@xyz.com</p>
        </div>
        <div class="communication_input card">
          <div class="form-group input-container">
              <input type="password" name="password"   id="" required="required">
              <label for="To">Password</label>
              <div class="bar"></div>
          </div>
        </div>
        <input type="submit" value="Login" class="form-control submit_button">
  </form>
                
                <div class="width_100 message_login">
               <span style="font-size: large;"> <?php include_once('message.php'); ?></span>
                </div>
                
                <div class="width_100" style="margin-top: -15px;">
                  <span class="forgot_password"><a href="forgotpassword.php" class="login_links"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Forgot Password</a></span><br>
                
                </div>
              
            </div>
        </div>  <!--landing_bg-->
    </div>  <!--colmd6-->
  </body>
</html>
