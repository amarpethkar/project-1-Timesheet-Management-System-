<?php 
	ob_start();
	
	// allow cross browser request
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	

	$quantsoftAdminVersion_007 = $_REQUEST['VERSION'];
	$quantsoftAdminToken = $_REQUEST['QUANTSOFTTOKEN'];
	$quantsoftAdminMethod = $_REQUEST['METHOD'];

 
// Check Version & Token 
if($quantsoftAdminVersion_007 == 1.00 && $quantsoftAdminToken == "adminquantsoft2015esya"){

include_once('classes/query_class.php');
$qc = new queryClass();

if($quantsoftAdminMethod == "FORGOT_PASSWORD"){
	
	$str = 'JQZ$!84ay';
    $shuffled = str_shuffle($str);
	$emp_email_id = $qc->clean($_REQUEST['emp_email_id']);
	
	$data = $qc->forgot_password($shuffled,$emp_email_id);
	if(data == true){

$mailto = $emp_email_id; //Enter recipient email address here

$subject = "Quantsoft - New Password !";

$from="pethkaramar@gmail.com"; //Your valid email address here

$message_body = "Your new password:". $shuffled;

mail($mailto,$subject,$message_body,"From:".$from);

//echo "Your email has been sent successfully";

			echo "RESULT=SUCCESS&REQUEST=FORGOT_PASSWORD&RESPONSE=".$data;
		}else{
			echo "RESULT=ERROR&REQUEST=FORGOT_PASSWORD&RESPONSE=";
		}
}//


}else{
	exit();
}
?>