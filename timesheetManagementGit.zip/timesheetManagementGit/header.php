 	  <header class="main-header">
        <nav class="navbar navbar-static-top header_fixed" role="navigation">
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          	<span class="sr-only">Toggle navigation</span>
          </a>
          <div class="analytics_container">
	          <div class="analytics_header_div_50">
		         <h1 id="page_title"></h1>
		       
	          </div>
	          <div class="analytics_header_div_50">
	          	  <div class="dropdown login_name_dropdown">
				    <button class="btn btn-default dropdown-toggle login_name_button" type="button" data-toggle="dropdown"><?php echo $name; ?><span class="caret"></span></button>
				    <ul class="dropdown-menu login_dropdown">
				      <li><a onclick="accountSettings();" class="login_dropdown_link link_pointer"><i class="fa fa-cog" aria-hidden="true"></i>Account Settings</a></li>
					  <!-- <li><a onclick="accountSettingsImg();" class="login_dropdown_link link_pointer"><i class="fa fa-cog" aria-hidden="true"></i>Profile Settings</a></li> -->
				      <li><a href="logout.php" class="login_dropdown_link link_pointer"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
				    </ul>
				  </div>
				  <img src="images/profilepicture.png" alt="Profile Pic" class="profile_picture">
				  <?php if($user_type == "employee"){ ?>
				  <a onclick="messages();" class="link_pointer"><i class="fa fa-envelope fa-2x mail_icon" aria-hidden="true"></i></a> <span class="badge" id="leaveNotiEmpCount">0</span>
					  <?php }?>
	          </div>
          </div>
        </nav>
      </header>