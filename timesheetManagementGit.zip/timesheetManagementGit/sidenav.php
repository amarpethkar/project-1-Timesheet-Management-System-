      <?php 
	  if($user_type == 'admin'){
		  ?>
	  <!-- sidenav for admin login -->
	  <aside class="main-sidebar">
        <section class="sidebar">
          <span style="text-align: center; color: white;"><h4>Timesheet Management System</h4></span>
          <ul class="sidebar-menu">
            <li class="treeview" id="side_menu3">
              <a onclick="analytics();" class="link_pointer"><i class="fa fa-bar-chart" aria-hidden="true"></i> <span>Analytics</span></a>
            </li>
            <li class="treeview" id="side_menu4">
              <a onclick="approveTimesheets();" class="link_pointer"><i class="fa fa-clock-o" aria-hidden="true"></i> <span>Timesheet Approval&nbsp;&nbsp;(<span id="timeesheetNotiCount" style="color:#fff;">0</span>)</span></a>
            </li>
            <li class="treeview" id="side_menu5">
              <a onclick="employeeDirectory();" class="link_pointer"><i class="fa fa-male" aria-hidden="true"></i> <span>Employee Directory</span></a>
            </li> 
            <li class="treeview" id="side_menu6">
              <a onclick="projectDirectory();" class="link_pointer"><i class="fa fa-product-hunt" aria-hidden="true"></i> <span>Project Directory</span></a>
            </li> 
			
            <li class="treeview" id="side_menu7">
              <a onclick="leaveApproval();" class="link_pointer"><i class="fa fa-calendar" aria-hidden="true"></i> <span>Leave approval&nbsp;&nbsp;(<span id="leaveNotiCount" style="color:#fff;">0</span>)</span></a>
            </li> 
			
            <li class="treeview" id="side_menu8">
              <a onclick="settings();" class="link_pointer"><i class="fa fa-cog" aria-hidden="true"></i> <span>Settings</span></a>
            </li> 
          </ul>
        </section>
      </aside>
	  <!-- -->
	  <?php }else{ ?>
	  
	  <!-- sidenav for employee -->
	  <aside class="main-sidebar">
        <section class="sidebar">
          <span style="text-align: center; color: white;"><h4>Timesheet Management System</h4></span>
          <ul class="sidebar-menu">
            <li class="active treeview" id="side_menu1">
              <a onclick="timesheetEntry();" class="link_pointer"><i class="fa fa-clock-o" aria-hidden="true"></i> <span>Timesheet Entry</span></a>
            </li>
			<?php 
			if($user_access_type == '1'){?>
				<li class="treeview" id="side_menu2">
              <a onclick="myPackage();" class="link_pointer"><i class="fa fa-male" aria-hidden="true"></i> <span>My Package</span></span></a>
            </li> 
			<?php } ?>
            
          </ul>
        </section>
      </aside>
	  <!-- -->
	  <?php } ?>