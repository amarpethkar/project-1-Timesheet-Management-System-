<?php 
error_reporting(E_ALL ^ E_NOTICE);
$status = $_REQUEST['status'];

if($status=='' || $status==NULL){}
else { if($status==1){ ?>
              <tr>
                <td colspan="2" class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp; Please try again with Correct Username &amp; Password.</td>
              </tr>
              <?php } if($status==2){ ?>
              <tr>
                <td colspan="2" class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;Process Failed, Please try again or contact Administrator.</td>
              </tr>
              <?php } if($status==3){ ?>
              <tr>
                <td colspan="2" class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;Access Denied, Please login again.</td>
              </tr>
              <?php } if($status==5){ ?>
              <tr>
                <td colspan="2" class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;The Validation code does not match!</td>
              </tr>
              <?php } if($status==4){ ?>
              <tr>
                <td colspan="2" class="alert_green"><img src="images/yes.png" align="absmiddle" />&nbsp;Logged out successfully.</td>
              </tr>
              <?php } } ?>