<div class="modal fade bg_transparent" id="loader" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog bg_transparent" role="document">
    <div class="modal-content top_250 bg_transparent">
      <div class="modal-body bg_transparent">
        <div class="loader center-block"></div>
    </div>
  </div>
</div>

<style>
.bg_transparent{
    background: transparent !important;
    box-shadow: none !important;
}
.top_250{
  top: 250px !important;
}
.loader {
  border: 2px solid #fff;
  border-radius: 50%;
  border-top: 2px solid #f37434;
  width: 50px;
  height: 50px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>