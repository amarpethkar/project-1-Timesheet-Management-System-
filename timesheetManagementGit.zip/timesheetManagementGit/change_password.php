<?php
require_once('auth.php');
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Change Password - <?php echo $name; ?></title>
<link rel="SHORTCUT ICON" href="images/favicon.jpg" />

<?php 
require_once('common_style.php');
?>
<link href="css/demo.css" rel="stylesheet" type="text/css" >
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/check_form.js"></script>
<script type="text/javascript">
    $(function () {
        $("#btnSubmit").click(function () {
            var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });
	function check_form(form_name) {
  if (submitted == true) {
    alert("This form has already been submitted. Please press Ok and wait for this process to be completed.");
    return false;
  }

  error = false;
  form = form_name;
  error_message = "Please make the following corrections:\n\n";
  
  check_input("old_password", 3, "Old Password");
  check_input("new_password",3, "New Password");
  check_input("retype_password", 3, "Retype Password");
  
  if (error == true) {
    alert(error_message);
    return false;
  } else {
   
    submitted = true;
    return true;
  }
}
</script>
</head>

<body style="background:#f1f1f1;">
<div class="I-wrapper">
  <div class="I-MainContainer">
    <div class="I-header" align="center">
      <div>
      <table width="100%" align="center">
      <tr>
            <td width="70%"><div align="center"><img style="padding-left: 355px;" src="images/logo.gif" title="Indian Library" height="80"></div></td>
            <td><div style="clear: both; float: right; height: 40px; width: 100%;"><span class="i-icones"><?php if($tittle=='admin'){?><a href="admin_panel.php"><img src="images/home.png" title="Home"></a><?php } else{?> <a href="user_panel.php"> <img src="images/home.png" title="Home"></a><?php }?> <a href="logout.php"><img src="images/logout.png" title="Logout"></a></span></div><span style="float:right; font-size: 14px;">WELCOME : <?php echo $name; ?></span></td>
          </tr>
        </table>
      </div>
    </div>
    <div>
      <?php
				$msg=$_REQUEST['msg'];
				if($msg==1){ 
			?>
      <font class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;Old password is wrong, Retry.</font>
      <?php } 
			if($msg==2){ 
			?>
      <font class="alert_green"><img src="images/yes.png" align="absmiddle" />&nbsp;New password is updated successfully.</font>
      <?php }if($msg==3){ 
			?>
      <font class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;New password and Old Password must be different.</font>
      <?php }if($msg==4){ 
			?>
      <font class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;Try Again.</font>
      <?php } ?>
    </div>
    <div class="I-content">
      <table width="99%" align="center" class="I-table">
       <form name="change_pass" action="query.php" method="post" onSubmit="return check_form(change_pass);">
        <tr class="I-bg">
          <td colspan="4"><div class="I-text"><img src="images/password.png"><span style="position: relative; top: -5px;">&nbsp;&nbsp;CHANGE PASSWORD</span></div></td>
        </tr>
        <tr>
          <td ><div class="I-subContent">User Name:</div></td>
          <td ><div class="I-subContent">
              <input name="user_name" type="text" class="inputBox" value="<?php echo $email; ?>" disabled>
            </div></td>
          <td ><div class="I-subContent">Old Password:</div></td>
          <td ><div class="I-subContent">
              <input name="old_password" type="text" class="inputBox" placeholder="type old password here">
            </div></td>
        </tr>
        <tr>
          <td ><div class="I-subContent">New Password:</div></td>
          <td ><div class="I-subContent">
              <input name="new_password" type="password" id="txtPassword" class="inputBox" placeholder="type new password here">
            </div></td>
          <td ><div class="I-subContent">Confirm Password:</div></td>
          <td ><div class="I-subContent">
              <input name="retype_password" type="password" id="txtConfirmPassword" class="inputBox" placeholder="re-type new password here">
            </div></td>
        </tr>
        <tr>
          <td colspan="4" align="center"><div class="I-subContent1">
              <input value="Save" class="I-btn" type="submit" id="btnSubmit">
               <input type="hidden" name="function" value="change_password">
            </div><div class="I-subContent" style="float: left;">
              <input value="Reset" class="I-btn" type="reset">
            </div></td>
        </tr>
        </form>
      </table>
    </div>
    <!--I-content end-->
    <div class="footer">
      <table width="92%" align="center">
        <tr>
          <td><p style="text-align: left; margin-top: -2px; padding:5px;">© Indian Library 2015</p></td>
          <td><p style="margin-top: -2px; float:right;padding:5px;">Designed & developed by <a href="http://www.esyainnovations.com/" target="_blank">eSya Innovations</a></p></td>
        </tr>
      </table>
    </div>
  </div>
  <!--I-mainContainer end--> 
</div>
<!--I-wrapper end-->
</body>
</html>
