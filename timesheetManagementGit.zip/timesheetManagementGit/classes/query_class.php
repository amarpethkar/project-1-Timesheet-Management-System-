<?php 
require_once('conn_obj.php');


class queryClass{

	//function queryClass(){}
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) 
	{
	global $con;
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysqli_real_escape_string($con,$str);
	}
	
/*....................................... Functions Area ......................................*/

// get leave notification 

function get_leave_notification($approve_incharge){
	global $con;
	try{
		
			$sql = "SELECT COUNT(leave_applied_id) as count FROM `quantsoft_emp_package` WHERE approve_flag = '0' AND approve_incharge = '$approve_incharge' ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			
			 
			 if($row = mysqli_fetch_array($rs)){
                 $result = $row['count'];
			}
	        return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}// 

// get Timesheet notification 

function get_timesheet_notification($id){
	global $con;
	try{
			$sql = "SELECT COUNT(qat.sr_no) as count FROM `quantsoft_daily_timesheet` qat, quantsoft_projects qp WHERE qat.timesheet_flag = '0' AND qat.project_id = qp.project_id AND qp.project_incharge = $id ";
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			 if($row = mysqli_fetch_array($rs)){
                 $result = $row['count'];
			}
	        return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}// 

// get leave notification emp 

function get_leave_notification_emp($id){
	global $con;
	try{
			$sql = "SELECT COUNT(leave_applied_id) as count FROM `quantsoft_emp_package` WHERE seen_unseen_flag = '0' AND emp_id = $id ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			
			 
			 if($row = mysqli_fetch_array($rs)){
                 $result = $row['count'];
			}
	        return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}// 

// get Timesheet disapprove notification emp 

function get_timesheet_disAprv_notification_emp($id){
	global $con;
	try{
			$sql = "SELECT COUNT(sr_no) as count FROM `quantsoft_daily_timesheet` WHERE timesheet_flag = '2' AND emp_id = '$id'";
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			 if($row = mysqli_fetch_array($rs)){
                 $result = $row['count'];
			}
	        return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}// 

// update seen noti emp 
function update_emp_seen_noti($id){
	global $con;
		try{
			$sql = "UPDATE quantsoft_emp_package SET seen_unseen_flag = '1' WHERE emp_id = '$id' AND seen_unseen_flag = '0' ";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// forgot password 

function forgot_password($shuffled,$emp_email_id){
	
	global $con;
		try{
			$r_id ='';
			$query_log="SELECT emp_id FROM quantsoft_employee WHERE email_id = '$emp_email_id'";
			$rs_log= mysqli_query($con,$query_log) or die(mysqli_error($con));
			if($ru_log=mysqli_fetch_assoc($rs_log)) 
			{
				$emp_id = $ru_log['emp_id'];
			}
			
			if($emp_id!='' && $emp_id!=0){
			$sql_log =  mysqli_query($con,"UPDATE quantsoft_employee SET emp_password = '$shuffled' WHERE email_id = '$emp_email_id' AND emp_id='$emp_id'") or die(mysqli_error());	
					$r_id = $emp_id;
			}
			else{
				
				$query_log="SELECT admin_id FROM quantsoft_admin WHERE email_id = '$emp_email_id'";
			$rs_log= mysqli_query($con,$query_log) or die(mysqli_error($con));
			if($ru_log=mysqli_fetch_assoc($rs_log)){
				$admin_id = $ru_log['admin_id'];
			}	
			if($admin_id!='' && $admin_id!=0){
			$sql_log =  mysqli_query($con,"UPDATE quantsoft_admin SET password = '$shuffled' WHERE email_id = '$emp_email_id' AND admin_id='$admin_id'") or die(mysqli_error());
				$r_id = $admin_id;
				}
			}
			return $r_id;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_log);		
		mysqli_close($sql_log);		
		mysqli_close($con);
	
}//

 /*  ONLOG IN GET PROFILE INFO  */	
 // get user profile
 function get_user_profile($id,$user_type){

	global $con;
	try{
		if($user_type == 'employee'){
			$sql = "SELECT * FROM quantsoft_employee WHERE emp_id = $id ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			if($row_user = mysqli_fetch_assoc($rs)){
                  
				  $result = $result.$row_user['emp_id'].'#@#'.$row_user['emp_first_name'].'#@#'.$row_user['emp_last_name'].'#@#'.$row_user['emp_gender'].'#@#'.$row_user['email_id'].'#@#'.$row_user['password'].'#@#'.$row_user['emp_mobile'].'#@#'.$row_user['emp_blood_grp'].'#@#'.$row_user['emp_city'].'#@#'.$row_user['emp_state'].'#@#'.$row_user['emp_country'].'#@#'.$row_user['emp_pincode'].'#@#'.$row_user['emp_emges_cont_person_name'].'#@#'.$row_user['emp_emges_cont_no'].'#@#'.$row_user['emp_start_date'].'#@#'.$row_user['emp_title'].'#@#'.$row_user['emp_team'].'#@#'.$row_user['employee_quantsoft_id'].'#@#'.$row_user['emp_password'].'#@#'.$row_user['emp_access_type'].'#@#'.$row_user['last_login'].'#@#'.$row_user['added_date'].'@@@@';
					
			}
			
	}else{
			$sql = "SELECT * FROM quantsoft_admin WHERE admin_id = '$id'";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			if($row_user = mysqli_fetch_assoc($rs)){
                  
				  $result = $result.$row_user['admin_id'].'#@#'.$row_user['first_name'].'#@#'.$row_user['last_name'].'#@#'.$row_user['contact_no'].'#@#'.$row_user['email_id'].'#@#'.$row_user['password'].'#@#'.$row_user['last_login'].'#@#'.$row_user['added_date'].'@@@@';
			}
			
	}
	return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//
	

// change password
function change_password($id,$user_type,$old_password,$new_password){
	
	global $con;
		try{
			if($user_type == 'employee'){
				$sql = "UPDATE quantsoft_employee SET emp_password = '$new_password' WHERE emp_password = '$old_password'  AND emp_id = '$id' ";
				$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			}
			if($user_type == 'admin'){
				$sql = "UPDATE quantsoft_admin SET password = '$new_password' WHERE  password = '$old_password' AND admin_id = '$id'  ";
				$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			}
			$val = mysqli_affected_rows($con);
			if($val>0){	
			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//	

// get admin info
function get_admin_profile(){
	global $con;
	try{
		
			$sql = "SELECT * FROM quantsoft_admin ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['admin_id'].'#@#'.$row_user['first_name'].'#@#'.$row_user['last_name'].'#@#'.$row_user['contact_no'].'#@#'.$row_user['email_id'].'#@#'.$row_user['password'].'#@#'.$row_user['last_login'].'#@#'.$row_user['added_date'].'@@@@';
			}
	return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}// 

	
 /* DAILY TIMESHEET ENTRY */
 /* 
Note: 
 flag = 0 -> time sheet submit
 flag = 1 -> time sheet approve 
 flag = 2 -> time sheet disapprove 
*/
// get emp log activity 
function get_emp_log_activity_info(){
	global $con;
	try{
		
			$sql = "SELECT * FROM quantsoft_daily_timesheet ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['sr_no'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['timesheet_date'].'#@#'.$row_user['project_id'].'#@#'.$row_user['category_id'].'#@#'.$row_user['sub_category_id'].'#@#'.$row_user['drawing_no'].'#@#'.$row_user['model_no'].'#@#'.$row_user['timesheet_hrs'].'#@#'.$row_user['timesheet_min'].'#@#'.$row_user['timesheet_msg'].'#@#'.$row_user['added_date'].'#@#'.$row_user['timesheet_flag'].'#@#'.$row_user['checked_by'].'#@#'.$row_user['admin_msg'].'@@@@';
			}
	return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}// 

 // get daily timesheet log 
 function get_daily_timesheet_info($user_date){

	global $con;
	try{
		
			$sql = "SELECT * FROM quantsoft_daily_timesheet WHERE timesheet_date = '$user_date' ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['sr_no'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['timesheet_date'].'#@#'.$row_user['project_id'].'#@#'.$row_user['category_id'].'#@#'.$row_user['sub_category_id'].'#@#'.$row_user['drawing_no'].'#@#'.$row_user['model_no'].'#@#'.$row_user['timesheet_hrs'].'#@#'.$row_user['timesheet_min'].'#@#'.$row_user['timesheet_msg'].'#@#'.$row_user['added_date'].'#@#'.$row_user['timesheet_flag'].'#@#'.$row_user['checked_by'].'@@@@';
			}
	return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//

// Get approval pendding timesheets 
 function get_approval_pendding_timesheet_info(){
	global $con;
	try{
			$sql = "SELECT * FROM quantsoft_daily_timesheet WHERE timesheet_flag = 0
ORDER BY `quantsoft_daily_timesheet`.`timesheet_date`  DESC ";				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['sr_no'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['timesheet_date'].'#@#'.$row_user['project_id'].'#@#'.$row_user['category_id'].'#@#'.$row_user['sub_category_id'].'#@#'.$row_user['drawing_no'].'#@#'.$row_user['model_no'].'#@#'.$row_user['timesheet_hrs'].'#@#'.$row_user['timesheet_min'].'#@#'.$row_user['timesheet_msg'].'#@#'.$row_user['added_date'].'#@#'.$row_user['timesheet_flag'].'#@#'.$row_user['checked_by'].'@@@@';
			}
	return $result;
	}
	catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//
 

// add daily timesheet 
function add_daily_timesheet_info($sr_no,$id,$timesheet_entry_date,$project_id,$project_category_id,$project_sub_category_id,$drawing_no,$model_no,$timesheet_hrs,$timesheet_min,$timesheet_msg){
	global $con;
		try{
			if($sr_no == ''){
				$sql = "INSERT INTO quantsoft_daily_timesheet (emp_id,timesheet_date,project_id,category_id,sub_category_id,drawing_no,model_no,timesheet_hrs,timesheet_min,timesheet_msg,added_date) VALUES ('$id','$timesheet_entry_date','$project_id','$project_category_id','$project_sub_category_id','$drawing_no','$model_no','$timesheet_hrs','$timesheet_min','$timesheet_msg',NOW())";
			}else{
				$sql =" UPDATE quantsoft_daily_timesheet SET timesheet_date='$timesheet_entry_date', project_id='$project_id', category_id='$project_category_id',sub_category_id='$project_sub_category_id',drawing_no='$drawing_no',model_no='$model_no',timesheet_hrs='$timesheet_hrs', timesheet_min='$timesheet_min', timesheet_msg='$timesheet_msg', timesheet_flag='0' WHERE sr_no = '$sr_no' ";
			}
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// add daily activity timesheet 
function add_daily_activity_timesheet_info($sr_no,$id,$timesheet_entry_date,$activity_id,$timesheet_hrs,$timesheet_min,$timesheet_msg){
	global $con;
		try{
			if($sr_no == ''){
				$sql = "INSERT INTO quantsoft_daily_timesheet (emp_id,timesheet_date,project_id,timesheet_hrs,timesheet_min,timesheet_msg,added_date) VALUES ('$id','$timesheet_entry_date','$activity_id','$timesheet_hrs','$timesheet_min','$timesheet_msg',NOW())";
			}else{
				$sql =" UPDATE quantsoft_daily_timesheet SET timesheet_date='$timesheet_entry_date', project_id='$activity_id',timesheet_hrs='$timesheet_hrs', timesheet_min='$timesheet_min', timesheet_msg='$timesheet_msg', timesheet_flag='0' WHERE sr_no = '$sr_no' ";
			}
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// approve daily timesheet 

function approve_daily_timesheet($sr_no,$id,$admin_msg){
	
	global $con;
		try{
			
			$sql = "UPDATE quantsoft_daily_timesheet SET timesheet_flag = '1', checked_by= '$id', admin_msg = '$admin_msg' WHERE sr_no = '$sr_no' ";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// disapprove daily timesheet 

function disapprove_daily_timesheet($sr_no,$id,$admin_msg){
	
	global $con;
		try{
			
			$sql = "UPDATE quantsoft_daily_timesheet SET timesheet_flag = '2', checked_by= '$id',admin_msg = '$admin_msg' WHERE sr_no = '$sr_no' ";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// get emp project productivity 

function emp_project_productivity(){
	
	global $con;
		try{ 
			
			$sql = "SELECT dts.emp_id,emp.emp_first_name, emp.emp_last_name, dts.project_id, sum(timesheet_hrs) as totalHrs, sum(timesheet_min) as totalMin FROM `quantsoft_daily_timesheet` dts LEFT JOIN quantsoft_employee emp on(emp.emp_id=dts.emp_id) WHERE dts.timesheet_flag = '1' group by dts.emp_id,dts.project_id  ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
				  $result = $result.$row_user['emp_id'].'#@#'.$row_user['emp_first_name'].'#@#'.$row_user['emp_last_name'].'#@#'.$row_user['project_id'].'#@#'.$row_user['totalHrs'].'#@#'.$row_user['totalMin'].'@@@@';
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);		
		mysqli_close($con);
	
}//

// get emp project productivity by search

function emp_project_productivity_search($emp_id,$emp_from_date,$emp_to_date){
	global $con;
		try{ 
			$sql = "SELECT dts.timesheet_date,dts.emp_id,emp.emp_first_name, emp.emp_last_name, dts.project_id, sum(timesheet_hrs) as totalHrs, sum(timesheet_min) as totalMin FROM quantsoft_daily_timesheet dts RIGHT JOIN quantsoft_employee emp on(emp.emp_id=dts.emp_id) WHERE DATE(dts.timesheet_date) >= DATE('$emp_from_date') AND DATE(dts.timesheet_date) <= DATE('$emp_to_date') AND dts.timesheet_flag = 1 AND dts.emp_id = $emp_id group by dts.emp_id,dts.project_id ";
				echo $sql;
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
				  $result = $result.$row_user['emp_id'].'#@#'.$row_user['emp_first_name'].'#@#'.$row_user['emp_last_name'].'#@#'.$row_user['project_id'].'#@#'.$row_user['totalHrs'].'#@#'.$row_user['totalMin'].'@@@@';
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// get ecah project productivity 

function project_productivity(){
	
	global $con;
		try{ 
			
			$sql = "SELECT project_id, SUM(timesheet_hrs) as timesheet_hrs, SUM(timesheet_min) as timesheet_min FROM `quantsoft_daily_timesheet` group by project_id   ORDER BY `project_id`";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
				  $result = $result.$row_user['project_id'].'#@#'.$row_user['timesheet_hrs'].'#@#'.$row_user['timesheet_min'].'@@@@';
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);		
		mysqli_close($con);
	
}//

/* MY PACKAGE */
// get apply leave details 

// Note if approve_flag == 0 -> request sent 
//		if approve_flag == 1 -> request approved 
// 		if approve_flag == 2 -> request Rejected   
function get_emp_apply_leave_info(){

	global $con;
		try{ 
			$sql = "SELECT * FROM quantsoft_emp_package ORDER BY leave_applied_id DESC ";
				
			 $rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  //0-11
				  $result = $result.$row_user['leave_applied_id'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['no_of_days'].'#@#'.$row_user['from_date'].'#@#'.$row_user['to_date'].'#@#'.$row_user['leave_type'].'#@#'.$row_user['leave_msg'].'#@#'.$row_user['approve_flag'].'#@#'.$row_user['approved_by'].'#@#'.$row_user['added_date'].'#@#'.$row_user['seen_unseen_flag'].'#@#'.$row_user['approve_incharge'].'@@@@';
					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//

// get leave by search date 
function get_emp_apply_leave_info_bydate($leaveSearchDate){

	global $con;
		try{ 
		$sql = "SELECT * FROM `quantsoft_emp_package` WHERE from_date <= '$leaveSearchDate' AND to_date >= '$leaveSearchDate' ";
				
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  //0-11
				  $result = $result.$row_user['leave_applied_id'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['no_of_days'].'#@#'.$row_user['from_date'].'#@#'.$row_user['to_date'].'#@#'.$row_user['leave_type'].'#@#'.$row_user['leave_msg'].'#@#'.$row_user['approve_flag'].'#@#'.$row_user['approved_by'].'#@#'.$row_user['added_date'].'#@#'.$row_user['seen_unseen_flag'].'#@#'.$row_user['approve_incharge'].'@@@@';
					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//

// assgin leaves to employee 
function assign_leave_days($leave_emp_id,$leave_id,$no_of_days){
	global $con;
		try{
			
			$sql_Check ="SELECT emp_lev_pkg_id FROM quantsoft_emp_leave_package WHERE employee_id = $leave_emp_id AND leave_id = $leave_id ";
			
			$rs_sql_check = mysqli_query($con,$sql_Check) or die(mysqli_error($con));
			if($row_user = mysqli_fetch_array($rs_sql_check)){
				  $result = $row_user['emp_lev_pkg_id'];
			}
			if($result == 0){
				$sql = "INSERT INTO quantsoft_emp_leave_package (employee_id,	leave_id,no_of_days) VALUES ('$leave_emp_id','$leave_id','$no_of_days')";
			}else{
				$sql = "UPDATE quantsoft_emp_leave_package SET no_of_days ='$no_of_days' WHERE emp_lev_pkg_id = $result";
			}
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sql_check);		
		mysqli_close($rs_sub);		
		mysqli_close($con);
}//
// get emp leave history 
function get_emp_leave_quota(){
	global $con;
		try{ 
			$sql = "SELECT * FROM quantsoft_emp_leave_package";
			$rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
				  $result = $result.$row_user['emp_lev_pkg_id'].'#@#'.$row_user['employee_id'].'#@#'.$row_user['leave_id'].'#@#'.$row_user['no_of_days'].'@@@@';
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//

// apply for leave
function apply_for_leave($id,$no_of_days,$from_date,$to_date,$leave_type_id,$leave_msg,$leave_incharge_id){
	global $con;
		try{
			$sql = "INSERT INTO quantsoft_emp_package (emp_id,no_of_days,from_date,to_date,	leave_type,leave_msg,approve_incharge,added_date) VALUES ('$id','$no_of_days','$from_date','$to_date','$leave_type_id','$leave_msg','$leave_incharge_id',NOW())";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}// function end 

// delete applied leave by employee 
function delete_leave_request($leave_id){
	global $con;
	try{
		$sql = "DELETE FROM quantsoft_emp_package WHERE leave_applied_id = '$leave_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} //

// leave request accept 
function leave_request_accept($id,$emp_id,$leave_id){
	global $con;
		try{
			$sql = "UPDATE quantsoft_emp_package SET approve_flag = '1', approved_by= '$id', seen_unseen_flag= '0'  WHERE leave_applied_id = '$leave_id' ";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}// 

// leave request reject 
function leave_request_reject($id,$emp_id,$leave_applied_id){
	global $con;
		try{
			
			$sql = "UPDATE quantsoft_emp_package SET approve_flag = '2', approved_by= '$id', seen_unseen_flag= '0' WHERE leave_applied_id = '$leave_applied_id' ";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}// 
// get emp leave history by id
function get_emp_leave_history($id){

	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_emp_package WHERE emp_id = '$id'";
				
			 $rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['leave_applied_id'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['no_of_days'].'#@#'.$row_user['from_date'].'#@#'.$row_user['to_date'].'#@#'.$row_user['leave_type'].'#@#'.$row_user['leave_msg'].'#@#'.$row_user['approve_flag'].'#@#'.$row_user['approved_by'].'#@#'.$row_user['added_date'].'@@@@';
					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//

// get all emp leave history 
function get_all_emp_leave_history(){

	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_emp_package";
				
			 $rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['leave_applied_id'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['no_of_days'].'#@#'.$row_user['from_date'].'#@#'.$row_user['to_date'].'#@#'.$row_user['leave_type'].'#@#'.$row_user['leave_msg'].'#@#'.$row_user['approve_flag'].'#@#'.$row_user['approved_by'].'#@#'.$row_user['added_date'].'@@@@';
					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//

/* QUANTSOFT EMPLOYEE DITECTORY */ 	
	
// get employee info details 

function get_emp_info_details(){

	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_employee";
				
			 $rs =mysqli_query($con,$sql) or die (mysqli_error($con));
			$result= '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['emp_id'].'#@#'.$row_user['emp_first_name'].'#@#'.$row_user['emp_last_name'].'#@#'.$row_user['emp_gender'].'#@#'.$row_user['email_id'].'#@#'.$row_user['emp_mobile'].'#@#'.$row_user['emp_blood_grp'].'#@#'.$row_user['emp_city'].'#@#'.$row_user['emp_state'].'#@#'.$row_user['emp_country'].'#@#'.$row_user['emp_pincode'].'#@#'.$row_user['emp_emges_cont_person_name'].'#@#'.$row_user['emp_emges_cont_no'].'#@#'.$row_user['emp_start_date'].'#@#'.$row_user['emp_title'].'#@#'.$row_user['emp_team'].'#@#'.$row_user['employee_quantsoft_id'].'#@#'.$row_user['emp_password'].'#@#'.$row_user['emp_access_type'].'#@#'.$row_user['emp_status'].'#@#'.$row_user['emp_deactivate_date'].'#@#'.$row_user['emp_dob'].'#@#'.$row_user['last_login'].'#@#'.$row_user['added_date'].'@@@@';
					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//

	
// Add Employee 

function add_new_quantsoft_emp_info($emp_id,$emp_first_name,$emp_last_name,$emp_gender,$emp_email_id,$emp_mobile_no,$emp_blood_grp,$emp_city,$emp_state,$emp_country,$emp_pincode,$emp_emges_cont_name,$emp_emges_cont_no,$emp_start_date,$emp_title,$emp_team,$employee_id,$emp_intial_password,$access_type,$emp_dob){
	global $con;
		try{
			if($emp_id==''){
			$sql = "INSERT INTO quantsoft_employee (emp_first_name,emp_last_name,emp_gender,email_id,emp_mobile,emp_blood_grp,emp_city,emp_state,emp_country,emp_pincode,emp_emges_cont_person_name,emp_emges_cont_no,emp_start_date,emp_title,emp_team,employee_quantsoft_id,emp_password,emp_access_type,emp_dob,added_date) VALUES ('$emp_first_name','$emp_last_name','$emp_gender','$emp_email_id','$emp_mobile_no','$emp_blood_grp','$emp_city','$emp_state','$emp_country','$emp_pincode','$emp_emges_cont_name','$emp_emges_cont_no','$emp_start_date','$emp_title','$emp_team','$employee_id','$emp_intial_password','$access_type','$emp_dob',NOW())";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			}else{
			$sql = " UPDATE quantsoft_employee SET emp_first_name='$emp_first_name',emp_last_name='$emp_last_name',emp_gender='$emp_gender',email_id='$emp_email_id',emp_mobile='$emp_mobile_no',emp_blood_grp='$emp_blood_grp',emp_city='$emp_city',emp_state='$emp_state',emp_country='$emp_country',emp_pincode='$emp_pincode',emp_emges_cont_person_name='$emp_emges_cont_name',emp_emges_cont_no='$emp_emges_cont_no',emp_start_date='$emp_start_date',emp_title='$emp_title',emp_team='$emp_team',employee_quantsoft_id='$employee_id',emp_password='$emp_intial_password',emp_access_type='$access_type',emp_dob='$emp_dob' WHERE emp_id = '$emp_id'";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));			
				
			}
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
} //

function delete_quantsoft_emp_info($emp_id){
	global $con;
	try{
		$sql = "UPDATE quantsoft_employee SET emp_status='0', emp_deactivate_date = NOW() WHERE emp_id = '$emp_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} // 

/* QUANTSOFT PROJECT DITECTORY */
// get project details

function get_proj_info_details(){

	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_projects";
				
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['project_id'].'#@#'.$row_user['project_no'].'#@#'.$row_user['project_name'].'#@#'.$row_user['start_date'].'#@#'.$row_user['project_allocated_hrs'].'#@#'.$row_user['project_status'].'#@#'.$row_user['proj_deactive_date'].'#@#'.$row_user['project_incharge'].'#@#'.$row_user['added_date'].'#@#'.$row_user['lable'].'@@@@';					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//

// add new project 
function add_new_quantsoft_project_info($project_id,$project_no,$project_name,$project_start_date,$project_allcated_hrs,$project_incharge){
		global $con;
		try{
			if($project_id == ''){
			$sql = "INSERT INTO quantsoft_projects (project_no,project_name,start_date,project_allocated_hrs,project_incharge,added_date) VALUES ('$project_no','$project_name','$project_start_date','$project_allcated_hrs','$project_incharge',NOW())";
			
			}else{
			$sql = "UPDATE quantsoft_projects SET project_no = '$project_no', project_name = '$project_name', start_date= '$project_start_date', project_allocated_hrs = '$project_allcated_hrs', project_incharge = '$project_incharge' WHERE project_id = '$project_id'" ;
			}
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
} //

// active project
function active_project($project_id){
	global $con;
		try{
			$sql = "UPDATE quantsoft_projects SET project_status = '1' WHERE project_id = '$project_id' ";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// deactive project
function deactive_project($project_id){
	global $con;
		try{
			$sql = "UPDATE quantsoft_projects SET project_status = '0', proj_deactive_date = NOW() WHERE project_id = '$project_id' ";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

/* CATEGORY */

// get category info 
function get_category_info(){
	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_proj_category";
				
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['category_id'].'#@#'.$row_user['category_name'].'#@#'.$row_user['added_date'].'@@@@';					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//


// add new category
function add_new_category($category_name){
		global $con;
		try{
			
			$sql = "INSERT INTO quantsoft_proj_category (category_name,added_date) VALUES ('$category_name',NOW())";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
} //

// edit category 
function edit_category($cat_id,$category_name){
	global $con;
		try{
			$sql = "UPDATE quantsoft_proj_category SET category_name = '$category_name' WHERE category_id = '$cat_id' ";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// delete category
function remove_category($cat_id){
	global $con;
	try{
		$sql = "DELETE FROM quantsoft_proj_category WHERE category_id = '$cat_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} //

// delete category the delete all sub category 
function remove_cat_sub_cat($cat_id){
	global $con;
	try{
		$sql = "DELETE FROM quantsoft_proj_sub_category WHERE category_id = '$cat_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} //

/* SUB CATEGORY */


// get sub category info 
function get_sub_category_info(){
	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_proj_sub_category";
				
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['sub_category_id'].'#@#'.$row_user['category_id'].'#@#'.$row_user['sub_category_name'].'#@#'.$row_user['added_date'].'@@@@';					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}	//


// add new SUB category
function add_new_sub_category($category_id,$sub_category_name){
		global $con;
		try{
			
			$sql = "INSERT INTO quantsoft_proj_sub_category (category_id,sub_category_name,added_date) VALUES ('$category_id','$sub_category_name',NOW())";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
} //
// edit sub category 
function edit_sub_category($sub_cat_id,$sub_category_name){
	global $con;
		try{
			$sql = "UPDATE quantsoft_proj_sub_category SET sub_category_name = '$sub_category_name' WHERE sub_category_id = '$sub_cat_id' ";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}//

// delete sub category
function remove_sub_category($sub_cat_id){
	global $con;
	try{
		$sql = "DELETE FROM quantsoft_proj_sub_category WHERE sub_category_id = '$sub_cat_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} //

/* TYPE OF LEAVE */

// get leave type info 
function get_leave_type_info(){
	global $con;
		try{ 
			
			$sql = "SELECT * FROM quantsoft_leave_types";
				
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
                  
				  $result = $result.$row_user['leave_id'].'#@#'.$row_user['leave_type_name'].'#@#'.$row_user['no_of_days'].'#@#'.$row_user['added_date'].'@@@@';					
			}
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//


// add new type of leave 
function add_new_leave_type($leave_type_name,$no_of_days){
		global $con;
		try{
			
			$sql = "INSERT INTO quantsoft_leave_types (leave_type_name,no_of_days,added_date) VALUES ('$leave_type_name','$no_of_days',NOW())";
			
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
} //

// delete leave type 
function delete_leave_type($leave_id){
	global $con;
	try{
		$sql = "DELETE FROM quantsoft_leave_types WHERE leave_id = '$leave_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} //

// delete leave type from employee leave package 
function delete_emp_leav($leave_id){
	global $con;
	try{
		$sql = "DELETE FROM quantsoft_emp_leave_package WHERE leave_id = '$leave_id'";
		$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
		if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
	}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
} //

// add emp attendance manualy by admin 
function add_manual_attendance($punching_code,$log_date,$log_time){
	global $con;
		try{
			$sql = "INSERT INTO tblt_timesheet (punchingcode,date,time,Tid) VALUES ('$punching_code','$log_date','$log_time','1')";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}// function end 
/*
// get emp attendance by id, year, and month
function get_emp_monthly_attendance($punching_code,$attendance_year,$attendance_month){
	global $con;
		try{ 
			$sql = "SELECT * FROM `tblt_timesheet` WHERE punchingcode = '$punching_code' AND EXTRACT(YEAR FROM date)= '$attendance_year' AND EXTRACT(MONTH FROM date)= '$attendance_month'";
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
				//0-4
				  $result = $result.$row_user['timesheetid'].'#@#'.$row_user['punchingcode'].'#@#'.$row_user['date'].'#@#'.$row_user['time'].'#@#'.$row_user['Tid'].'@@@@';
			}
			//echo $result;die;
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//
*/
// get emp attendance by id, year, and month
function get_emp_monthly_attendance($punching_code,$attendance_year,$attendance_month){
	global $con;
		try{ 
			$sql = "SELECT timesheetid,punchingcode,date, min(time) as in_time, max(time) as out_time FROM `tblt_timesheet` WHERE punchingcode = '$punching_code' AND EXTRACT(YEAR FROM date)= '$attendance_year' AND EXTRACT(MONTH FROM date)= '$attendance_month' GROUP BY date ORDER BY date";
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
				//0-4
				  $result = $result.$row_user['timesheetid'].'#@#'.$row_user['punchingcode'].'#@#'.$row_user['date'].'#@#'.$row_user['in_time'].'#@#'.$row_user['out_time'].'@@@@';
			}
			//echo $result;die;
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//


// get emp timesheet by id, year, and month
function get_emp_monthly_timesheet($emp_id,$timesheet_year,$timesheet_month){
	global $con;
		try{ 
			$sql = "SELECT * FROM `quantsoft_daily_timesheet` WHERE emp_id = '$emp_id' AND EXTRACT(YEAR FROM timesheet_date)= '$timesheet_year' AND EXTRACT(MONTH FROM timesheet_date)= '$timesheet_month'";
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
				//0-14
				   $result = $result.$row_user['sr_no'].'#@#'.$row_user['emp_id'].'#@#'.$row_user['timesheet_date'].'#@#'.$row_user['project_id'].'#@#'.$row_user['category_id'].'#@#'.$row_user['sub_category_id'].'#@#'.$row_user['drawing_no'].'#@#'.$row_user['model_no'].'#@#'.$row_user['timesheet_hrs'].'#@#'.$row_user['timesheet_min'].'#@#'.$row_user['timesheet_msg'].'#@#'.$row_user['added_date'].'#@#'.$row_user['timesheet_flag'].'#@#'.$row_user['checked_by'].'#@#'.$row_user['admin_msg'].'@@@@';
			}
			//echo $result;die;
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//

// get emp monthly attendance by id, year, and month 
/*
function get_emp_attendance($attendance_date){
	global $con;
		try{ 
			//$sql = "SELECT * FROM tblt_timesheet WHERE date = '$attendance_date' ";
			$sql = "select date,punchingcode,min(time) AS in_time ,max(time) AS out_time from tblt_timesheet where `date` = '2017-06-05' GROUP by punchingcode ORDER BY time ";
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
				//0-4
				  $result = $result.$row_user['timesheetid'].'#@#'.$row_user['punchingcode'].'#@#'.$row_user['date'].'#@#'.$row_user['time'].'#@#'.$row_user['Tid'].'@@@@';
			}
			//echo $result;die;
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//
*/

// get emp monthly attendance by id, year, and month 
function get_emp_attendance($attendance_date){
	global $con;
		try{ 
			$sql = "select timesheetid,date,punchingcode,min(time) AS in_time ,max(time) AS out_time from tblt_timesheet where DATE(`date`) = DATE('$attendance_date') GROUP by punchingcode ORDER BY time ";
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
				//0-4
				  $result = $result.$row_user['timesheetid'].'#@#'.$row_user['punchingcode'].'#@#'.$row_user['date'].'#@#'.$row_user['in_time'].'#@#'.$row_user['out_time'].'@@@@';
			}
			//echo $result;die;
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//


// get emp attendance by id
function get_emp_attendance_by_id($id){
	global $con;
		try{ 
			
			$sql = "SELECT *, min(time) as in_time, max(time) as out_time FROM `tblt_timesheet` WHERE punchingcode = (select cast(right(employee_quantsoft_id,2) as UNSIGNED) from quantsoft_employee where emp_id = $id)  GROUP BY date order by date DESC";
			
			echo $sql;
			$rs = mysqli_query($con,$sql) or die (mysqli_error($con));
			$result = '';
			while($row_user = mysqli_fetch_array($rs)){
				//0-4
				  $result = $result.$row_user['timesheetid'].'#@#'.$row_user['punchingcode'].'#@#'.$row_user['date'].'#@#'.$row_user['in_time'].'#@#'.$row_user['out_time'].'@@@@';
			}
			//echo $result;die;
			return $result;
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
}//
	
}//class end...
?>
