<?php
require_once('conn_obj.php');

class loginModule{

	//function loginModule(){}

	function getLoginInfo($username,$password){

		//$password = md5($pass);
		global $con;
		try{			
			$check_admin = mysqli_query($con,"SELECT * FROM quantsoft_admin WHERE email_id ='$username' AND password ='$password'") or die(mysqli_error());
			
			if(mysqli_num_rows($check_admin)>0) {
				//Login Successful
			
				$adminDetails = mysqli_fetch_assoc($check_admin);
				
			$_SESSION['SESS_USER_NAME'] = $adminDetails['first_name'].' '.$adminDetails['last_name'];
			$_SESSION['SESS_USER_EMAIL'] = $username;
			$_SESSION['SESS_DATE'] = $adminDetails['last_login'];	
			$_SESSION['SESS_USER_ID'] = $adminDetails['admin_id'];
			$_SESSION['SESS_USER_TYPE'] = "admin";

			$sql_log =  mysqli_query($con,"UPDATE quantsoft_admin SET last_login=NOW() WHERE email_id = '$username'") or die(mysqli_error());		
				return true;
			}
			else{

				 $salt = 'abcdefjhighklmnopqurstuzdfsjnsdn@!12314567809';
				 $password = $password.$salt;
				 $password = sha1($password);
				
				$check_employee = mysqli_query($con,"SELECT * FROM quantsoft_employee WHERE email_id = '$username' AND emp_password ='$password'") or die (mysqli_error());

				if(mysqli_num_rows($check_employee)>0){

				$employeeDetails = mysqli_fetch_assoc($check_employee);

				$_SESSION['SESS_USER_NAME'] = $employeeDetails['emp_first_name'].' '.$employeeDetails['emp_last_name'];
				$_SESSION['SESS_USER_EMAIL'] = $username;
				$_SESSION['SESS_DATE'] = $employeeDetails['last_login'];
				$_SESSION['SESS_USER_ID'] = $employeeDetails['emp_id'];
				$_SESSION['SESS_USER_ACCESS_TYPE'] = $employeeDetails['emp_access_type'];
				$_SESSION['SESS_USER_TYPE'] = "employee";
				
				$sql_log = mysqli_query($con,"UPDATE quantsoft_employee SET last_login = NOW() WHERE employee_quantsoft_id = '$username'") or die(mysqli_error());
				return true;
				}
				else{

				return false; 
				}
			}
		}
		catch(Exception $e){
			echo 'Caught exception: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($check);
		mysqli_close($con);
		//$Connect->close();
		//}
	}
}

?>