<?php
error_reporting(E_ALL);
require_once('conn_obj.php');

class dbSession{
 
    /***  Constructor of class
     **  @return void   */
    function dbSession(){
 
        // get session lifetime
        $this->sessionLifetime = get_cfg_var("session.gc_maxlifetime");
        // register the new handler
 
      //  session_set_save_handler(array(&$this, 'open'),array(&$this, 'close'),array(&$this, 'read'),array(&$this, 'write'), array(&$this, 'destroy'),array(&$this, 'gc'));
        register_shutdown_function('session_write_close');
        // start the session
        session_start(); 
     }
  
    /***  Custom open() function *
     *  @access private */
    function open($save_path, $session_name){
         return true; 
    }
 
    /***  Custom close() function*
	*  @access private*/
    function close(){
        return true;
    }
 
    /***  Custom read() function*
	*  @access private */
    function read($session_id){
	global $con;	
        // reads session data associated with the session id
        // but only if the HTTP_USER_AGENT is the same as the one who had previously written to this session
        // and if session has not expired
        $result = mysqli_query($con,"SELECT session_data FROM session_data WHERE session_id = '".$session_id."' AND http_user_agent = '".$_SERVER["HTTP_USER_AGENT"]."' AND   session_expire > '".time()."'");
 
        // if anything was found
        if (is_resource($result) && mysqli_num_rows($result) > 0) {
 
            // return found data
            $fields = mysqli_fetch_assoc($result) or die( mysqli_error($con));
            // don't bother with the unserialization - PHP handles this automatically
            return $fields["session_data"];
 
        }
 
        // if there was an error return an epmty string - this HAS to be an empty string
        return '';
 
    }
 
    /***  Custom write() function
     **  @access private   */
    function write($session_id, $session_data){
 global $con;
        // first checks if there is a session with this id
        $result = mysqli_query($con,"SELECT * FROM session_data WHERE session_id = '".$session_id."'") or die( mysqli_error($con));
 	
        // if there is
        if (mysqli_num_rows($result) > 0) {
 
            // update the existing session's data
            // and set new expiry time
            $result = mysqli_query($con,"UPDATE session_data SET session_data = '".$session_data."',session_expire = '".(time() + $this->sessionLifetime)."' WHERE session_id = '".$session_id."'") or die(mysqli_error($con));
 
            // if anything happened
            if (mysqli_affected_rows($con)) {
                return true;
            } 
        // if this session id is not in the database
        } else {
 
            // insert a new record
            $result = mysqli_query($con,"INSERT INTO session_data (session_id,http_user_agent,session_data,session_expire) VALUES ('".$session_id."','".$_SERVER["HTTP_USER_AGENT"]."','".$session_data."','".(time() + $this->sessionLifetime)."')") or die( mysqli_error($con));
 
            // if anything happened
            if (mysqli_affected_rows($con)) { 
                // return an empty string
                return ""; 
            } 
        } 
        // if something went wrong, return false
        return false; 
    }
 
    /***  Custom destroy() function
     **  @access private */
    function destroy($session_id){
        // deletes the current session id from the database
		global $con;
        $result = mysqli_query($con,"DELETE FROM session_data WHERE session_id = '".$session_id."'") or die( mysqli_error($con));
 
        // if anything happened
        if (mysqli_affected_rows($con)) {
            // return true
            return true; 
        }
 
        // if something went wrong, return false
        return false;
    }
 
    /***  Custom gc() function (garbage collector)
     **  @access private */
    function gc($maxlifetime){
 global $con;
        // it deletes expired sessions from database
        $result = mysqli_query($con,"DELETE FROM session_data WHERE session_expire < '".(time() - $maxlifetime)."'") or die( mysqli_error($con)); 
    } 
	
	  /***  Regenerates the session id.
     **  <b>Call this method whenever you do a privilege change!</b>
     **  @return void  */
    function regenerate_id(){
 
        // saves the old session's id
        $oldSessionID = session_id();
 
        // regenerates the id
        // this function will create a new session, with a new id and containing the data from the old session
        // but will not delete the old session
        session_regenerate_id();
 
        // because the session_regenerate_id() function does not delete the old session,
        // we have to delete it manually
        $this->destroy($oldSessionID); 
    }
 
    /***  Get the number of online users*
	*  This is not 100% accurate. It depends on how often the garbage collector is run
     **  @return integer     approximate number of users curently online */
    function get_users_online(){
 global $con;
        // counts the rows from the database
        $result = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(session_id) as count FROM session_data")) or die( mysqli_error($con));
 
        // return the number of found rows
        return $result["count"];
    }
 
}
?>