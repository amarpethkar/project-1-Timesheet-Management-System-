<?php
error_reporting(E_ALL ^ E_NOTICE);
//date_default_timezone_set('Asia/Kolkata');
//$login_time = date('Y-d-m h:i:s A');

$sid = session_id();

//
include_once('classes/session_query.php');
$session = new dbSession();
$session->regenerate_id();

//$session->open('',session_name("SESS_USER"));
$_SESSION['sessionid'] = session_id();
$session_id =$_SESSION['sessionid'];

/*if(empty($_SESSION['letters_code'] ) ||strcasecmp($_SESSION['letters_code'], $_POST['letters_code']) != 0){
    header("location: index.php?status=5");
	exit();

}else{ */

//echo "session".$session_id ;
include_once('classes/query_class.php');
$qc = new queryClass();

//echo "session".$session_id ;
include_once('classes/login_query.php');
$login = new loginModule();
//echo "login";

$username = $qc->clean($_REQUEST['username']);
$password = $qc->clean($_REQUEST['password']);

if($username!='' && $password!=''){
$valid_login_data = $login->getLoginInfo($username,$password);
//echo $valid_login_data." ".$username." ".$password;

	if($valid_login_data == true){		
		$session->write($session_id,$valid_login_data);
		//echo $valid_login_data." ".$username." ".$password;
		header("location: home.php");
		exit();
		
		}
	
	else {
	//Login failed
	//echo "error in login";
 header("location: index.php?status=1");
	exit();
	}
}
/*else {
//Query failed
header("location: index.php?status=2");
}*/
/*}*/
?>
