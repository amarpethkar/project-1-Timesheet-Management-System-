
	
	var dataTable = '<div class="modal-dialog" role="document" id="emp_add">\
        <div class="modal-content">\
          <div class="modal-body padding_15">\
            <h4 class="modal-title" id="exampleModalLabel">success</h4>\
            <button type="button" class="btn btn-primary"><i class="fa fa-check" aria-hidden="true"></i></button>\
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>\
            <p class="note_line">Note: .......</p>\
          </div>\
        </div>\
      </div>';
	
