// Today date creation 	
var curDate    = new Date();    
var curMonth   ='';    
var curdateVal ='';    
var curYear    ='';    
var todayDate  ='';
    curMonth   = curDate.getMonth()+1;
    curdateVal = curDate.getDate();
    curYear    = curDate.getFullYear();
    if(curdateVal<10){
    curdateVal = '0'+curdateVal;
    }
    if(curMonth<10){
    curMonth = '0'+curMonth;
    }
    todayDate = curYear+'-'+curMonth+'-'+curdateVal;
	
// auto call to leave notification admin

function startTimeLeaveNoti() {
 var total = getLeaveNotiCount(loginId); 
 //console.log(total);
    $('#leaveNotiCount').text(total);
  setTimeout(startTimeLeaveNoti, 600000);
}//

// auto call to timesheet approval notification admin
function startTimeTimShetNoti() {
 var totalTSA = getTimShetNotiCount(); 

    $('#timeesheetNotiCount').text(totalTSA);
  setTimeout(startTimeTimShetNoti, 600000);
}//


// auto call to timesheet disapproval notification employee
function startTimeTimShetNotiEmp() {
 var ts_dis_aprv_emp = getTimShetNotiEmpCount(); 
 //console.log(ts_dis_aprv_emp);
    $('#myLogDisAprvNoti').text(ts_dis_aprv_emp);
  setTimeout(startTimeTimShetNotiEmp, 600000);
}//

// auto call to leave notification emp 
function startTimeLeaveNotiEmp() {
 var total = getLeaveNotiCountEmp(); 
 //console.log(total);
    $('#leaveNotiEmpCount').text(total);
  setTimeout(startTimeLeaveNotiEmp, 600000);
}//


// create random password for employee 

function makeid()
{
    var initial_pass = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    for( var i=0; i <5; i++ ){
        initial_pass += possible.charAt(Math.floor(Math.random() * possible.length));
	}
    return initial_pass;
}

// function for navigation active start
function menuuse(loc1){
    var loc1 = loc1;
        for(var i=0; i<9; i++){
            if(loc1==i){
            $('#side_menu'+i).addClass('active');    
            }else{
                 $('#side_menu'+i).removeClass('active'); 
            }//else end
         }// end for loop
}
// function for navigation active end

// Analytics start 
function analytics(){
$('#loader').modal('show');
  get_project_info_details();
  project_productivity();
  
  var analyticsData = '';
  analyticsData = '  \
    <div class="analytics_full_width_div fullwraper greybgcolor padding_left_right_0">\
      <div class="analytics_main_div">\
        <div class="analytics_container">\
          <div class="full_width_left">\
            <div class="analytics_team_select">\
              <span class="team_lable_analytics">Project Name</span>\
              <select class="team_select_analytics" id="project_id" onchange="projectTotalTime();">\
                <option value="">-- Select Project --</option>';
				
				for(var i=0; i<quantsoftProjlist.length; i++){
					if(quantsoftProjlist[i][5] == '1'){
						analyticsData += '   <option value="'+quantsoftProjlist[i][0]+'">'+quantsoftProjlist[i][1]+'</option>';
					}
				}
             analyticsData += ' </select>\
            </div>\
          </div>';
		analyticsData += '<div style="height: 70px;"></div>';
        analyticsData += '<div class="analytics_div_50">\
              <div class="analytics_div_45 margin_left_10p analytics_white_bg">\
                <div class="row">\
                  <span class="dashboard_icon_wrap">\
                    <span class="dashboard_icon4"><i class="fa fa-clock-o" aria-hidden="true"></i></span>\
                    <span class="dashboard_icon_text4"> Approved Hours</span>\
                  </span>\
                </div>\
                <div class="row">\
                  <span class="dashboard_no4" id="projHrsUsed">'+hrsUtilised+'</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>';
      analyticsData += '  <div class="analytics_container">\
          <div class="analytics_div_75 height_400 margin_top_25 analytics_white_bg_member">\
            <p class="member_title">Deadline Projects</p>\
            <div class="thin_scroll analytics_side_scroll">\
              <table class="table margin_top_0 table-condensed">\
                <thead>\
                  <tr>\
                    <th class="analytics_table_head">Project ID</th>\
                    <th class="analytics_table_head">Project Name</th>\
                    <th class="analytics_table_head">Start Date</th>\
                    <th class="analytics_table_head">Hours Utilised</th>\
                  </tr>\
                </thead>\
                <tbody>';
				for (var i=0; i<quantsoftProjlist.length; i++){
				if(quantsoftProjlist[i][5] == '1'){
					var	hrs = '';
					var	min	= '';
					var y = '';
					var z = '';
					var l = '';
					var m = '';
					var totalHrs = quantsoftProjlist[i][4];
					var x = parseFloat(totalHrs/100);
					
					 analyticsData += '<tr>\
                    <td class="analytics_table_data">'+quantsoftProjlist[i][1]+'</td>\
                    <td class="analytics_table_data">'+quantsoftProjlist[i][2]+'</td>\
                    <td class="analytics_table_data">'+quantsoftProjlist[i][3]+'</td>';
					for(var j=0; j<projectProductivity.length; j++){
					
						if(quantsoftProjlist[i][0] == projectProductivity[j][0]){
							hrs = parseInt (projectProductivity[j][1]);
							min = parseInt (projectProductivity[j][2]);
						}
					}
					if(min>='60'){
						hr = parseInt(min/60); 
						hrs = parseInt(hrs + hr);
						min = (min%60);
					}
					y = parseFloat(hrs/x);
					z = parseInt(hrs%x);
					l = parseInt(totalHrs - hrs);
					m = parseFloat(l/x);
					
                  analyticsData += '  <td class="analytics_table_data">'+hrs+'h:'+min+'m</td>';
				  
                analyticsData += '</tr>';
				
				}
				}

             
           analyticsData += '</tbody>\
              </table>\
            </div>\
          </div>';
         analyticsData += ' <div class="analytics_div_24 height_400 analytics_white_bg_small margin_top_25">\
            <p class="low_cashflow_title">Individual Productivity</p>\
            <div class="thin_scroll analytics_side_scroll">\
              <table class="table margin_top_0 table-condensed">\
                <thead>\
                  <tr>\
                    <th class="analytics_table_head">Emp#</th>\
                    <th class="analytics_table_head">Name</th>\
                    <th class="analytics_table_head">Hours</th>\
                  </tr>\
                </thead>\
                <tbody id="individualProductivity" >';
				// individual productivity data here 
      analyticsData += '</tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
    </div>';
	  menuuse(3);// user use this fun for selection menu or bold the menu 
    $('#page_title').text('Analytics');
    $('#page_title').addClass('page_header');  
    $('#page_map').text('Quantsoft -- Analytics');
    $('#page_map').addClass('page_map');
    $('#main_all_content').html(analyticsData);  
    $(".thin_scroll").mCustomScrollbar();
	$('#loader').modal('hide');
	$('.modal-backdrop').modal('hide');
}//

// onchange project name to project time 
function projectTotalTime(){	 
	var project_id = $('#project_id').val();
	//alert(project_id);
	var hrsUtilised = 0;
	var minUtilised = 0;
	var projAllowedHrs = '';
	var dataTable  = '';
	if(project_id!=''){
		
		// to get totall hrs 
		for(var i=0; i<quantsoftProjlist.length; i++){
		
			if(project_id == quantsoftProjlist[i][0]){
			projAllowedHrs = quantsoftProjlist[i][4];
			dataTable  += '<span>'+projAllowedHrs+'</span>';
			}
		}
	}
	$('#projAlloedTime').html(dataTable);
	
	// to get hrs utilised 
	for(var i=0; i<empLogActivityInfo.length; i++){
		if(project_id == empLogActivityInfo[i][3] && empLogActivityInfo[i][12] == '1') {
				hrsUtilised =  parseInt(hrsUtilised+parseInt(empLogActivityInfo[i][8]));
				minUtilised =  parseInt(minUtilised+parseInt(empLogActivityInfo[i][9]));
				if(minUtilised>60){
							hr = parseInt(minUtilised/60);
							hrsUtilised = parseInt(hrsUtilised + hr );
							minUtilised = parseInt(minUtilised%60);
						
				}
				if(minUtilised == '60'){
					        hrsUtilised = parseInt(hrsUtilised + 1);
							minUtilised = 0;
				}
		}
	}
	
	$('#projHrsUsed').text(hrsUtilised+'h:'+minUtilised+'m'+'');
	
	
	// project wise individual productivity 
	empProjProductivityTest();
		
		var analyticsData = '';
		var emp_id 	  = '';
		var emp_fn	  = '';
		var emp_ln	  = '';
		
	for(var i=0; i<empProjProductivity.length; i++){
		var emp_hrs	  = '';
		var emp_min	  = '';
		if(empProjProductivity[i][3] == project_id){
			emp_id = empProjProductivity[i][0];
			emp_fn = empProjProductivity[i][1];
			emp_ln = empProjProductivity[i][2];
			emp_hrs = parseInt(emp_hrs + parseInt(empProjProductivity[i][4]));
			emp_min = parseInt(emp_min + parseInt(empProjProductivity[i][5]));
			
			if(emp_min>='60'){
				hr  = parseInt(emp_min/60);
				emp_hrs = parseInt(emp_hrs + hr);
				emp_min = parseInt(emp_min%60);
			}
			
			for(var j=0; j<quantsoftEmplist.length; j++){
				if(quantsoftEmplist[j][0] == emp_id){
					var emp_no = quantsoftEmplist[j][16];
				}
			}
			analyticsData += '   <tr >\
                    <td class="analytics_table_data">'+emp_no+'</td>\
                    <td class="analytics_table_data" id="empName">'+emp_fn+'&nbsp;'+emp_ln+'</td>\
                    <td class="analytics_table_data red_color">'+emp_hrs+'h:'+emp_min+'m</td>\
                  </tr>';
		}
	}
	$('#individualProductivity').html(analyticsData);
	
	
}// 
// Analytics end 


// Messages start 
function messages(){

  updateLeaveNotiEmp();
  	getUserAppliedLeaveInfo();
  var messagesData = '';
  messagesData = '\
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="messages();" class="top_nav_active link_pointer"><i class="fa fa-envelope" aria-hidden="true"></i> Inbox</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <input type="text" class="form-control search_box">\
          <span class="input-group-btn search_btn">\
            <button class="btn btn-default" type="button">\
              <i class="fa fa-search"></i>\
            </button>\
          </span>\
        </div>\
      </div>\
      <div class="table-responsive" id="enquiryTrackingViewingContainer">\
        <table class="table table-bordered table-hover">\
          <tbody class="table_body">\
		   <tr>\
              <td class="message_time unread_message">Message</td>\
              <td class="message_time unread_message">Status</td>\
              <td class="message_time unread_message">Date</td>\
            </tr>';
			
			for(var i=0; i<quantsoftEmpAppliedLeavelist.length; i++){
				if(quantsoftEmpAppliedLeavelist[i][1] == userProfile[0][0] && quantsoftEmpAppliedLeavelist[i][7] !='0'){
					
					messagesData += ' <tr class="link_pointer">\
						  <td class="message_subject">Applying for leave '+quantsoftEmpAppliedLeavelist[i][3]+' to '+quantsoftEmpAppliedLeavelist[i][4]+'</td>';
						  if(quantsoftEmpAppliedLeavelist[i][7] == '1'){
							messagesData += '<td class="message_subject ">Approve</td>';
						  }else{
							messagesData += '<td class="message_subject">Reject</td>';
						  }
						 messagesData += ' <td class="message_time">'+quantsoftEmpAppliedLeavelist[i][9]+'</td>\
						  </tr>';
				}
			}
           messagesData += '</tbody>\
        </table>\
      </div>\
    </div>';
    
  $('#page_title').text('Messages');
  $('#page_title').addClass('page_header');  
  $('#page_map').text('Quantsoft -- Messages -- Inbox');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(messagesData);  
}
// Messages end 


// Open Messages start 
/*
function openMessages(){
  var openMessagesData = '';
  openMessagesData = '\
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="messages();" class="top_nav_active link_pointer"><i class="fa fa-envelope" aria-hidden="true"></i> Inbox</a></li>\
        </ul>\
      </div>\
      <div class="" id="enquiryTrackingViewingContainer">\
        <p class="open_message_subject">This line will be for the subject of the mail.</p>\
        <p class="open_message_name"><img src="images/profilepicture.png" alt="Profile Pic" class="open_message_picture"> Prathamesh Deshmukh ( pdeshmukh@esyainnovations.com )</p>\
        <p class="open_message_time">Oct 20 (12:20 pm)</p>\
        <p class="open_message_line">This is the line content of the message. This is the line content of the message. This is the line content of the message. This is the line content of the message. This is the line content of the message. This is the line content of the message. This is the line content of the message. </p>\
        <div class="message_border"></div>\
      </div>\
    </div>\
';
  $('#page_title').text('Messages');
  $('#page_title').addClass('page_header');  
  $('#page_map').text('Quantsoft -- Messages -- Inbox');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(openMessagesData);  
}*/
// Open Messages end 

// Account Settings start
function accountSettings(){
  var accountSettingsData = '';
  accountSettingsData = '  \
    <div class="col-md-12 fullwraper margin_top_70">\
      <form method="post">\
        <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="old_password" name="old_password" required="required">\
              <label for="To">Old Password</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
          <div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="new_password" name="new_password" required="required">\
              <label for="To">New Password</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>\
		<input type="button" value="Save" class="btn save_btn" onclick="changePassword();">\
      </form>\
    </div>\
';
  $('#page_title').text('Account Settings');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Account Settings');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(accountSettingsData);
}//


function accountSettingsImg(){
  var accountSettingsDataImg = '';
  accountSettingsDataImg = '  \
    <div class="col-md-12 fullwraper margin_top_70">\
      <form method="post">\
	  <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="form_label margin_top_25 margin_left_14">Upload Profile Picture</span>\
              <input type="file" id="" required="required" class="padding_left_13 width_60 margin_top_25">\
            </div>\
          </div>\
        </div>\
      <input type="submit" value="Save" class="btn save_btn">\
      </form>\
    </div>\
';
  $('#page_title').text('Profile Settings');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Profile Settings');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(accountSettingsDataImg);
}
// Account Settings end 


// Timesheet Entry start
function timesheetEntry(){
	get_project_info_details();
	get_category_info();
  var timesheetEntryData = '';
  timesheetEntryData = '  \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="timesheetEntry();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Timesheet Entry</a></li>\
		  <li><a onclick="activityEntry();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Activity&nbsp;</a></li>\
          <li><a onclick="weeklyTimesheet();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> My Productivity&nbsp;(<span id="myLogDisAprvNoti" style="color:#f37434;">0</span>)</a></li>\
		  </ul>\
      </div>';
	  
     timesheetEntryData += ' <form name="daily_timesheet_entry" method="post">\
        <div class="row">\
          <div class="col-md-4">\
            <div class="week_display_timesheet">\
			  <input type="date" id="timesheet_entry_date" value="'+todayDate+'" class="timesheet_entry_date">\
            </div>\
          </div>\
        </div>';
		
     timesheetEntryData += '   <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="timesheet_select_category">Project No</span>\
              <select class="team_select_analytics" id="project_id" onchange="projectName();">\
                <option value="">- Select Project -</option>';
				for(var i=0; i<quantsoftProjlist.length; i++){	
				if(quantsoftProjlist[i][9] != 'activity'){
               timesheetEntryData += ' <option value="'+quantsoftProjlist[i][0]+'">'+quantsoftProjlist[i][1]+'</option>';
				}
				}
            timesheetEntryData += ' </select>\
            </div>\
          </div>';
		  
        timesheetEntryData += '  <div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <span class="timesheet_project_label">Project Name:</span>\
              <span class="timesheet_project_name" id="project_name"></span>\
            </div>\
          </div>\
        </div>';
		
    timesheetEntryData += '  <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="timesheet_select_category">Category</span>\
              <select class="team_select_analytics" id="project_category_id" onchange="projectCategory();">\
                <option value="">- Select Category -</option>';
				
				for(var i=0; i<quantsoftCategorylist.length; i++){					
               timesheetEntryData += ' <option value="'+quantsoftCategorylist[i][0]+'">'+quantsoftCategorylist[i][1]+'</option>';
                }
				
    timesheetEntryData += ' </select>\
            </div>\
          </div>';
		  
    timesheetEntryData += ' <div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <span class="timesheet_select_category">Sub Category</span>\
              <select class="team_select_analytics" id="project_sub_category_id">\
                <option value="">- Select Sub Category -</option>\
			  </select>\
          </div>\
        </div>';
		
		
      timesheetEntryData += '  <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="drawing_no" placeholder="Drawing Number">\
              <label for="To">Drawing Number</label>\
              <div class="bar"></div>\
            </div>\
          </div>';

		  
          timesheetEntryData += '<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="model_no" placeholder="Model Number">\
              <label for="To">Model Number</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
       timesheetEntryData += ' <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="time_label">Time</span>\
              <div class="width_30" id="selectTime">\
			  <select class="team_select_analytics" id="timesheet_hrs">\
                <option value="">Hrs.</option>\
                <option value="0">00</option>\
                <option value="1">01</option>\
                <option value="2">02</option>\
                <option value="3">03</option>\
                <option value="4">04</option>\
                <option value="5">05</option>\
                <option value="6">06</option>\
                <option value="7">07</option>\
                <option value="8">08</option>\
                <option value="9">09</option>\
                <option value="10">10</option>\
                <option value="11">11</option>\
                <option value="12">12</option>\
              </select>\
             </div>\
              <div class="width_30">\
                <select class="team_select_analytics" id="timesheet_min">\
                <option value="">Min.</option>\
                <option value="0">00</option>\
                <option value="15">15</option>\
                <option value="30">30</option>\
                <option value="45">45</option>\
              </select>\
              </div>\
            </div>\
          </div>';
		  
          timesheetEntryData += '<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="timesheet_msg" placeholder="Message">\
              <label for="To">Message</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
		
        timesheetEntryData += '<input type="hidden" id="sr_no" value="">\
		<input type="button" value="Submit" onclick="addDailyTimesheet();" class="btn save_btn">\
      </form>\
    </div>\
    ';
  $('#page_title').text('Timesheet Entry');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Timesheet Entry');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(timesheetEntryData);
  menuuse(1);
}

// onchange project id to project name 
function projectName(){
	
	var project_id = $('#project_id').val();
	var dataTable  = '';
	if(project_id!=''){
		
		for(var i=0; i<quantsoftProjlist.length; i++){
		
			if(project_id == quantsoftProjlist[i][0]){
				
			dataTable  += '<span>'+quantsoftProjlist[i][2]+'</span>';
			}
		}
	}
	$('#project_name').html(dataTable);
}

// on change category to sub category
function projectCategory(){
	
	var category_id = $('#project_category_id').val();
	var dataTable   = '<option value="">- Select Sub Category -</option>'; 	
	if(category_id!=''){
		
		for(var i=0; i<quantsoftSubCategorylist.length; i++){
			if(category_id == quantsoftSubCategorylist[i][1]){
				
				dataTable  += '<option value="'+quantsoftSubCategorylist[i][0]+'">'+quantsoftSubCategorylist[i][2]+'</option>'; 
			
			}
			
		}
		
	}
	$('#project_sub_category_id').html(dataTable);
}//


// Activity Entry start
function activityEntry(){
	get_project_info_details();
	get_category_info();
  var activityEntryData = '';
  activityEntryData = '  \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="timesheetEntry();" class=" link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Timesheet Entry</a></li>\
		  <li><a onclick="activityEntry();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Activity</a></li>\
          <li><a onclick="weeklyTimesheet();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> My Productivity&nbsp;(<span id="myLogDisAprvNoti" style="color:#f37434;">0</span>)</a></li>\
        </ul>\
      </div>';
	  
     activityEntryData += ' <form name="daily_timesheet_entry" method="post">\
        <div class="row">\
          <div class="col-md-4">\
            <div class="week_display_timesheet">\
			  <input type="date" id="timesheet_entry_date" value="'+todayDate+'" class="timesheet_entry_date">\
            </div>\
          </div>\
        </div>';
		
     activityEntryData += ' <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="timesheet_select_category">Activity</span>\
              <select class="team_select_analytics" id="activity_id">\
                <option value="">- Select Activity -</option>';
				for(var i=0; i<quantsoftProjlist.length; i++){		
				if(quantsoftProjlist[i][9] == 'activity'){
               activityEntryData += ' <option value="'+quantsoftProjlist[i][0]+'">'+quantsoftProjlist[i][1]+'</option>';
				}
				}
           
     activityEntryData += ' </select>\
            </div>\
          </div>';
		
       activityEntryData += ' <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="time_label">Time</span>\
              <div class="width_30" id="selectTime">\
			  <select class="team_select_analytics" id="timesheet_hrs">\
                <option value="">Hrs.</option>\
                <option value="0">00</option>\
                <option value="1">01</option>\
                <option value="2">02</option>\
                <option value="3">03</option>\
                <option value="4">04</option>\
                <option value="5">05</option>\
                <option value="6">06</option>\
                <option value="7">07</option>\
                <option value="8">08</option>\
                <option value="9">09</option>\
                <option value="10">10</option>\
                <option value="11">11</option>\
                <option value="12">12</option>\
              </select>\
             </div>\
              <div class="width_30">\
                <select class="team_select_analytics" id="timesheet_min">\
                <option value="">Min.</option>\
                <option value="0">00</option>\
                <option value="15">15</option>\
                <option value="30">30</option>\
                <option value="45">45</option>\
              </select>\
              </div>\
            </div>\
          </div>';
		  
          activityEntryData += '<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="textarea" id="timesheet_msg" placeholder="Message">\
              <label for="To">Message</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
        activityEntryData += '<input type="hidden" id="sr_no" value="">\
		<input type="button" value="Submit" onclick="addActivityTimesheet();" class="btn save_btn">\
      </form>\
    </div>\
    ';
  $('#page_title').text('Timesheet Entry');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Timesheet Entry');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(activityEntryData);
  menuuse(1);
}//

// Weekly Timesheet start 
function weeklyTimesheet(){
getEmpLogActivity();	
  var weeklyTimesheetData = '';
  weeklyTimesheetData = ' \
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="timesheetEntry();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Timesheet Entry</a></li>\
		      <li><a onclick="activityEntry();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Activity&nbsp;</a></li>\
          <li><a onclick="weeklyTimesheet();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> My Productivity&nbsp;(<span id="myLogDisAprvNoti" style="color:#f37434;">0</span>) </a></li>\
		    </ul>\
      </div>\
      <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="dark_color">Date</a></th>\
              <th class="table_heading"><a class="dark_color">Project #</a></th>\
              <th class="table_heading"><a class="dark_color">Project Name</a></th>\
              <th class="table_heading"><a class="dark_color">Productivity</a></th>\
              <th class="table_heading"><a class="dark_color">Status</a></th>\
              <th class="table_heading"><a class="dark_color">View</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		  var  user_id = userProfile[0][0];
		 
		  var count = empLogActivityInfo.length-1;
		   
		  for(var i=count; i>=0; i--){
			  if(empLogActivityInfo[i][1] == user_id){
			  var project_id = empLogActivityInfo[i][3];
			  var flag = empLogActivityInfo[i][12];
			  var proj_no   = '';
			  var proj_name = '';
			  for(var j=0; j<quantsoftProjlist.length; j++){
				  if(quantsoftProjlist[j][0] == project_id){
					  proj_no   = quantsoftProjlist[j][1];
					  proj_name = quantsoftProjlist[j][2];
				  }
			  }
			  
  weeklyTimesheetData += '<tr>\
              <td class="padding_top_10"><a class="timesheet_view_link">'+empLogActivityInfo[i][2]+'</a></td>\
              <td class="padding_top_10"><a class="timesheet_view_link">'+proj_no+'</a></td>\
              <td class="padding_top_10"><a class="timesheet_view_link">'+proj_name+'</a></td>\
              <td class="padding_top_10"><a class="timesheet_view_link">'+empLogActivityInfo[i][8]+'h.'+empLogActivityInfo[i][9]+'m</a></td>';
			  if(flag == '1'){
 weeklyTimesheetData += '<td class="padding_top_10"><a class="timesheet_view_link green_color">Approved</a></td>';				  
			  }else if(flag == '2'){
 weeklyTimesheetData += '<td class="padding_top_10"><a class="timesheet_view_link red_color">Disapproved</a></td>';				  
			  }else{
 weeklyTimesheetData += '<td class="padding_top_10"><a class="timesheet_view_link">Pendding</a></td>';				  
			  }
			  
  weeklyTimesheetData += '<td class="padding_top_10"><a class="timesheet_view_link green_color" title="View" onclick="viewtimesheetEmp('+empLogActivityInfo[i][0]+','+empLogActivityInfo[i][3]+');"><i class="fa fa-eye" aria-hidden="true"></i></a></td>';
				
				
  weeklyTimesheetData += '</tr>';
		  }}
  weeklyTimesheetData += '</tbody>\
        </table>\
      </div>\
    </div>\
	<div class="modal fade" id="viewtimesheetEmp" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
  $('#page_title').text('Weekly Timesheet');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Weekly Timesheet');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(weeklyTimesheetData);
}//

// onclick view timesheet employee 
function viewtimesheetEmp(sr_no,proj_id){
	var sr_no = sr_no;
	var proj_id = proj_id;
	
	var dataTable = '';

	dataTable += '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body display_table">\
            <div class="view_enquiry_header">';
			console.log(empLogActivityInfo);
		for(var x=0;x<empLogActivityInfo.length;x++){
			if(empLogActivityInfo[x][0] == sr_no){
				var sr_no      = empLogActivityInfo[x][0];
				var logdate    = empLogActivityInfo[x][2];
				var project_id = empLogActivityInfo[x][3];
				var cat_id     = empLogActivityInfo[x][4];
				var sub_cat_id = empLogActivityInfo[x][5];
				var drawing_no = empLogActivityInfo[x][6];
				var model_no   = empLogActivityInfo[x][7];
				var ttl_hr     = empLogActivityInfo[x][8];
				var ttl_min    = empLogActivityInfo[x][9];
				var msg        = empLogActivityInfo[x][10];				
				var status_flag= empLogActivityInfo[x][12];				
				var adminMsg   = empLogActivityInfo[x][14];
			}
		}// x for loop end 
		for(var l=0;l<quantsoftProjlist.length;l++){
			 if(proj_id == quantsoftProjlist[l][0]){
				var project_no   = quantsoftProjlist[l][1];
				var project_name = quantsoftProjlist[l][2];
			 }
		} // l for loop end 
		for(var m=0; m<quantsoftCategorylist.length; m++){
			 if(cat_id == quantsoftCategorylist[m][0]){
				var category_name = quantsoftCategorylist[m][1];
			 }
		}// m for loop end 
	
	   for(var n=0; n<quantsoftSubCategorylist.length; n++){
			 if(sub_cat_id == quantsoftSubCategorylist[n][0]){
				var subCategory_name = quantsoftSubCategorylist[n][2];
			 }
	   }// n for loop end 
	   
     dataTable += '<label class="view_enquiry_head_lable">'+logdate+'</label>\
                   </div>';	
		if(status_flag == 2 || status_flag == 0){
		dataTable += ' <div style="/*! align-content: space-between; */align-items: ;margin-left: 555px;margin-top: 15px;cursor: pointer;"><a onclick="editDailyTimesheet('+sr_no+','+project_id+');" class="green_color" title="Edit Log"><i class="fa fa-pencil" aria-hidden="true"></i></a></div>\
					';
		}
   				   
	 if(proj_id>4){			   
	 dataTable += ' <div class="border_div_1"></div>\
					<div class="width_50"><label class="view_label">Project ID :</label> <label class="view_label_input">'+project_no+'</label></div>';
	 }
	 if(proj_id>4){	
	 dataTable += ' <div class="width_50"><label class="view_label">Project Name :</label> <label      class="view_label_input">'+project_name+'</label></div>';
	 }else{
	 dataTable += ' <div class="width_50"><label class="view_label">Activity :</label> <label      class="view_label_input">'+project_name+'</label></div>';	 
	 }
	 if(proj_id>4){
	 dataTable += ' <div class="width_50"><label class="view_label">Category :</label> <label class="view_label_input">'+category_name+'</label></div>';
	 
	 dataTable += ' <div class="width_50"><label class="view_label">Sub Category :</label> <label class="view_label_input">'+subCategory_name+'</label></div>';
	 
	 dataTable += '	<div class="width_50"><label class="view_label">Drawing Number :</label> <label class="view_label_input">'+drawing_no+'</label></div>';
	 
	 dataTable += '	<div class="width_50"><label class="view_label">Model Number :</label> <label class="view_label_input">'+model_no+'</label></div>';
	 }
	 dataTable += '	<div class="width_50"><label class="view_label">Total Hours :</label> <label class="view_label_input">'+ttl_hr+'</label></div>';
			
	 dataTable += '	<div class="width_50"><label class="view_label">Total Minutes :</label> <label class="view_label_input">'+ttl_min+'</label></div>';
	
	 dataTable += '	<div class="width_100"><label class="view_label">Message :</label> <label class="view_label_input_message">'+msg+'</label></div>';
	 
	 dataTable += '	<div class="width_100"><label class="view_label">Admin Message :</label> <label class="view_label_input_message">'+adminMsg+'</label></div>';
				
    dataTable += '	<div class="width_100"><button type="button"  data-dismiss="modal" class="btn    save_btn_prod">Dismiss</buttont></div>\
		</div>\
        </div>\
      </div>';
	$('#viewtimesheetEmp').html(dataTable);
	$('#viewtimesheetEmp').modal('show');
}//

// edit daily timesheet 

function editDailyTimesheet(sr_no,proj_id){
	var proj_id					= proj_id;
	$('.modal-backdrop').remove();
	if(proj_id<5){
	activityEntry();
	
	var sr_no					= sr_no;
	var activity_id				='';
	var timesheet_entry_date	='';
	var	timesheet_hrs			='';
	var	timesheet_min			='';
	var	timesheet_msg			='';
	
	for(var i=0; i<empLogActivityInfo.length; i++){
		if(empLogActivityInfo[i][0] == sr_no){
			
			var activity_id				=empLogActivityInfo[i][3];
			var timesheet_entry_date	=empLogActivityInfo[i][2];
			var	timesheet_hrs			=empLogActivityInfo[i][8];
			var	timesheet_min			=empLogActivityInfo[i][9];
			var	timesheet_msg			=empLogActivityInfo[i][10];
		}
	}//
	
	$("#activity_id").val(activity_id);
	$("#timesheet_hrs").val(timesheet_hrs);
	$("#timesheet_min").val(timesheet_min);
	$("#timesheet_msg").val(timesheet_msg);
	$("#sr_no").val(sr_no);
	}else{
	timesheetEntry();	
	var sr_no					= sr_no;
	var project_id				='';
	var timesheet_entry_date	='';
	var	project_category_id		='';
	var	project_sub_category_id	='';
	var	drawing_no				='';
	var	model_no				='';
	var	timesheet_hrs			='';
	var	timesheet_min			='';
	var	timesheet_msg			='';

	for(var i=0; i<empLogActivityInfo.length; i++){
		if(empLogActivityInfo[i][0] == sr_no){
			
			var project_id				=empLogActivityInfo[i][3];
			var timesheet_entry_date	=empLogActivityInfo[i][2];
			var	project_category_id		=empLogActivityInfo[i][4];
			var	project_sub_category_id	=empLogActivityInfo[i][5];
			var	drawing_no				=empLogActivityInfo[i][6];
			var	model_no				=empLogActivityInfo[i][7];
			var	timesheet_hrs			=empLogActivityInfo[i][8];
			var	timesheet_min			=empLogActivityInfo[i][9];
			var	timesheet_msg			=empLogActivityInfo[i][10];
		}
	}
	
	var subCatOpt = '';
	for(var j=0; j<quantsoftSubCategorylist.length;j++){
		
		if(quantsoftSubCategorylist[j][0] == project_sub_category_id){
			subCatOpt = '<option value="'+quantsoftSubCategorylist[j][0]+'">'+quantsoftSubCategorylist[j][2]+'</option>';
		}
	}
	var projectName = '';	
	for(var k=0; k<quantsoftProjlist.length; k++){
		if(quantsoftProjlist[k][0] == project_id){
		 projectName = quantsoftProjlist[k][2];
		}
	}	
	
	$("#project_id").val(project_id);
	$("#project_name").text(projectName);
	$("#timesheet_entry_date").val(timesheet_entry_date);
	$("#project_category_id").val(project_category_id);
	$("#project_sub_category_id").html(subCatOpt);
	$("#drawing_no").val(drawing_no);
	$("#model_no").val(model_no);
	$("#timesheet_hrs").val(timesheet_hrs);
	$("#timesheet_min").val(timesheet_min);
	$("#timesheet_msg").val(timesheet_msg);
	
	$("#sr_no").val(sr_no);
	}
}//


// Weekly Timesheet end 



// My Package start 
function myPackage(){
 getEmpLeaveHistory();
 getEmpLeavesQuota();
  var myPackageData = '';
  myPackageData = ' \
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="myPackage();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> My Package</a></li>\
          <li><a onclick="leaveHistory();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Leave History </a></li>\
        </ul>\
      </div>\
      <div class="row margin_top_25">\
        <div class="communication_input card">\
          <div class="form-group left_div input-container">\
            <span class="lable_detail_mypackage">Employee ID:</span>\
            <span class="work_package_no_details">'+userProfile[0][17]+'</span>\
          </div>\
        </div>\
      </div>';
	  
     myPackageData += ' <div class="row margin_bottom_20">\
        <div class="communication_input card">\
          <div class="form-group left_div input-container">\
            <span class="lable_detail_mypackage">Employee Name:</span>\
            <span class="work_package_no_details">'+userProfile[0][1]+' '+userProfile[0][2]+'</span>\
          </div>\
        </div>\
      </div>';
	  
       myPackageData += '<div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Category</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Allotted</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Remaining</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		  for(var i=0; i<quantsoftLeaveTypelist.length; i++){
			  var totalUsedLeave = 0;
			  var remLeave = 0;
			  for(var j=0; j<empLeaveHistory.length;j++){
				  if(quantsoftLeaveTypelist[i][0] == empLeaveHistory[j][5] && empLeaveHistory[j][7] == '1' ){

					  totalUsedLeave = parseInt(totalUsedLeave + parseInt(empLeaveHistory[j][2]));
				  }
			  }
			  for(var k=0; k<quantsoftEmpleaveQuota.length;k++){
				  if(quantsoftEmpleaveQuota[k][1] == loginId && quantsoftLeaveTypelist[i][0] == quantsoftEmpleaveQuota[k][2]){
					 var allowedLeave =  quantsoftEmpleaveQuota[k][3];
					 remLeave = parseInt(allowedLeave - parseInt(totalUsedLeave));
				  }
			  }
			  
				  
          myPackageData += '  <tr>\
              <td class="padding_top_10">'+quantsoftLeaveTypelist[i][1]+'</td>\
              <td class="padding_top_10">'+allowedLeave+'</td>';
       myPackageData += '   <td class="padding_top_10">'+remLeave+'</td>';
            myPackageData += ' </tr>';
		  }
         myPackageData += ' </tbody>\
        </table>\
      </div>\
      <input type="button" class="btn apply_leave_btn" value="Apply Leave" data-toggle="modal" onclick="onClickApplyLeave()">\
    </div>\
    <div class="modal fade" id="apply_leave" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>'; // onclick apply leave 
	
  $('#page_title').text('My Package');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- My Package');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(myPackageData);
  menuuse(2);
}//

// onclick apply leave function 
function onClickApplyLeave(){
	var dataTable = '';
	dataTable  = '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body">\
            <div class="view_enquiry_header">\
              <label class="view_enquiry_head_lable">Apply Leave</label>\
            </div>';
			
			dataTable += ' <div class="full_width margin_top_25">\
              <div class="communication_input padding_left_right_20 card">\
                <div class="form-group input-container row">\
                  <span class="apply_leave_label">Leave Type</span>\
                  <select class="leave_type_select" id="leave_type_id" name="leave_type_id">\
                    <option value="">-- Leave Type --</option>';
					for(var i=0; i<quantsoftLeaveTypelist.length; i++){
                   dataTable += ' <option value="'+quantsoftLeaveTypelist[i][0]+'">'+quantsoftLeaveTypelist[i][1]+'</option>';
					}
                  dataTable += '</select>\
                </div>\
              </div>\
            </div>';
			
			dataTable += '<form name="apply_leave_form" method="POST">\
			<div class="full_width margin_top_25">\
              <div class="communication_input padding_left_right_20 card">\
                <div class="form-group input-container row">\
                  <span class="form_label">No. of Days</span>\
                  <input type="text" id="no_of_days" name="no_of_days" required="required" onchange="applyLeaveAlertMsg();" class="padding_left_13 width_60">\
                  <div class="bar width_60 margin_left_40p"></div>\
                </div>\
              </div>\
            </div>';
			
         dataTable += '   <div class="full_width margin_top_25">\
              <div class="communication_input padding_left_right_20 card">\
                <div class="form-group input-container row">\
                  <span class="form_label">From</span>\
                  <input type="date" id="from_date" name="from_date" value="'+todayDate+'" required="required" class="padding_left_13 width_60">\
                  <div class="bar width_60 margin_left_40p"></div>\
                </div>\
              </div>\
            </div>';
			
        dataTable += ' <div class="full_width margin_top_25">\
              <div class="communication_input padding_left_right_20 card">\
                <div class="form-group input-container row">\
                  <span class="form_label">To</span>\
                  <input type="date" id="to_date" name="to_date" value="'+todayDate+'" required="required" class="padding_left_13 width_60">\
                  <div class="bar width_60 margin_left_40p"></div>\
                </div>\
              </div>\
            </div>';
			
		dataTable += ' <div class="full_width margin_top_25">\
              <div class="communication_input padding_left_right_20 card">\
                <div class="form-group input-container row">\
                  <span class="apply_leave_label" id="leave_incharge_id_lable">Report to</span>\
                  <select class="leave_type_select" id="leave_incharge_id" name="leave_incharge_id">\
                    <option value="">-- Select Incharge --</option>';
					var length = adminProfile.length;
					for(var i=0; i<length-1; i++){
                   dataTable += ' <option value="'+adminProfile[i][0]+'">'+adminProfile[i][1]+'&nbsp;'+adminProfile[i][2]+'</option>';
					}
                  dataTable += '</select>\
                </div>\
              </div>\
            </div>';	
			
           dataTable += ' <div class="full_width margin_top_25">\
              <div class="communication_input padding_left_right_20 card">\
                <div class="form-group input-container">\
                  <input type="text" id="leave_msg" name="leave_msg" required="required">\
                  <label for="To" class="margin_left_5">Message</label>\
                  <div class="bar"></div>\
                </div>\
              </div>\
            </div>';
			
           dataTable += '<input type="button" value="Apply" onclick="applyLeave();" class="message_send">\
			</form>\
          </div>\
        </div>\
      </div>';
	$('#apply_leave').html(dataTable);
	$('#apply_leave').modal('show');
}//
// My Package end 

// My Package start 
function leaveHistory(){
	getUserAppliedLeaveInfo();
  var leaveHistoryData = '';
  leaveHistoryData = ' \
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="myPackage();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> My Package</a></li>\
          <li><a onclick="leaveHistory();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Leave History </a></li>\
        </ul>\
      </div>\
      <div class="table-responsive table_div" id="">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Leave Type</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">From</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Till</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Status</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">&nbsp;</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		  console.log(quantsoftEmpAppliedLeavelist);
		  for(var i=0; i<quantsoftEmpAppliedLeavelist.length;i++){
			  if(quantsoftEmpAppliedLeavelist[i][1] == loginId){
				  var leave_id = quantsoftEmpAppliedLeavelist[i][5];
				  for(var j=0;j<quantsoftLeaveTypelist.length;j++){
					  if(quantsoftLeaveTypelist[j][0] == leave_id){
						  var leave_type = quantsoftLeaveTypelist[j][1];
					  }
				  }//
				  
  leaveHistoryData += '<tr>\
              <td class="padding_top_10">'+leave_type+'</td>\
              <td class="padding_top_10">'+quantsoftEmpAppliedLeavelist[i][3]+'</td>\
              <td class="padding_top_10">'+quantsoftEmpAppliedLeavelist[i][4]+'</td>';
			
				if(quantsoftEmpAppliedLeavelist[i][7] == 1){
		  leaveHistoryData += '<td class="padding_top_10 green_color">Approved</td>';		
				}else if(quantsoftEmpAppliedLeavelist[i][7] == 2){
		  leaveHistoryData += '<td class="padding_top_10 red_color">Disapproved</td>';			
				}else{
		 leaveHistoryData += '<td class="padding_top_10">Pendding</td>';		
				} 
				if(quantsoftEmpAppliedLeavelist[i][7] != 0){
		  leaveHistoryData += '<td class="padding_top_10"><a onclick="viewLeaveHistory('+quantsoftEmpAppliedLeavelist[i][0]+');" class="calender_icon_link green_color link_pointer" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a></td>\
            </tr>';
				}else{
		leaveHistoryData += '<td class="padding_top_10"><a onclick="deleteApplyLeave('+quantsoftEmpAppliedLeavelist[i][0]+');" class="calender_icon_link red_color link_pointer" title="Delete"><i class="fa fa-times" aria-hidden="true"></i></a></td>\
            </tr>';
				}//	
			  }// 
		  }// end of i loop 
  leaveHistoryData += '</tbody>\
        </table>\
      </div>\
    </div>\
    <div class="modal fade" id="viewLeaveHistory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>'; // onclick view leave history 

  $('#page_title').text('Leave History');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- My Package -- Leave History');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(leaveHistoryData);
}//

// Attendance History  
function attendanceHistory(){
	getEmpAttendanceByIdAjax();
  var leaveHistoryData = '';
  leaveHistoryData = ' \
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="myPackage();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> My Package</a></li>\
          <li><a onclick="leaveHistory();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Leave History </a></li>\
          <li><a onclick="attendanceHistory();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Daily Attendance </a></li>\
        </ul>\
      </div>\
      <div class="table-responsive table_div" id="">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Date</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">In-Time</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Out-Time</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		  for(var i=0; i<quantsoftEmpAttendanceById.length;i++){	 
  leaveHistoryData += '<tr>\
              <td class="padding_top_10">'+quantsoftEmpAttendanceById[i][2]+'</td>\
              <td class="padding_top_10">'+formatAMPM(quantsoftEmpAttendanceById[i][3])+'</td>\
              <td class="padding_top_10">'+formatAMPM(quantsoftEmpAttendanceById[i][4])+'</td>\
            </tr>';
		  }// end of i loop 
  leaveHistoryData += '</tbody>\
        </table>\
      </div>\
    </div>';

  $('#page_title').text('Attendance History');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- My Package -- Attendance History');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(leaveHistoryData);
}//


// on click view leave history 
function viewLeaveHistory(leave_id) {
	var leave_id = leave_id;
	var dataTable = '';
	dataTable += '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body display_table">\
            <div class="view_enquiry_header">\
              <label class="view_enquiry_head_lable">Leave History</label>\
            </div>';
		for(var i=0; i<quantsoftEmpAppliedLeavelist.length;i++){
			if(quantsoftEmpAppliedLeavelist[i][0] == leave_id){
				var leave_type_id = quantsoftEmpAppliedLeavelist[i][5];
				var from_date     = quantsoftEmpAppliedLeavelist[i][3];
				var to_date       = quantsoftEmpAppliedLeavelist[i][4];
				var status_flag   = quantsoftEmpAppliedLeavelist[i][7];
				var msg 		  = quantsoftEmpAppliedLeavelist[i][6];		
			}
		}//
		for(var j=0;j<quantsoftLeaveTypelist.length;j++){
					  if(quantsoftLeaveTypelist[j][0] == leave_type_id){
						  var leave_type = quantsoftLeaveTypelist[j][1];
					  }
				  }//
   dataTable += '<div class="width_50"><label class="view_label">Leave Type :</label> <label class="view_label_input">'+leave_type+'</label></div>\
            <div class="width_50"><label class="view_label">From :</label> <label class="view_label_input">'+from_date+'</label></div>\
            <div class="width_50"><label class="view_label">Till :</label> <label class="view_label_input">'+to_date+'</label></div>';
			if(status_flag == 1){
   dataTable += '<div class="width_50"><label class="view_label">Status :</label> <label class="view_label_input">Approved</label></div>';				
			}else if(status_flag == 2){
   dataTable += '<div class="width_50"><label class="view_label">Status :</label> <label class="view_label_input">Disapproved</label></div>';				
			}else{
   dataTable += '<div class="width_50"><label class="view_label">Status :</label> <label class="view_label_input">Pendding</label></div>';				
			}
   
   dataTable += '<div class="width_100"><label class="view_label_notes"><span class="view_label_notes_label">Notes :</span> '+msg+'.</label></div>\
          </div>\
        </div>\
      </div>';
	$('#viewLeaveHistory').html(dataTable);
	$('#viewLeaveHistory').modal('show');
	
}//
// Leave History end 

// alert while applying leave 
function applyLeaveAlertMsg(){
	getEmpLeavesQuota();
	getEmpLeaveHistory();
	var no_of_days  	= $("#no_of_days").val();
	var leave_type_id  	= $("#leave_type_id").val();
	var totalLeave = 0; 
	var typeTotalLeave = 0;
	var count = 0;
	for(var i=0; i<quantsoftEmpleaveQuota.length; i++){
		if(leave_type_id == quantsoftEmpleaveQuota[i][2] && quantsoftEmpleaveQuota[i][1] == loginId){
			 typeTotalLeave = quantsoftEmpleaveQuota[i][3];
			//alert(typeTotalLeave);
			console.log(empLeaveHistory);
			 for(var j=0;j<empLeaveHistory.length;j++){
				 if(leave_type_id == empLeaveHistory[j][5] && empLeaveHistory[j][7] == '1' && empLeaveHistory[j][1] == loginId ){
					 totalLeave = parseInt(totalLeave + parseInt(empLeaveHistory[j][2]));
					 
				}
			 }
			//alert(totalLeave);
		}
	}
	count = parseInt(totalLeave + parseInt(no_of_days));
	if(count > typeTotalLeave){
		
		alert('Alert! You have crosed the leave quota. Please check your leave package and apply accodingly');
		$('#no_of_days').val('');
		$('#leave_type_id').prev('span').css('color','red');
		
	}
}// function end 

// Leave Approval start 
function leaveApproval(){
	$('#loader').modal('show');
	getUserAppliedLeaveInfo();
  var leaveApprovalData = '';
  leaveApprovalData = '\
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="leaveApproval();" class="top_nav_active link_pointer"><i class="fa fa-envelope" aria-hidden="true"></i> Leave Notification</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <input type="date" id="leaveSearchDate" class="form-control search_box" value="'+todayDate+'">\
          <span class="input-group-btn search_btn">\
            <button type="button" onclick="searchLeaveByDate();" class="btn btn-default" >\
              <i class="fa fa-search"></i>\
            </button>\
          </span>\
        </div>\
      </div';
    leaveApprovalData += ' <div class="scroll_div"> <div class="table-responsive" id="enquiryTrackingViewingContainer">\
        <table class="table table-bordered table-hover">\
          <tbody class="table_body">';
			for(var i=0; i<quantsoftEmpAppliedLeavelist.length; i++){
				if(quantsoftEmpAppliedLeavelist[i][7] == '0' && quantsoftEmpAppliedLeavelist[i][11] == loginId){
				var leave_applied_id = quantsoftEmpAppliedLeavelist[i][0];
				var emp_id = quantsoftEmpAppliedLeavelist[i][1];
				
          leaveApprovalData += '  <tr onclick="openLeaveMessages('+quantsoftEmpAppliedLeavelist[i][0]+');" class="link_pointer">';
		  for(var j=0; j<quantsoftEmplist.length; j++){
			  if(emp_id == quantsoftEmplist[j][0]){
           leaveApprovalData += ' <td class="messages_name unread_message"><img src="images/profilepicture.png" alt="Message Pic" class="messages_picture">'+quantsoftEmplist[j][1]+' '+quantsoftEmplist[j][2]+'</td>';
		  }}
           leaveApprovalData += '   <td class="message_subject unread_message">Applying for leave from <span>'+quantsoftEmpAppliedLeavelist[i][3]+'</span> to <span>'+quantsoftEmpAppliedLeavelist[i][4]+'</span></td>\
              <td class="message_time unread_message">'+quantsoftEmpAppliedLeavelist[i][9]+'</td>\
            </tr>';
			}}
			for(var i=0; i<quantsoftEmpAppliedLeavelist.length; i++){
				if(quantsoftEmpAppliedLeavelist[i][7] != '0' && quantsoftEmpAppliedLeavelist[i][11] == loginId){
					var leave_applied_id = quantsoftEmpAppliedLeavelist[i][0];
				    var emp_id = quantsoftEmpAppliedLeavelist[i][1];
					
		 leaveApprovalData += '	  <tr onclick="openLeaveMessagesRead('+quantsoftEmpAppliedLeavelist[i][0]+');" class="link_pointer">';
		  for(var j=0; j<quantsoftEmplist.length; j++){
			  if(emp_id == quantsoftEmplist[j][0]){
           leaveApprovalData += ' <td class="messages_name"><img src="images/profilepicture.png" alt="Message Pic" class="messages_picture">'+quantsoftEmplist[j][1]+' '+quantsoftEmplist[j][2]+'</td>\
              <td class="message_subject">Applying for leave from <span>'+quantsoftEmpAppliedLeavelist[i][3]+'</span> to <span>'+quantsoftEmpAppliedLeavelist[i][4]+'</span></td>\
              <td class="message_time">'+quantsoftEmpAppliedLeavelist[i][9]+'</td>\
            </tr>';
			}}}}
         leaveApprovalData += ' </tbody>\
        </table>\
      </div>\
	  </div>\
	  </div>\
';
  $('#page_title').text('Leave Approval');
  $('#page_title').addClass('page_header');  
  $('#page_map').text('Quantsoft -- Leave Approval');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(leaveApprovalData);  
  $(".scroll_div").mCustomScrollbar();
  menuuse(7);
  $('#loader').modal('hide');
  $('.modal-backdrop').modal('hide');
}//

// leave search by date 
function searchLeaveByDate(leaveSearchDate){
	
	var leaveSearchDate = $("#leaveSearchDate").val();

	getLeaveBySearchDate(leaveSearchDate);
	//getUserAppliedLeaveInfo();
  var leaveApprovalData = '';
  leaveApprovalData = '\
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="leaveApproval();" class="top_nav_active link_pointer"><i class="fa fa-envelope" aria-hidden="true"></i> Leave Notification</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <input type="date" id="leaveSearchDate" class="form-control search_box" value="'+todayDate+'">\
          <span class="input-group-btn search_btn">\
            <button type="button" onclick="searchLeaveByDate('+leaveSearchDate+');" class="btn btn-default" >\
              <i class="fa fa-search"></i>\
            </button>\
          </span>\
        </div>\
      </div';
    leaveApprovalData += ' <div class="scroll_div"> <div class="table-responsive" id="enquiryTrackingViewingContainer">\
        <table class="table table-bordered table-hover">\
          <tbody class="table_body">';
		  console.log(quantsoftEmpAppliedLeavelistByDate);
			for(var i=0; i<quantsoftEmpAppliedLeavelistByDate.length; i++){
				if(quantsoftEmpAppliedLeavelistByDate[i][7] == '0' && quantsoftEmpAppliedLeavelistByDate[i][11] == loginId ){
				var leave_applied_id = quantsoftEmpAppliedLeavelistByDate[i][0];
				var emp_id = quantsoftEmpAppliedLeavelistByDate[i][1];
				
          leaveApprovalData += '<tr onclick="openLeaveMessages('+quantsoftEmpAppliedLeavelistByDate[i][0]+');" class="link_pointer">';
		  for(var j=0; j<quantsoftEmplist.length; j++){
			  if(emp_id == quantsoftEmplist[j][0]){
           leaveApprovalData += ' <td class="messages_name unread_message"><img src="images/profilepicture.png" alt="Message Pic" class="messages_picture">'+quantsoftEmplist[j][1]+' '+quantsoftEmplist[j][2]+'</td>';
		  }}
           leaveApprovalData += '   <td class="message_subject unread_message">Applying for leave from <span>'+quantsoftEmpAppliedLeavelistByDate[i][3]+'</span> to <span>'+quantsoftEmpAppliedLeavelistByDate[i][4]+'</span></td>\
              <td class="message_time unread_message">'+quantsoftEmpAppliedLeavelistByDate[i][9]+'</td>\
            </tr>';
			 }// end if
		}// end for loop 
			for(var i=0; i<quantsoftEmpAppliedLeavelistByDate.length; i++){
				if(quantsoftEmpAppliedLeavelistByDate[i][7] != '0' && quantsoftEmpAppliedLeavelistByDate[i][11] == loginId){
					var leave_applied_id = quantsoftEmpAppliedLeavelistByDate[i][0];
				    var emp_id = quantsoftEmpAppliedLeavelistByDate[i][1];
					
		 leaveApprovalData += '	  <tr onclick="openLeaveMessagesRead('+quantsoftEmpAppliedLeavelistByDate[i][0]+');" class="link_pointer">';
		  for(var j=0; j<quantsoftEmplist.length; j++){
			  if(emp_id == quantsoftEmplist[j][0]){
           leaveApprovalData += ' <td class="messages_name"><img src="images/profilepicture.png" alt="Message Pic" class="messages_picture">'+quantsoftEmplist[j][1]+' '+quantsoftEmplist[j][2]+'</td>\
              <td class="message_subject">Applying for leave from <span>'+quantsoftEmpAppliedLeavelistByDate[i][3]+'</span> to <span>'+quantsoftEmpAppliedLeavelistByDate[i][4]+'</span></td>\
              <td class="message_time">'+quantsoftEmpAppliedLeavelistByDate[i][9]+'</td>\
            </tr>';
			}}}}
         leaveApprovalData += ' </tbody>\
        </table>\
      </div>\
	  </div>\
	  </div>\
';
  $('#page_title').text('Leave Approval');
  $('#page_title').addClass('page_header');  
  $('#page_map').text('Quantsoft -- Leave Approval');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(leaveApprovalData);  
  $(".scroll_div").mCustomScrollbar();
  menuuse(7);
}//
// Leave Approval end 


// Open Leave Messages start 
function openLeaveMessages(leave_applied_id){
	var leave_applied_id = leave_applied_id;
	//alert(leave_applied_id);
  var openLeaveMessagessData = '';
  openLeaveMessagessData = '\
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="leaveApproval();" class="top_nav_active link_pointer"><i class="fa fa-envelope" aria-hidden="true"></i> Leave Notification</a></li>\
        </ul>\
      </div>';
	  for(var i=0; i<quantsoftEmpAppliedLeavelist.length; i++){
		  var emp_id = quantsoftEmpAppliedLeavelist[i][1];
		
		  if(leave_applied_id == quantsoftEmpAppliedLeavelist[i][0]){
    openLeaveMessagessData += '  <div class="" id="enquiryTrackingViewingContainer">\
        <p class="open_message_subject">Applying for leave from <span>'+quantsoftEmpAppliedLeavelist[i][3]+'</span> to <span>'+quantsoftEmpAppliedLeavelist[i][4]+'</span></p>';
		for(var j=0; j<quantsoftEmplist.length; j++){
			if(emp_id == quantsoftEmplist[j][0]){
       openLeaveMessagessData += '  <p class="open_message_name"><img src="images/profilepicture.png" alt="Profile Pic" class="open_message_picture"> '+quantsoftEmplist[j][1]+' '+quantsoftEmplist[j][2]+' ( '+quantsoftEmplist[j][16]+' )</p>';
		}}
		
       openLeaveMessagessData +=' <p class="open_message_time">'+quantsoftEmpAppliedLeavelist[i][9]+'</p>\
        <p class="open_message_line">'+quantsoftEmpAppliedLeavelist[i][6]+'. </p>\
        <p class="open_message_line"><input type="hidden" id="emp_id" value="'+emp_id+'"><input type="hidden" id="leave_applied_id" value="'+leave_applied_id+'"><input type="button" class="btn leave_status_btn" value="Accept" onclick="leaveRequestAccept('+quantsoftEmpAppliedLeavelist[i][0]+');"> <input type="button" class="btn leave_status_btn" value="Reject" onclick="leaveRequestReject();"></p>\
        <div class="message_border"></div>\
      </div>';
	  }}
  openLeaveMessagessData += '  </div>\
';
  $('#page_title').text('Leave Approval');
  $('#page_title').addClass('page_header');  
  $('#page_map').text('Quantsoft -- Leave Approval');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(openLeaveMessagessData);  
}
// Open Leave Messages end 

// Open Leave Messages read start 
function openLeaveMessagesRead(leave_applied_id){
	var leave_applied_id = leave_applied_id;
	//alert(leave_applied_id);
  var openLeaveMessagessData = '';
  openLeaveMessagessData = '\
    <div class="col-md-12 fullwraper" style="background:#fff;">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="leaveApproval();" class="top_nav_active link_pointer"><i class="fa fa-envelope" aria-hidden="true"></i> Leave Notification</a></li>\
        </ul>\
      </div>';
	  for(var i=0; i<quantsoftEmpAppliedLeavelist.length; i++){
		  var emp_id = quantsoftEmpAppliedLeavelist[i][1];
		 
		  if(leave_applied_id == quantsoftEmpAppliedLeavelist[i][0]){
    openLeaveMessagessData += '  <div class="" id="enquiryTrackingViewingContainer">\
        <p class="open_message_subject">Applying for leave from <span>'+quantsoftEmpAppliedLeavelist[i][3]+'</span> to <span>'+quantsoftEmpAppliedLeavelist[i][4]+'</span></p>';
		for(var j=0; j<quantsoftEmplist.length; j++){
			if(emp_id == quantsoftEmplist[j][0]){
       openLeaveMessagessData += '  <p class="open_message_name"><img src="images/profilepicture.png" alt="Profile Pic" class="open_message_picture"> '+quantsoftEmplist[j][1]+' '+quantsoftEmplist[j][2]+' ( '+quantsoftEmplist[j][16]+' )</p>';
		}}
       openLeaveMessagessData +=' <p class="open_message_time">'+quantsoftEmpAppliedLeavelist[i][9]+'</p>\
        <p class="open_message_line">'+quantsoftEmpAppliedLeavelist[i][6]+'. </p>\
        <div class="message_border"></div>\
      </div>';
	  }}
  openLeaveMessagessData += '  </div>\
';
  $('#page_title').text('Leave Approval');
  $('#page_title').addClass('page_header');  
  $('#page_map').text('Quantsoft -- Leave Approval');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(openLeaveMessagessData);  
}
// Open Leave Messages read end 


// Settings start
function settings(){
	
  var settingsData = '';
  settingsData = '  \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="settings();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Category</a></li>\
          <li><a onclick="categoryList();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Category List</a></li>\
          <li><a onclick="leaveTypes();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Leave Types</a></li>\
          <li><a onclick="assignLeave();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Assign Leave</a></li>\
		  <li><a onclick="empLeaveQuota();" class="link_pointer"><i class="fa fa-briefcase" aria-hidden="true"></i> Emp. Leave Quota</a></li>\
        </ul>\
      </div>';
     settingsData += ' <form method="post">\
        <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="timesheet_select_category">Category</span>\
              <select class="team_select_settings" id="category_id" name="category_id">\
                <option value="">-Select Category-</option>';
				
				for(var i=0; i < quantsoftCategorylist.length; i++){
					
              settingsData += '  <option value="'+quantsoftCategorylist[i][0]+'">'+quantsoftCategorylist[i][1]+'</option>';
				}
            settingsData += '  </select>\
            </div>\
          </div>\
          <a href="#" class="add_row_link_category" data-toggle="modal" data-target="#addcategory" title="Add row"><i class="fa fa-plus" aria-hidden="true"></i></a>\
        </div>';
       settingsData += '<div id="add_more_sub_category"> <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="sub_category_name0" name="sub_category_name0" required="required">\
              <label for="To">Sub Category</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
          <a href="#" class="add_row_link_category" onclick="add_subcategory_row();" title="Add row"><i class="fa fa-plus" aria-hidden="true"></i></a>\
        </div>\
		</div>\
		<input type="hidden" id="count_sc" value="1">\
        <input type="button" value="Submit" class="btn save_btn" onclick="addSubCategoryRow();">\
      </div>\
    </form>';
    settingsData += ' <div class="modal fade" id="add_row" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
  settingsData += '  <div class="modal fade" id="addcategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">\
      <div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body">\
          <form name="category_form" method="POST">\
            <div class="form-group">\
              <label for="recipient-name" class="addCategoryLabel">New Category :</label>\
              <input type="text" id="category_name" name="category_name" placeholder="Enter New Category Name" class="form-control addCategoryText">\
            </div>\
            <input type="button" value="Add" onclick="addNewCategory();" class="btn btn-primary addCategorybtn">\
          </form>\
          </div>\
        </div>\
      </div>\
    </div>\
';
  $('#page_title').text('Settings');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Settings -- Add Category');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(settingsData);
  menuuse(8);
}
// Settings End


// Leave type start
function leaveTypes(){
  var leaveTypesData = '';
  leaveTypesData = '  \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="settings();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Category</a></li>\
          <li><a onclick="categoryList();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Category List</a></li>\
          <li><a onclick="leaveTypes();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Leave Types</a></li>\
          <li><a onclick="assignLeave();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Assign Leave</a></li>\
		  <li><a onclick="empLeaveQuota();" class="link_pointer"><i class="fa fa-briefcase" aria-hidden="true"></i> Emp. Leave Quota</a></li>\
        </ul>\
      </div>\
      <div class="row margin_top_25">\
        <div class="col-md-3">\
          <div class="table-responsive">\
            <table class="table">\
              <thead class="table_header">\
                <tr>\
                  <th class="table_heading">Leave Types</a></th>\
                  <th class="table_heading">No. of Days</a></th>\
                  <th class="table_heading">&nbsp;</a></th>\
                </tr>\
              </thead>\
				<tbody class="table_body">';
				for(var i=0; i < quantsoftLeaveTypelist.length; i++){
    leaveTypesData += ' <tr>\
                  <td>'+quantsoftLeaveTypelist[i][1]+'</td>\
				  <td>'+quantsoftLeaveTypelist[i][2]+'</td>\
                  <td><a class="table_icon red_color" onclick="leaveTypeDeleteMsg('+quantsoftLeaveTypelist[i][0]+');" title="Terminate"><i class="fa fa-times" aria-hidden="true"></i></a></td>\
                </tr>';
				}
    leaveTypesData += '<tr>\
                  <td class="padding_side_0 padding_bottom_0"><a href="#" class="add_category_link addCategoryLink" data-toggle="modal" data-target="#addLeave">+ ADD LEAVE TYPE</a></td>\
                  <td>&nbsp;</td>\
                  <td>&nbsp;</td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>';
// add new leave type 
   leaveTypesData += ' <div class="modal fade" id="addLeave" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">\
        <div class="modal-dialog" role="document">\
          <div class="modal-content">\
            <div class="modal-body">\
            <form name="leave_form" method="POST">\
              <div class="form-group">\
                <label for="recipient-name" class="addCategoryLabel">New Leave Type :</label>\
                <input type="text" id="leave_type_name" name="leave_type_name" placeholder="Enter New Leave Type" class="form-control addCategoryText">\
                <input type="text" id="no_of_days" name="no_of_days" placeholder="Enter Number of Days" class="form-control addCategoryText">\
              </div>\
              <input type="button" value="Add" onclick="addLeaveType();" class="btn btn-primary addCategorybtn">\
            </form>\
            </div>\
          </div>\
        </div>\
      </div>\
	<div class="modal fade" id="terminate_confirm_settings" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
	
  $('#page_title').text('Settings');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Settings -- Leave Types');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(leaveTypesData);
}
// Leave type End

// Category List start
function categoryList(){
	get_category_info();
	get_sub_category_info();
  var categoryListData = '';
  categoryListData = '  \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="settings();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Category</a></li>\
          <li><a onclick="categoryList();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Category List</a></li>\
          <li><a onclick="leaveTypes();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Leave Types</a></li>\
          <li><a onclick="assignLeave();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Assign Leave</a></li>\
		  <li><a onclick="empLeaveQuota();" class="link_pointer"><i class="fa fa-briefcase" aria-hidden="true"></i> Emp. Leave Quota</a></li>\
        </ul>\
      </div>\
      <div class="row margin_top_25">\
        <div class="col-md-4">\
          <div class="table-responsive">\
            <table class="table">\
              <thead class="table_header">\
                <tr>\
                  <th class="table_heading">Types</th>\
                  <th class="table_heading">&nbsp;</th>\
                  <th class="table_heading">&nbsp;</th>\
                </tr>\
              </thead>\
              <tbody class="table_body">';
			for(var i=0;i<quantsoftCategorylist.length;i++){
				var c_count = i+1;
   categoryListData += '<tr>\
                  <td><span class="list_main_category">'+c_count+'.&nbsp;'+quantsoftCategorylist[i][1]+'</span></td>\
                  <td><a class="table_icon green_color link_pointer" onclick="onClickEditCategort('+quantsoftCategorylist[i][0]+');" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a></td>\
                  <td><a class="table_icon red_color link_pointer" title="Remove" onclick="categoryTypeDeleteMsg('+quantsoftCategorylist[i][0]+');"><i class="fa fa-times" aria-hidden="true"></i></a></td>\
                </tr>';
			
			for(var j=0;j<quantsoftSubCategorylist.length;j++){
				
				if(quantsoftCategorylist[i][0] == quantsoftSubCategorylist[j][1]){
   categoryListData += '<tr>\
                  <td><span class="list_sub_category">'+quantsoftSubCategorylist[j][2]+'</span></td>\
                  <td><a class="table_icon green_color link_pointer" onclick="editSubCategort('+quantsoftSubCategorylist[j][0]+');" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a></td>\
                  <td><a class="table_icon red_color link_pointer" title="Terminate" onclick="subCategoryTypeDeleteMsg('+quantsoftSubCategorylist[j][0]+');"><i class="fa fa-times" aria-hidden="true"></i></a></td>\
                </tr>';
				}// 
			}// sub category for loop end 
			}// category for loop end 
   categoryListData += '</tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div class="modal fade" id="main_category_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">\</div>';// on click category edit 
	  
   categoryListData += '<div class="modal fade" id="delete_category" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';// delete popup
   
   categoryListData += ' <div class="modal fade" id="sub_category_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div></div>';// onclick sub category edit 
   
   categoryListData += '<div class="modal fade" id="delete_sub_category" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';// delete popup  
  
  $('#page_title').text('Category List');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Settings -- Category List');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(categoryListData);
}// 

// Assign Leave start
function assignLeave(){
	getEmpLeavesQuota();
	console.log(quantsoftEmpleaveQuota);
  var assignLeaveData = '';
  assignLeaveData = '\
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="settings();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Category</a></li>\
          <li><a onclick="categoryList();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Category List</a></li>\
          <li><a onclick="leaveTypes();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Leave Types</a></li>\
          <li><a onclick="assignLeave();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Assign Leave</a></li>\
		  <li><a onclick="empLeaveQuota();" class="link_pointer"><i class="fa fa-briefcase" aria-hidden="true"></i> Emp. Leave Quota</a></li>\
        </ul>\
      </div>\
      <div class="row">\
        <form action="" class="form_border" method="">\
          <div class="col-md-2">\
            <span class="span_label" id="emp_name_atAddLeave"></span>\
          </div>\
          <div class="col-md-4">\
            <select class="team_select_analytics_leave" id="leave_id">\
              <option value="">- Select Leave Type -</option>';
			  for(var j=0; j<quantsoftLeaveTypelist.length;j++){
 assignLeaveData += '<option value="'+quantsoftLeaveTypelist[j][0]+'">'+quantsoftLeaveTypelist[j][1]+'</option>';				  
			  }
 assignLeaveData += '</select>\
          </div>\
          <div class="col-md-4">\
            <div class="communication_input card">\
              <div class="form-group input-container row">\
                <input type="number" id="no_of_days" name="no_of_days" required="required" class="padding_left_13 width_31 margin_top_6">\
                <div class="bar width_31"></div>\
				<input type="hidden" value="" id="leave_emp_id">\
                <input type="button" value="Assign" onclick="assignLeaveToEmp();" class="submit_btn_leave">\
              </div>\
            </div>\
          </div>\
        </form>\
      </div>\
      <div class="row margin_top_25">\
        <div class="table-responsive">\
          <div class="table_height">\
            <table class="table">\
              <thead class="table_header">\
                <tr>';
   assignLeaveData += '<th class="table_heading">Employee ID</th>\
                  <th class="table_heading">Employee Name</th>';
				for(var k=0; k<quantsoftLeaveTypelist.length;k++){
   assignLeaveData += '<th class="table_heading">'+quantsoftLeaveTypelist[k][1]+'</th>';					
				} 
  assignLeaveData += '<th class="table_heading">&nbsp;</th>\
                </tr>\
              </thead>\
              <tbody class="table_body">';
			for(var i=0;i<quantsoftEmplist.length;i++){  
  assignLeaveData += '<tr>\
                  <td><span class="">'+quantsoftEmplist[i][16]+'</span></td>\
                  <td><span class="">'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</span></td>';
				  
		  for(var l=0; l<quantsoftLeaveTypelist.length;l++){
			  for(var m=0;m<quantsoftEmpleaveQuota.length;m++){
				  if(quantsoftLeaveTypelist[l][0] == quantsoftEmpleaveQuota[m][2] && quantsoftEmpleaveQuota[m][1] == quantsoftEmplist[i][0]){
assignLeaveData += '<td><span class="">'+quantsoftEmpleaveQuota[m][3]+'</span></td>';
				  }
			  }// end of m for loop 
		}// end of l for loop 
                  
  assignLeaveData += '<td><span class=""><a class="link_pointer green_color" onclick="addLeaveQuota('+quantsoftEmplist[i][0]+');"><i class="fa fa-plus" aria-hidden="true"></i></a></span></td>\
                </tr>';
			}
  assignLeaveData += '</tbody>\
            </table>\
          </div>\
        </div>\
        </div>\
      </div>';
  $('#page_title').text('Assign Leave');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Settings -- Assign Leave');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(assignLeaveData);
  $(".table_height").mCustomScrollbar();
}//

// onclick add leave quota 
function addLeaveQuota(emp_id){
	var emp_id = emp_id;
		for(var i=0;i<quantsoftEmplist.length;i++){  
			if(quantsoftEmplist[i][0] == emp_id){
				var f_name = quantsoftEmplist[i][1];
				var l_name = quantsoftEmplist[i][2];
				var emp_name = quantsoftEmplist[i][1]+" "+quantsoftEmplist[i][2];
				}
		}//
	$("#emp_name_atAddLeave").html(emp_name);
	$("#leave_emp_id").val(emp_id);
}//
// Assign Leave end 


// Assign Leave start
function empLeaveQuota(){
	getEmpLeavesQuota();
	getAllEmpLeaveHistory();
  var assignLeaveData = '';
  assignLeaveData = '\
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="settings();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Category</a></li>\
          <li><a onclick="categoryList();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Category List</a></li>\
          <li><a onclick="leaveTypes();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Leave Types</a></li>\
          <li><a onclick="assignLeave();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Assign Leave</a></li>\
		  <li><a onclick="empLeaveQuota();" class="top_nav_active link_pointer"><i class="fa fa-briefcase" aria-hidden="true"></i> Emp. Leave Quota</a></li>\
        </ul>\
      </div>\
      <div class="row margin_top_25">\
        <div class="table-responsive">\
          <div class="table_height">\
            <table class="table">\
              <thead class="table_header">\
                <tr>';
   assignLeaveData += '<th class="table_heading">Employee ID</th>\
                  <th class="table_heading">Employee Name</th>';
				  // dynamic leave list
				for(var k=0; k<quantsoftLeaveTypelist.length;k++){
   assignLeaveData += '<th class="table_heading">'+quantsoftLeaveTypelist[k][1]+'</th>';					
				} 
  assignLeaveData += '</tr>\
              </thead>\
              <tbody class="table_body">';
			for(var i=0;i<quantsoftEmplist.length;i++){  
  assignLeaveData += '<tr>\
                  <td><span class="">'+quantsoftEmplist[i][16]+'</span></td>\
                  <td><span class="">'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</span></td>';
				  
		  for(var l=0; l<quantsoftLeaveTypelist.length;l++){
			  for(var m=0;m<quantsoftEmpleaveQuota.length;m++){
				  if(quantsoftLeaveTypelist[l][0] == quantsoftEmpleaveQuota[m][2] && quantsoftEmpleaveQuota[m][1] == quantsoftEmplist[i][0]){
				  var assg_leave = quantsoftEmpleaveQuota[m][3];
				  
				  //
			  var totalUsedLeave = 0;
			  var remLeave = 0;
			  for(var j=0; j<allEmpLeaveHistory.length;j++){
				  if(quantsoftLeaveTypelist[l][0] == allEmpLeaveHistory[j][5] && allEmpLeaveHistory[j][7] == '1' && quantsoftEmplist[i][0] == allEmpLeaveHistory[j][1] ){

				  totalUsedLeave = parseInt(totalUsedLeave + parseInt(allEmpLeaveHistory[j][2]));
					 
				  }
			  }
			  remLeave = parseInt(assg_leave) - parseInt(totalUsedLeave);
			  
				  //
assignLeaveData += '<td><span class="">'+assg_leave+' | '+remLeave+'</span></td>';
				  }
			  }// end of m for loop 
		}// end of l for loop 
                  
  assignLeaveData += '</tr>';
			}
  assignLeaveData += '</tbody>\
            </table>\
          </div>\
        </div>\
        </div>\
      </div>';
  $('#page_title').text('Emp. Leave Quota');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Settings -- Emp. Leave Quota');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(assignLeaveData);
  $(".table_height").mCustomScrollbar();
}//


// onclick edit category 
function onClickEditCategort(cat_id){
	var cat_id    = cat_id;

	var dataTable = '';
  dataTable =' <div class="modal-dialog" role="document">\
          <div class="modal-content">\
            <div class="modal-body">\
            <form name="" method="POST">\
              <div class="form-group">\
                <label for="recipient-name" class="addCategoryLabel">Edit Main Category :</label>\
                <input type="text" id="category_name" name="category_name" class="form-control addCategoryText">\
              </div>\
              <input type="button" value="Save" onclick="editCategory('+cat_id+');" class="btn btn-primary addCategorybtn">\
            </form>\
            </div>\
          </div>\
        </div>';
	$('#main_category_edit').html(dataTable);
	$('#main_category_edit').modal('show');
	
}//

// onclick delete category
function categoryTypeDeleteMsg(cat_id){
	  var cat_id = cat_id;
	  var dataTable = '';
       dataTable = ' <div class="modal-dialog" role="document">\
				<div class="modal-content">\
					<div class="modal-body padding_15">\
					  <h4 class="modal-title" id="exampleModalLabel">Do you want to remove this Category Type?<br>It will also remove all Sub-Category too!</h4>\
					  <button type="button" class="btn btn-primary" onclick="delete_category_type('+cat_id+');"><i class="fa fa-check" aria-hidden="true"></i></button>\
					  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>\
					</div>\
				 </div>\
			  </div>';
	$('#delete_category').html(dataTable);
	$('#delete_category').modal('show');	
}//

// onclick edit sub category
function editSubCategort(sub_cat_id){
	var sub_cat_id = sub_cat_id;
	
	var dataTable = '';
  dataTable =' <div class="modal-dialog" role="document">\
          <div class="modal-content">\
            <div class="modal-body">\
            <form name="" method="POST">\
              <div class="form-group">\
                <label for="recipient-name" class="addCategoryLabel">Edit Sub-Category :</label>\
                <input type="text" id="sub_category_name" name="sub_category_name" class="form-control addCategoryText">\
              </div>\
              <input type="button" value="Save" onclick="editSubCategory('+sub_cat_id+');" class="btn btn-primary addCategorybtn">\
            </form>\
            </div>\
          </div>\
        </div>';
	$('#sub_category_edit').html(dataTable);
	$('#sub_category_edit').modal('show');
	
}//

// onclick delete sub category
function subCategoryTypeDeleteMsg(sub_cat_id){
	  var sub_cat_id = sub_cat_id;
	  var dataTable = '';
       dataTable = ' <div class="modal-dialog" role="document">\
				<div class="modal-content">\
					<div class="modal-body padding_15">\
					  <h4 class="modal-title" id="exampleModalLabel">Do you want to remove this Sub-Category Type?</h4>\
					  <button type="button" class="btn btn-primary" onclick="delete_sub_category_type('+sub_cat_id+');"><i class="fa fa-check" aria-hidden="true"></i></button>\
					  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>\
					</div>\
				 </div>\
			  </div>';
	$('#delete_sub_category').html(dataTable);
	$('#delete_sub_category').modal('show');	
}//
// Category List End


// Project Directory start 
function projectDirectory(){
	
  var projectDirectoryData = '';
  projectDirectoryData = ' \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="projectDirectory();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Project Directory</a></li>\
          <li><a onclick="addProject();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Projects</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <input type="text" id="search_proj_id" class="form-control search_box" placeholder="Search By Project ID (Case Sensitive)">\
          <span class="input-group-btn search_btn">\
            <button class="btn btn-default" type="button" onclick="searchByProjectId();">\
              <i class="fa fa-search"></i>\
            </button>\
          </span>\
        </div>\
      </div>';
  projectDirectoryData += '<div class="scroll_div"> <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Start Date</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Project ID</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Project/Activity</a></th>\
			  <th class="table_heading"><a class="link_pointer dark_color">Project Incharge</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Hours Utilised</th>\
              <th class="table_heading"><a class="link_pointer dark_color">Deactivation Date</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Project Status</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">&nbsp;</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		  //console.log(projectProductivity);
					
			for(var i=0; i < quantsoftProjlist.length; i++){
				var flag = quantsoftProjlist[i][5];
				var ttlTime = quantsoftProjlist[i][4];
				var prjIncharge = quantsoftProjlist[i][7];
				
				for (var p=0; p<adminProfile.length; p++){
					if(prjIncharge == adminProfile[p][0]){
						var inchargeName = adminProfile[p][1]+'&nbsp;'+adminProfile[p][2];
					}
				}// end for 
				
				var hrs = '';
			    var min = '';
				var hr = 0;
				
				for(var j=0; j<projectProductivity.length; j++){
					if(projectProductivity[j][0] == quantsoftProjlist[i][0]){
						hrs =  parseInt(projectProductivity[j][1]);
						min =  parseInt(projectProductivity[j][2]);
						if(min>='60'){
						hr = parseInt(min/60);
						min = parseInt(min%60);
						hrs = parseInt(hrs+hr);
						}
					}
				}// end for loop 
				
  projectDirectoryData += ' <tr>\
              <td>'+quantsoftProjlist[i][3]+'</td>\
              <td>'+quantsoftProjlist[i][1]+'</td>\
              <td>'+quantsoftProjlist[i][2]+'</td>\
              <td>'+inchargeName+'</td>\
              <td>'+hrs+'h:'+min+'m</td>';
			  if(quantsoftProjlist[i][5] == '0'){
  projectDirectoryData += ' <td>'+quantsoftProjlist[i][6]+'</td>';				  
			  }else{
  projectDirectoryData += ' <td>-</td>';
			  }
  projectDirectoryData += ' <td>';
		if(flag == '1'){
			projectDirectoryData += '<input type="radio"  value="active" checked> <span class="project_status_label">Active</span>';
		}else{
			projectDirectoryData += '<input type="radio"  value="active" onclick="activeProject('+quantsoftProjlist[i][0]+');"> <span class="project_status_label">Active</span>';
		}
		if(flag == '0'){
			projectDirectoryData += '<input type="radio"  value="deactive" checked> <span class="project_status_label">Deactive</span>';
		}else{
			projectDirectoryData += '<input type="radio"  value="deactive" onclick="deactiveProject('+quantsoftProjlist[i][0]+');"> <span class="project_status_label">Deactive</span>';
		}
        
			projectDirectoryData += ' <td>\
          <a class="table_icon green_color" title="Edit" onclick="editProjectInfo('+quantsoftProjlist[i][0]+');"><i class="fa fa-pencil" aria-hidden="true"></i></a>\
        </td>\
            </tr>';
			}
			
  projectDirectoryData += ' </tbody>\
        </table>\
      </div>\
	  </div>\
	  </div>';
  $('#page_title').text('Project Directory');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Project Directory');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(projectDirectoryData);
  $(".scroll_div").mCustomScrollbar();
  menuuse(6);
}//
// search by project id 
function searchByProjectId(){
	var search_proj_id  = $("#search_proj_id").val();
	
	var projectDirectoryData = '';
  projectDirectoryData = ' \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="projectDirectory();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Project Directory</a></li>\
          <li><a onclick="addProject();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Projects</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <span class="input-group-btn search_btn">\
            <button onclick="projectDirectory();" class="btn btn-default" type="button" onclick="searchEmpById();">\
              <i class="fa fa-arrow-left" aria-hidden="true"></i> Back\
            </button>\
          </span>\
        </div>\
      </div>';
  projectDirectoryData += '<div class="scroll_div"> <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Start Date</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Project ID</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Project Name</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Total Hours</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Hours Utilised</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Deactivation Date</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Project Status</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">&nbsp;</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		// console.log(projectProductivity);
					
			for(var i=0; i < quantsoftProjlist.length; i++){
				if(quantsoftProjlist[i][1] == search_proj_id){
				var flag = quantsoftProjlist[i][5];
				var ttlTime = quantsoftProjlist[i][4];
				var hrs = '';
			    var min = '';
				var hr = 0;
				for(var j=0; j<projectProductivity.length; j++){
			
					if(projectProductivity[j][0] == quantsoftProjlist[i][0]){
					
						hrs =  parseInt(projectProductivity[j][1]);
						
						min =  parseInt(projectProductivity[j][2]);
						if(min>='60'){
						hr = parseInt(min/60);
						min = parseInt(min%60);
						hrs = parseInt(hrs+hr);
						}
					}
				}
				
  projectDirectoryData += ' <tr>\
              <td>'+quantsoftProjlist[i][3]+'</td>\
              <td>'+quantsoftProjlist[i][1]+'</td>\
              <td>'+quantsoftProjlist[i][2]+'</td>\
              <td>'+quantsoftProjlist[i][4]+'</td>\
              <td>'+hrs+'h:'+min+'m</td>';
			  if(quantsoftProjlist[i][5] == '0'){
  projectDirectoryData += ' <td>'+quantsoftProjlist[i][6]+'</td>';				  
			  }else{
  projectDirectoryData += ' <td>-</td>';
			  }
  projectDirectoryData += ' <td>';
		if(flag == '1'){
			projectDirectoryData += '<input type="radio"  value="active" checked> <span class="project_status_label">Active</span>';
		}else{
			projectDirectoryData += '<input type="radio"  value="active" onclick="activeProject('+quantsoftProjlist[i][0]+');"> <span class="project_status_label">Active</span>';
		}
		if(flag == '0'){
			projectDirectoryData += '<input type="radio"  value="deactive" checked> <span class="project_status_label">Deactive</span>';
		}else{
			projectDirectoryData += '<input type="radio"  value="deactive" onclick="deactiveProject('+quantsoftProjlist[i][0]+');"> <span class="project_status_label">Deactive</span>';
		}
        
			projectDirectoryData += ' <td>\
          <a class="table_icon green_color" title="Edit" onclick="editProjectInfo('+quantsoftProjlist[i][0]+');"><i class="fa fa-pencil" aria-hidden="true"></i></a>\
        </td>\
            </tr>';
}}
			
  projectDirectoryData += ' </tbody>\
        </table>\
      </div>\
	  </div>\
	  </div>';
  $('#page_title').text('Project Directory');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Project Directory');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(projectDirectoryData);
  $(".scroll_div").mCustomScrollbar();
  menuuse(6);
	
}

// edit project info 

function editProjectInfo(project_id){
	//console.log(quantsoftProjlist);
	 addProject();
	 var project_id  			= project_id;
	 var project_no 			="";
	 var project_name 			="";
	 var start_date 			="";
	 var project_allocated_hrs 	="";
	 var project_incharge	 	="";
	 var project_status 		="";
	 
	 for(var i=0; i<quantsoftProjlist.length; i++){
		 if(project_id == quantsoftProjlist[i][0]){
			 project_no 			= quantsoftProjlist[i][1];
			 project_name 			= quantsoftProjlist[i][2];
			 start_date 			= quantsoftProjlist[i][3];
			 project_allocated_hrs  = quantsoftProjlist[i][4];
			 project_incharge		= quantsoftProjlist[i][7];
			 project_status 		= quantsoftProjlist[i][5];
		 }
	 }
	 
	 $("#project_no").val(project_no);
	 $("#project_name").val(project_name);
	 $("#project_start_date").val(start_date);
	 $("#project_allcated_hrs").val(project_allocated_hrs);
	 $("#project_incharge").val(project_incharge);
	 $("#project_id").val(project_id);
	 
	 
}//

// Project Directory start 

// Add Project start
function addProject(){
  var addProjectData = '';
  addProjectData = '  \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="projectDirectory();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Project Directory</a></li>\
          <li><a onclick="addProject();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> Add Projects</a></li>\
        </ul>\
      </div>';
	  
    addProjectData += '<form method="post">\
        <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="work_package_lable">Project Details</span>\
			</div>\
          </div>\
        </div>';
		
       addProjectData += ' <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="form_label" id="project_no_lable">Project No.</span>\
              <input type="text" id="project_no" name="project_no" required="required" class="padding_left_13 width_60">\
              <div class="bar width_60 margin_left_40p"></div>\
            </div>\
          </div>';
		  
      addProjectData += ' <div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="project_name" name="project_name" required="required">\
              <label for="To">Project Name</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
       addProjectData += '<div class="row">\
	   <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="form_label" id="project_start_date_label">Start Date</span>\
              <input type="date" id="project_start_date" name="project_start_date" required="required" class="padding_left_13 width_60" value="'+todayDate+'">\
              <div class="bar width_60 margin_left_40p"></div>\
            </div>\
          </div>';
		  
		   addProjectData += ' <div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="number" id="project_allcated_hrs" name="project_allcated_hrs" required="required">\
              <label for="To">Hrs. Allocated</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
       addProjectData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\<span class="addproject_select_category">Project Incharge</span>\
              <select class="add_project_select" id="project_incharge">\
                <option value="" selected>- Select -</option>';
				for(var i=0; i<adminProfile.length - 1; i++){					
               addProjectData += ' <option value="'+adminProfile[i][0]+'">'+adminProfile[i][1]+'&nbsp;'+adminProfile[i][2]+'</option>';
				}
            addProjectData += ' </select>\
            </div>\
          </div>\
        </div>\
		<input type="hidden" id="project_id" value="">\
        <input Type="button" value="Create" onclick="addQuantsoftProject();" class="btn save_btn">\
      </div>\
    </form>';
  $('#page_title').text('Add Project');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Project Directory -- Add Projects');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(addProjectData);
}
// Add Project end 


// Employee Directory start 
function employeeDirectory(){

  var employeeDirectoryData = '';
  employeeDirectoryData = '<div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="employeeDirectory();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Employee Directory</a></li>\
          <li><a onclick="newEmployee();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> New Employee</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <input type="text" id="search_emp_no" class="form-control search_box" placeholder="Search by Employee# (Case Sensitive)">\
          <span class="input-group-btn search_btn">\
            <button class="btn btn-default" type="button" onclick="searchEmpById();">\
              <i class="fa fa-search"></i>\
            </button>\
          </span>\
        </div>\
      </div>\
      <div class="scroll_div">\
      <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Employee #</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Name</span></a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Title</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Team</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Start Date</a></th>\
			        <th class="table_heading"><a class="link_pointer dark_color">Deactivation Date </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Status</a></th>\
			        <th class="table_heading"><a class="link_pointer dark_color">&nbsp; </a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		 
		 for(var i=0; i<quantsoftEmplist.length; i++){
			 if(quantsoftEmplist[i][19] == '1'){
          employeeDirectoryData += '<tr>\
              <td>'+quantsoftEmplist[i][16]+'</td>\
              <td>'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</td>\
              <td>'+quantsoftEmplist[i][14]+'</td>\
              <td>'+quantsoftEmplist[i][15]+'</td>\
              <td>'+quantsoftEmplist[i][13]+'</td>\
              <td>--</td>\
              <td class="green_color">Active</td>\
              <td>\
                <a onclick="edit_emp_info('+quantsoftEmplist[i][0]+');" class="table_icon green_color" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>\
                <a class="calender_icon_link blue_color"  onclick="view_employeeDetails('+quantsoftEmplist[i][0]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a>\
                <a class="table_icon red_color" onclick="emp_deleteMsg('+quantsoftEmplist[i][0]+');" title="Terminate"><i class="fa fa-times" aria-hidden="true"></i></a>\
                <a class="table_icon black_color" title="Log Activity" onclick="empProductivity('+quantsoftEmplist[i][0]+');"><i class="fa fa-address-card-o" aria-hidden="true"></i></a>\
                <a class="table_icon black_color" title="Monthly Report" onclick="empMonthlyReport('+quantsoftEmplist[i][0]+');"><i class="fa fa-calendar-times-o" aria-hidden="true"></i></a>\
              </td>\
            </tr>';
			 }// end if for active emp
			  if(quantsoftEmplist[i][19] == '0'){
          employeeDirectoryData += '<tr>\
              <td>'+quantsoftEmplist[i][16]+'</td>\
              <td>'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</td>\
              <td>'+quantsoftEmplist[i][14]+'</td>\
              <td>'+quantsoftEmplist[i][15]+'</td>\
              <td>'+quantsoftEmplist[i][13]+'</td>\
              <td>'+quantsoftEmplist[i][20]+'</td>\
              <td class="red_color">Deactive</td>\
              <td>\
			  <a class="calender_icon_link blue_color"  onclick="view_employeeDetails('+quantsoftEmplist[i][0]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a>\
                <a class="table_icon black_color" title="Log Activity" onclick="empProductivity('+quantsoftEmplist[i][0]+');"><i class="fa fa-address-card-o" aria-hidden="true"></i></a>\
              </td>\
            </tr>';
			 }// end if for deactive emp
			 
		 }// end i loop 
			
employeeDirectoryData += '</tbody>\
        </table>\
		</div>\
		</div>\
    </div>\
    <div class="modal fade" id="my_log" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"></div>\
	<div class="modal fade" id="terminate_confirm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>\
    <div class="modal fade" id="viewemployee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
	
  $('#page_title').text('Employee Directory');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Employee Directory');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(employeeDirectoryData);
  $(".scroll_div").mCustomScrollbar();
  menuuse(5);
}//
// emp search by id 

function searchEmpById(){
	var search_emp_no = $("#search_emp_no").val();
	//alert(search_emp_no);
	
   var employeeDirectoryData = '';
  employeeDirectoryData = '<div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="employeeDirectory();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Employee Directory</a></li>\
          <li><a onclick="newEmployee();" class="link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> New Employee</a></li>\
        </ul>\
        <div class="form-group input-group pull-right search_div">\
          <span class="input-group-btn search_btn">\
            <button onclick="employeeDirectory();" class="btn btn-default" type="button" onclick="searchEmpById();">\
              <i class="fa fa-arrow-left" aria-hidden="true"></i> Back\
            </button>\
          </span>\
        </div>\
      </div>\
      <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
              <th class="table_heading"><a class="link_pointer dark_color">Employee #</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Name</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Title</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Team</a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Start Date</a></th>\
			  <th class="table_heading"><a class="link_pointer dark_color">Deactivation Date </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Status</a></th>\
			  <th class="table_heading"><a class="link_pointer dark_color">&nbsp; </a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body">';
		 //console.log(quantsoftEmplist);
		 for(var i=0; i<quantsoftEmplist.length; i++){
			 if(quantsoftEmplist[i][19] == '1' && quantsoftEmplist[i][16] == search_emp_no){
          employeeDirectoryData += '<tr>\
              <td>'+quantsoftEmplist[i][16]+'</td>\
              <td>'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</td>\
              <td>'+quantsoftEmplist[i][14]+'</td>\
              <td>'+quantsoftEmplist[i][15]+'</td>\
              <td>'+quantsoftEmplist[i][13]+'</td>\
              <td>--</td>\
              <td class="green_color">Active</td>\
              <td>\
                <a onclick="edit_emp_info('+quantsoftEmplist[i][0]+');" class="table_icon green_color" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>\
                <a class="calender_icon_link blue_color"  onclick="view_employeeDetails('+quantsoftEmplist[i][0]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a>\
                <a class="table_icon red_color" onclick="emp_deleteMsg('+quantsoftEmplist[i][0]+');" title="Terminate"><i class="fa fa-times" aria-hidden="true"></i></a>\
                <a class="table_icon black_color" title="Log Activity" onclick="empProductivity('+quantsoftEmplist[i][0]+');"><i class="fa fa-address-card-o" aria-hidden="true"></i></a>\
              </td>\
            </tr>';
			 }// end if for active emp
			  if(quantsoftEmplist[i][19] == '0' && quantsoftEmplist[i][16] == search_emp_no){
          employeeDirectoryData += '<tr>\
              <td>'+quantsoftEmplist[i][16]+'</td>\
              <td>'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</td>\
              <td>'+quantsoftEmplist[i][14]+'</td>\
              <td>'+quantsoftEmplist[i][15]+'</td>\
              <td>'+quantsoftEmplist[i][13]+'</td>\
              <td>'+quantsoftEmplist[i][20]+'</td>\
              <td class="red_color">Deactive</td>\
              <td>\
			  <a class="calender_icon_link blue_color"  onclick="view_employeeDetails('+quantsoftEmplist[i][0]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a>\
                <a class="table_icon black_color" title="Log Activity" onclick="empProductivity('+quantsoftEmplist[i][0]+');"><i class="fa fa-address-card-o" aria-hidden="true"></i></a>\
              </td>\
            </tr>';
			 }// end if for deactive emp
			 
		 }// end i loop 
			
employeeDirectoryData += '</tbody>\
        </table>\
		</div>\
    </div>\
    <div class="modal fade" id="my_log" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"></div>\
	<div class="modal fade" id="terminate_confirm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>\
    <div class="modal fade" id="viewemployee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
	
  $('#page_title').text('Employee Directory');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Employee Directory');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(employeeDirectoryData);
  menuuse(5);
	get_emp_info_details();
}//

// on click event emp productivity 

function empProductivity(emp_id){
	
	var emp_id = emp_id;
	var dataTable = '';
	
	var dataTable = '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body">\
            <div class="view_enquiry_header">';
			for (var i=0; i<quantsoftEmplist.length; i++){
			if(quantsoftEmplist[i][0] == emp_id){
             dataTable += ' <label class="view_enquiry_head_lable">Employee Name :</label> <label class="view_enquiry_head_lable">'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</label>';
			}}
			
           dataTable += ' </div>\
            <div class="row">\
              <div class="communication_input card">\
                <div class="form-group left_div input-container">\
                  <span class="form_date_label">Start Date</span>\
                  <input type="date" id="emp_from_date" name="emp_from_date" value="'+todayDate+'" class="width_60 margin_top_7">\
                  <div class="bar width_60 margin_left_31p"></div>\
                </div>\
              </div>';
             dataTable += '<div class="communication_input card">\
                <div class="form-group right_div_popup input-container">\
                  <span class="form_date_label">End Date</span>\
                  <input type="date" id="emp_to_date" name="emp_to_date" value="'+todayDate+'" class="width_60 margin_top_7">\
                  <div class="bar width_60 margin_left_31p"></div>\
                </div>\
                <a class="date_submit" onClick="empProductivityByDate('+emp_id+');"><i class="fa fa-search" aria-hidden="true" ></i></a>\
              </div>\
            </div>';
         dataTable += '<table class="table table_employee_log">\
              <thead class="table_header">\
                <tr>\
                  <th class="table_heading"><a class="link_pointer dark_color">Project ID <span class=""></span></a></th>\
                  <th class="table_heading"><a class="link_pointer dark_color">Project Name <span class=""></span></a></th>\
                  <th class="table_heading"><a class="link_pointer dark_color">Project Hours <span class=""></span></a></th>\
                  <th class="table_heading"><a class="link_pointer dark_color">Productivity </a></th>\
                </tr>\
              </thead>\
              <tbody class="table_body" id="dataBySearch">';
			  
			  for(var i=0; i<empProjProductivity.length; i++){
				  if(empProjProductivity[i][0] == emp_id){
				  console.log(empProjProductivity);
					  var hrs         = empProjProductivity[i][4];
					  var min         = empProjProductivity[i][5];
					  var proj_no     = '';
					  var proj_name   = '';
					  var proj_totHrs = '';
					  for(var j=0; j<quantsoftProjlist.length; j++){
						  if(quantsoftProjlist[j][0] == empProjProductivity[i][3]){
							  proj_no     = quantsoftProjlist[j][1];
							  proj_name   = quantsoftProjlist[j][2];
							  proj_totHrs = quantsoftProjlist[j][4];
						  }
					  }// end j loop
					  
					  if(empProjProductivity[i][5]>= '60'){
						  min = parseInt(min/60);
						  hrs = parseInt(hrs + min);
						  min = parseInt(min%60);
					  }//
					  
					  dataTable +=' <tr>\
					  <td>'+proj_no+'</td>\
					  <td>'+proj_name+'</td>\
					  <td>'+proj_totHrs+'&nbsp;Hrs.</td>\
					  <td>'+hrs+':'+min+'&nbsp;Hrs.</td>\
					  </tr>';
					 
				  }// end main if
			  }//end i loop 
			  
              dataTable +='</tbody>\
            </table>\
          </div>\
        </div>\
      </div>';
	  
	$('#my_log').html(dataTable);
	$('#my_log').modal('show');
	
	
}//



// on click event emp productivity 

function empMonthlyReport(emp_id){  
	
  var emp_id = emp_id;
  var dataTable = '';  
  var dataTable = '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body">\
            <div class="view_enquiry_header">';
      for (var i=0; i<quantsoftEmplist.length; i++){
      if(quantsoftEmplist[i][0] == emp_id){
             dataTable += ' <label class="view_enquiry_head_lable">Employee Name :</label> <label class="view_enquiry_head_lable">'+quantsoftEmplist[i][1]+'&nbsp;'+quantsoftEmplist[i][2]+'</label><button type="button" class="close" data-dismiss="modal">&times;</button>';
      }}
dataTable += ' </div>\
            <div class="row">\
              <div class="communication_input card">\
                <div class="form-group left_div input-container">\
                  <div class="bar width_60 margin_left_31p"></div>\
                </div>\
              </div>';
             dataTable += '<div class="communication_input card">\
                <div class="form-group right_div_popup input-container">\
                  <span class="form_date_label">Select Date</span>\
                  <input type="date" id="report_date" name="report_date" value="'+todayDate+'" class="width_60 margin_top_7">\
                  <div class="bar width_60 margin_left_31p"></div>\
                </div>\
                <a class="date_submit" onClick="viewMonthlyEmpTimesheet('+emp_id+');"><i class="fa fa-search" aria-hidden="true" ></i></a>\
              </div>\
            </div>';
         dataTable += '<table class="table table_employee_log">\
              <thead class="table_header">\
                <tr>\
                  <th class="table_heading"><a class="link_pointer dark_color"> Date <span class=""></span></a></th>\
                  <th class="table_heading"><a class="link_pointer dark_color"> Project/Activity <span class=""></span></a></th>\
                  <th class="table_heading"><a class="link_pointer dark_color"> Productivity <span class=""></span></a></th>\
                  <th class="table_heading"><a class="link_pointer dark_color">Timesheet Status </a></th>\
                </tr>\
              </thead>\
              <tbody class="table_body" id="monthlyReport">';

              dataTable +='</tbody>\
            </table>\
          </div>\
        </div>\
      </div>';
  
  $('#my_log').html(dataTable);
  $('#my_log').modal('show');
}//

// report data table
function reportDataBymonth(){
	var dataTable = '';
	
	if(empMonthlyTimesheet.length>0){
	for(var i=0;i<empMonthlyTimesheet.length;i++){
	var timesheet_status = empMonthlyTimesheet[i][12];
	var project_id = empMonthlyTimesheet[i][3];
	 for(var j=0; j<quantsoftProjlist.length;j++){
		 if(quantsoftProjlist[j][0] == project_id){
			 var proj_name = quantsoftProjlist[j][2];
			 }
		 }
	dataTable +=' <tr>\
				<td>'+empMonthlyTimesheet[i][2]+'</td>\
				<td>'+proj_name+'</td>\
				<td>'+empMonthlyTimesheet[i][8]+'h:'+empMonthlyTimesheet[i][9]+'m</td>';
				if(timesheet_status == 0){
				dataTable +='<td>Pendding</td>';
					}else if(timesheet_status == 1){
				dataTable +='<td>Approved</td>';	
					}else if(timesheet_status == 2){
				dataTable +='<td>Disapproved</td>';	
					}
	dataTable +='</tr>';
	}}else{
	dataTable +=' <tr>\
				<td colspan="4">No Data Found!</td>\
			</tr>';
	}	
  $('#monthlyReport').html(dataTable);
  
}

// Employee Directory end 

/* Alert Messages */

// employee delete alert 
function emp_deleteMsg(emp_id){
	var dataTable = '';
	var emp_id = emp_id;
	
	dataTable = '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body padding_15">\
            <h4 class="modal-title" id="exampleModalLabel">Do you want to terminate this Employee?</h4>\
            <button type="button" class="btn btn-primary" onclick="delete_emp_info_details('+emp_id+');" ><i class="fa fa-check" aria-hidden="true"></i></button>\
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>\
            <p class="note_line">Note: Deleted Employees will move at the bottom of the table.</p>\
          </div>\
        </div>\
      </div>';
	
	$('#terminate_confirm').html(dataTable);
	$('#terminate_confirm').modal('show');	
}

// leave delete alert 
function leaveTypeDeleteMsg(leave_id){
	
		  var dataTable = '';
		  var leave_id = leave_id;
		  
dataTable = ' <div class="modal-dialog" role="document">\
				<div class="modal-content">\
					<div class="modal-body padding_15">\
					  <h4 class="modal-title" id="exampleModalLabel">Do you want to remove this Leave Type?</h4>\
					  <button type="button" class="btn btn-primary" onclick="delete_leave_type('+leave_id+');"><i class="fa fa-check" aria-hidden="true"></i></button>\
					  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>\
					</div>\
				 </div>\
			  </div>';
		  
	$('#terminate_confirm_settings').html(dataTable);
	$('#terminate_confirm_settings').modal('show');	
		  
}
//

// add sub category alert 

function add_subcategory_row(){
	
	var dataTable = '';
	dataTable = ' <div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body padding_15">\
            <h4 class="modal-title" id="exampleModalLabel">Do you want to add another Sub Category?</h4>\
            <button type="button" class="btn btn-primary" onclick="addMoreRow();"><i class="fa fa-check" aria-hidden="true"></i></button>\
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>\
          </div>\
        </div>\
      </div>';
	  
	$('#add_row').html(dataTable);
	$('#add_row').modal('show');	
}

function view_employeeDetails(emp_id){
	var dataTable = '';
	var emp_id = emp_id;
	
	for(var i=0; i<quantsoftEmplist.length;i++){
		if(emp_id == quantsoftEmplist[i][0] ){
		
	dataTable = '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body display_table">\
            <div class="view_enquiry_header">\
              <label class="view_enquiry_head_lable">Employee ID :</label> <label class="view_enquiry_head_lable">'+quantsoftEmplist[i][16]+'</label>\
            </div>\
            <div class="width_100"><label class="view_label_heading margin_top_13">Personal Details :</label></div>\
            <div class="width_50"><label class="view_label">First Name :</label> <label class="view_label_input">'+quantsoftEmplist[i][1]+'</label></div>\
            <div class="width_50"><label class="view_label">Last Name :</label> <label class="view_label_input">'+quantsoftEmplist[i][2]+'</label></div>\
            <div class="width_50"><label class="view_label">Gender :</label> <label class="view_label_input">'+quantsoftEmplist[i][3]+'</label></div>\
            <div class="width_50"><label class="view_label">Email :</label> <label class="view_label_input"><a href="mailto:name@email.com" class="view_enquiry_link">'+quantsoftEmplist[i][4]+'</a></label></div>\
            <div class="width_50"><label class="view_label">Mobile :</label> <label class="view_label_input">+91 '+quantsoftEmplist[i][5]+'</label></div>\
            <div class="width_50"><label class="view_label">Blood Group :</label> <label class="view_label_input">'+quantsoftEmplist[i][6]+'</label></div>\
            <div class="width_50"><label class="view_label">City :</label> <label class="view_label_input">'+quantsoftEmplist[i][7]+'</label></div>\
            <div class="width_50"><label class="view_label">State :</label> <label class="view_label_input">'+quantsoftEmplist[i][8]+'</label></div>\
            <div class="width_50"><label class="view_label">Country :</label> <label class="view_label_input">'+quantsoftEmplist[i][9]+'</label></div>\
            <div class="width_50"><label class="view_label">Pincode :</label> <label class="view_label_input">'+quantsoftEmplist[i][10]+'</label></div>\
            <div class="width_50"><label class="view_label">Emergency Contact Name :</label> <label class="view_label_input">'+quantsoftEmplist[i][11]+'</label></div>\
            <div class="width_50"><label class="view_label">Emergency Contact No. :</label> <label class="view_label_input">+91 '+quantsoftEmplist[i][12]+'</label></div>\
            <div class="width_50"><label class="view_label">Title :</label> <label class="view_label_input">'+quantsoftEmplist[i][14]+'</label></div>\
            <div class="width_50"><label class="view_label">Team :</label> <label class="view_label_input">'+quantsoftEmplist[i][15]+'</label></div>\
            <div class="width_50"><label class="view_label">Joining Date :</label> <label class="view_label_input">'+quantsoftEmplist[i][13]+'</label></div>\
			<div class="width_50"><label class="view_label">D.O.B. :</label> <label class="view_label_input">'+quantsoftEmplist[i][21]+'</label></div>\
          </div>\
        </div>\
      </div>';
		}// if end 
	} // for loop end 
	$('#viewemployee').html(dataTable);
	$('#viewemployee').modal('show');
	
}// 
// New Employee start 
function newEmployee(){
	var randPassword = makeid();
	
  var newEmployeeData = '';
  newEmployeeData = '<div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="employeeDirectory();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Employee Directory</a></li>\
          <li><a onclick="newEmployee();" class="top_nav_active link_pointer"><i class="fa fa-plus" aria-hidden="true"></i> New Employee</a></li>\
        </ul>\
      </div>';
	  
newEmployeeData += '<form method="post" action="#" id="add_new_emp">\
        <div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <h3 class="form_sub_heading">Employee Details</h3>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="emp_first_name" name="emp_first_name" required="required">\
              <label for="To">First Name</label>\
              <div class="bar"></div>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="emp_last_name" name="emp_last_name" required="required">\
              <label for="To">Last Name</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="lead_lable">Gender</span>\
              <select id="emp_gender" name="emp_gender" class="lead_select">\
                  <option class="lead_item" value="">- select -</option>\
                  <option value="male">Male</option>\
                  <option value="female">Female</option>\
              </select>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="emp_email_id" name="emp_email_id" required="required">\
              <label for="To">Email</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="emp_mobile_no" name="emp_mobile_no" required="required">\
              <label for="To">Mobile</label>\
              <div class="bar"></div>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="emp_blood_grp" name="emp_blood_grp" placeholder="Blood Group">\
              <label for="To">Blood Group</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="emp_city" name="emp_city" required="required">\
              <label for="To">City</label>\
              <div class="bar"></div>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="emp_state" name="emp_state" required="required">\
              <label for="To">State</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
            <span class="lead_lable">Country</span>\
            <select id="emp_country" name="emp_country" class="lead_select">\
            <option class="lead_item" value="">- select -</option>';
            for(var i=0; i < country_list.length; i++){
             newEmployeeData += '<option class="lead_item" value="'+country_list[i]+'">'+country_list[i]+'</option>';
            }
            newEmployeeData += '</select>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="emp_pincode" name="emp_pincode" required="required">\
              <label for="To">Pincode</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <input type="text" id="emp_emges_cont_name" name="emp_emges_cont_name" required="required">\
              <label for="To">Emergency Contact (Name)</label>\
              <div class="bar"></div>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="emp_emges_cont_no" name="emp_emges_cont_no" required="required">\
              <label for="To">Emergency Contact (Number)</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="form_date_label">Start Date</span>\
              <input type="date" id="emp_start_date" name="emp_start_date"  value="'+todayDate+'" class="width_41 margin_top_7">\
              <div class="bar width_41 margin_left_31p"></div>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <span class="lead_lable">Title</span>\
              <select id="emp_title" name="emp_title" class="lead_select">\
                  <option class="lead_item" value="">- select -</option>\
                  <option value="SENIOR ENGINEER">SENIOR ENGINEER</option>\
                  <option value="JUNIOR ENGINEER">JUNIOR ENGINEER</option>\
                  <option value="SENIOR DRAUGHTSMEN">SENIOR DRAUGHTSMEN</option>\
                  <option value="JUNIOR DRAUGHTSMEN">JUNIOR DRAUGHTSMEN</option>\
                  <option value="SENIOR DESIGNER">SENIOR DESIGNER</option>\
                  <option value="JUNIOR DESIGNER">JUNIOR DESIGNER</option>\
                  <option value="MODELLER">MODELLER</option>\
                  <option value="SENIOR EDITOR">SENIOR EDITOR</option>\
                  <option value="JUNIOR EDITOR">JUNIOR EDITOR</option>\
                  <option value="ACCOUNTANT">ACCOUNTANT</option>\
                  <option value="HR PERSONNEL">HR PERSONNEL</option>\
              </select>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="row">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="team_lable">Team</span>\
              <select id="emp_team" name="emp_team" class="lead_select">\
                  <option class="lead_item" value="">- select -</option>\
                  <option value="ENGINEERS">ENGINEERS</option>\
                  <option value="DRAUGHTSMEN">DRAUGHTSMEN</option>\
                  <option value="DESIGNERS">DESIGNERS</option>\
                  <option value="MODELLERS">MODELLERS</option>\
                  <option value="EDITORS">EDITORS</option>\
                  <option value="ACCOUNTANTS/HR PERSONNEL">ACCOUNTANTS/HR PERSONNEL</option>\
              </select>\
            </div>\
          </div>';
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <input type="text" id="employee_id" name="employee_id" required="required">\
              <label for="To">Employee ID</label>\
              <div class="bar"></div>\
            </div>\
          </div>\
        </div>';
		
newEmployeeData += '<div class="full_width">\
		<div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="lead_lable">Login Password: </span>\
              <span class="login_input_div">\
	              <input type="text" value="" class="margin_top_12" name="emp_intial_password" required="required">\
	              <div class="bar_password"></div>\
              </span>\
            </div>\
          </div>';
		
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
              <span class="lead_lable">Access Type</span>\
              <select id="access_type" name="access_type" class="lead_select">\
                  <option class="lead_item" value="">- select -</option>\
                  <option value="1">EMPLOYEE</option>\
                  <option value="2">PROBATION PERIOD</option>\
                  <option value="3">TRAINING PERIOD</option>\
                  <option value="4">NOTICE PERIOD</option>\
              </select>\
            </div>\
            </div>\
          </div>';

newEmployeeData += '<div class="row col-md-12">\
          <div class="communication_input card">\
            <div class="form-group left_div input-container">\
              <span class="form_date_label">D.O.B</span>\
              <input type="date" id="emp_dob" name="emp_dob"  value="'+todayDate+'" class="width_41 margin_top_7">\
              <div class="bar width_41 margin_left_31p"></div>\
            </div>\
          </div>';		  
	  
		  
		  
newEmployeeData += '<div class="communication_input card">\
            <div class="form-group right_div input-container">\
            </div>\
          </div>\
        </div>\
		<input type="hidden" id="emp_id" value="">\
        <input type="button" value="Create" onclick="addNewQuantsoftEmp();" class="btn save_btn">\
      </div>\
    </form>';
  $('#page_title').text('New Employee');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Employee Directory -- New Employee');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(newEmployeeData);
}
// New Employee end 

// Emp edit 
function edit_emp_info(emp_id){
	newEmployee();
	var emp_id 				= emp_id;
	var emp_first_name 		= "";
	var emp_last_name   	= "";
	var emp_gender   		= "";
	var emp_email_id	 	= "";
	var emp_mobile_no	 	= "";
	var emp_blood_grp	 	= "";
	var emp_city		 	= "";
	var emp_state		 	= "";
	var emp_country		 	= "";
	var emp_pincode		 	= "";
	var emp_emges_cont_name = "";
	var emp_emges_cont_no	= "";
	var emp_start_date		= "";
	var emp_title			= "";
	var emp_team			= "";
	var employee_id			= "";
	var emp_intial_password	= "";
	var access_type			= "";
	var emp_dob			    = "";
	
	for(var i=0; i<quantsoftEmplist.length; i++){
		if(emp_id == quantsoftEmplist[i][0]){		
			  emp_first_name 	  = quantsoftEmplist[i][1];
			  emp_last_name   	  = quantsoftEmplist[i][2];
			  emp_gender	   	  = quantsoftEmplist[i][3];
			  emp_email_id	 	  = quantsoftEmplist[i][4];
			  emp_mobile_no	 	  = quantsoftEmplist[i][5];
			  emp_blood_grp	 	  = quantsoftEmplist[i][6];
			  emp_city		 	  = quantsoftEmplist[i][7];
			  emp_state		 	  = quantsoftEmplist[i][8];
			  emp_country		  = quantsoftEmplist[i][9];
			  emp_pincode		  = quantsoftEmplist[i][10];
			  emp_emges_cont_name = quantsoftEmplist[i][11];
			  emp_emges_cont_no	  = quantsoftEmplist[i][12];
			  emp_start_date	  = quantsoftEmplist[i][13];
			  emp_title			  = quantsoftEmplist[i][14];
			  emp_team			  = quantsoftEmplist[i][15];
			  employee_id		  = quantsoftEmplist[i][16];
			  emp_intial_password = quantsoftEmplist[i][17];
			  access_type		  = quantsoftEmplist[i][18];
			  emp_dob    		  = quantsoftEmplist[i][21];
	    }
	}
	
	$("#emp_first_name").val(emp_first_name);
	$("#emp_last_name").val(emp_last_name);
	$("#emp_gender").val(emp_gender);
	$("#emp_email_id").val(emp_email_id);
	$("#emp_mobile_no").val(emp_mobile_no);
	$("#emp_blood_grp").val(emp_blood_grp);
	$("#emp_city").val(emp_city);
	$("#emp_state").val(emp_state);
	$("#emp_country").val(emp_country);
	$("#emp_pincode").val(emp_pincode);
	$("#emp_emges_cont_name").val(emp_emges_cont_name);
	$("#emp_emges_cont_no").val(emp_emges_cont_no);
	$("#emp_start_date").val(emp_start_date);
	$("#emp_title").val(emp_title);
	$("#emp_team").val(emp_team);
	$("#employee_id").val(employee_id);
	$("#emp_intial_password").val(emp_intial_password);
	$("#access_type").val(access_type);
	$("#emp_dob").val(emp_dob);
	
	$("#emp_id").val(emp_id);
}
// Emp edit end 

// Approve Timesheets start 
function approveTimesheets(){
$('#loader').modal('show');
//getEmpLogActivity();
getDailyTimesheetInfo(todayDate);

  var approveTimesheetsData = '';
  approveTimesheetsData = ' \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="approveTimesheets();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Timesheet Roaster</a></li>\
          <li><a onclick="approvalTimesheetsPendding();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Approve Timesheets</a></li>\
        </ul>\
      </div>\
      <div class="row margin_bottom_10">\
        <div class="pull-left day_display">\
          <p class="week_display_line margin_bottom_20">\
          <span class="week_display_date"><input type="date" id="timesheet_date" value="'+todayDate+'" onchange="timesheetActivityDate(this.value);" style="padding:0px;border-bottom-color: darkgray;border: none;background-color: #f4f4f4;"></span>\
          </p>\
        </div>\
      </div>';
      approveTimesheetsData += ' <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
			<th class="table_heading"><a class="link_pointer dark_color">Date </a></th>\
			<th class="table_heading"><a class="link_pointer dark_color">Employee Name </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Prject/Activity </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Total Hours </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Timecard Submitted </a></th>\
			  <th class="table_heading"><a class="link_pointer dark_color">Details</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body" id="viewTimeSheetDataINfo">';
		  
		
		
		for(var i=0; i<dailyTimeSheetInfo.length; i++){	 
		//viewTimeSheetDataINfo
		var admin_id = userProfile[0][0];
		
		var project_id = dailyTimeSheetInfo[i][3];
		for(var j=0; j<quantsoftProjlist.length;j++){
			if(quantsoftProjlist[j][0] == project_id){
				var project_incharge = quantsoftProjlist[j][7];
				var project_name = quantsoftProjlist[j][2];
			}
		}//
		
		var emp_id = dailyTimeSheetInfo[i][1];
		for(var k=0; k<quantsoftEmplist.length;k++){
			if(quantsoftEmplist[k][0] == emp_id){
				var emp_first_name = quantsoftEmplist[k][1];
				var emp_last_name  = quantsoftEmplist[k][2];
				var emp_id 		   = quantsoftEmplist[k][16];
			}
		}//
		
		if(project_incharge == admin_id){
			
         approveTimesheetsData += ' <tr>\
		      <td>'+dailyTimeSheetInfo[i][2]+'</td>\
              <td>'+emp_first_name+'&nbsp'+emp_last_name+'</td>\
              <td>'+project_name+'</td>';
	approveTimesheetsData += ' <td>'+dailyTimeSheetInfo[i][8]+'h:'+dailyTimeSheetInfo[i][9]+'m</td>';
			  if(dailyTimeSheetInfo[i][12] == '1'){
				  approveTimesheetsData += ' <td class="green_color">Approved</td>';
			  }else if(dailyTimeSheetInfo[i][12] == '2'){
				 approveTimesheetsData += ' <td class="red_color">Disapproved</td>';  
			  }else{
				  approveTimesheetsData += ' <td class="green_color">Yes</td>';
			  }
			  
			  approveTimesheetsData += '<td><a class="calender_icon_link blue_color" onclick="viewtimesheet('+dailyTimeSheetInfo[i][0]+','+dailyTimeSheetInfo[i][1]+','+dailyTimeSheetInfo[i][3]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a></td>\
            </tr>';
		    }
		 }
       approveTimesheetsData += ' </tbody>\
        </table>\
      </div>\
    </div>\
    <div class="modal fade" id="viewtimesheet" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
  $('#page_title').text('Timesheets Approval');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Timesheets Approval');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(approveTimesheetsData);
  menuuse(4);
  $('#loader').modal('hide');
  $('.modal-backdrop').modal('hide');
}//


// pendding timesheet approvals 
function approvalTimesheetsPendding(){
	getApprovalPenddingTimesheetInfo();
$('#loader').modal('show');

  var approveTimesheetsData = '';
  approveTimesheetsData = ' \
    <div class="col-md-12 fullwraper">\
      <div class="row">\
        <ul class="top_nav_ul">\
          <li><a onclick="approveTimesheets();" class="link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Timesheet Roaster</a></li>\
          <li><a onclick="approvalTimesheetsPendding();" class="top_nav_active link_pointer"><i class="fa fa-list-alt" aria-hidden="true"></i> Approve Timesheets</a></li>\
        </ul>\
      </div>';
approveTimesheetsData += ' <div class="table-responsive table_div" id="enquiryTrackingViewingContainer">\
        <table class="table">\
          <thead class="table_header">\
            <tr>\
			<th class="table_heading"><a class="link_pointer dark_color">Date </a></th>\
			<th class="table_heading"><a class="link_pointer dark_color">Employee Name </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Prject/Activity </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Total Hours </a></th>\
              <th class="table_heading"><a class="link_pointer dark_color">Timecard Submitted </a></th>\
			  <th class="table_heading"><a class="link_pointer dark_color">Details</a></th>\
            </tr>\
          </thead>\
          <tbody class="table_body" id="viewTimeSheetDataINfo">';
		  
		for(var i=0; i<approvalPenddingTimeSheetInfo.length; i++){	 
		//viewTimeSheetDataINfo
		var admin_id = userProfile[0][0];
		
		var project_id = approvalPenddingTimeSheetInfo[i][3];
		for(var j=0; j<quantsoftProjlist.length;j++){
			if(quantsoftProjlist[j][0] == project_id){
				var project_incharge = quantsoftProjlist[j][7];
				var project_name = quantsoftProjlist[j][2];
			}
		}//
		
		var emp_id = approvalPenddingTimeSheetInfo[i][1];
		for(var k=0; k<quantsoftEmplist.length;k++){
			if(quantsoftEmplist[k][0] == emp_id){
				var emp_first_name = quantsoftEmplist[k][1];
				var emp_last_name  = quantsoftEmplist[k][2];
				var emp_id 		   = quantsoftEmplist[k][16];
			}
		}//
		var chk_count = 0;
		if(project_incharge == admin_id){
			chk_count = chk_count + i;
         approveTimesheetsData += ' <tr>\
		      <td>'+approvalPenddingTimeSheetInfo[i][2]+'</td>\
              <td>'+emp_first_name+'&nbsp'+emp_last_name+'</td>\
              <td>'+project_name+'</td>';
	approveTimesheetsData += ' <td>'+approvalPenddingTimeSheetInfo[i][8]+'h:'+approvalPenddingTimeSheetInfo[i][9]+'m</td>';
			  if(approvalPenddingTimeSheetInfo[i][12] == '1'){
				  approveTimesheetsData += ' <td class="green_color">Approved</td>';
			  }else if(approvalPenddingTimeSheetInfo[i][12] == '2'){
				 approveTimesheetsData += ' <td class="red_color">Disapproved</td>';  
			  }else{
				  approveTimesheetsData += ' <td class="green_color">Yes</td>';
			  }
			  
			  approveTimesheetsData += '<td><a class="calender_icon_link blue_color" onclick="viewtimesheet('+approvalPenddingTimeSheetInfo[i][0]+','+approvalPenddingTimeSheetInfo[i][1]+','+approvalPenddingTimeSheetInfo[i][3]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a></td>\
            </tr>';
		    }
		 }
		
       approveTimesheetsData += ' </tbody>\
        </table>\
      </div>\
    </div>\
    <div class="modal fade" id="viewtimesheet" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"></div>';
  $('#page_title').text('Timesheets Approval');
  $('#page_title').addClass('page_header');
  $('#page_map').text('Quantsoft -- Timesheets Approval');
  $('#page_map').addClass('page_map');
  $('#main_all_content').html(approveTimesheetsData);
  menuuse(4);
  $('#loader').modal('hide');
  $('.modal-backdrop').modal('hide');
}//

// on view daily detail timesheet 
function viewtimesheet(sr_no,emp_id,proj_id){
	getEmpLogActivity();
	var sr_no    = sr_no;	
	var emp_id   = emp_id;	
	var proj_id   = proj_id;	


	var dataTable = '';

	dataTable += '<div class="modal-dialog" role="document">\
        <div class="modal-content">\
          <div class="modal-body display_table">\
            <div class="view_enquiry_header">';
		for(var x=0;x<empLogActivityInfo.length;x++){
			if(empLogActivityInfo[x][0] == sr_no){
				var logdate = empLogActivityInfo[x][2];
			}
		}
		//alert(logdate);
     dataTable += '<label class="view_enquiry_head_lable">'+logdate+'</label>\
            </div>';
				 
			for(var i=0; i<quantsoftEmplist.length; i++){
				if(emp_id == quantsoftEmplist[i][0]){
				dataTable += ' <div class="width_100"><label class="view_label_heading margin_top_13 margin_bottom_10">Employee Name: '+quantsoftEmplist[i][1]+' '+quantsoftEmplist[i][2]+' ('+quantsoftEmplist[i][16]+')</label></div>';
				
				}// if end 
			}// i end 
				
				// console.log(empLogActivityInfo);
			for(var j=0; j<empLogActivityInfo.length; j++){
				if(sr_no == empLogActivityInfo[j][0]){
				 var proj_id	 = empLogActivityInfo[j][3];
				 var cat_id	     = empLogActivityInfo[j][4];				
				 var sub_cat_id	 = empLogActivityInfo[j][5];				
				 var approve_checked = '';
				 var disapprove_checked = '';
				 
				 for(var l=0;l<quantsoftProjlist.length;l++){
					 if(proj_id == quantsoftProjlist[l][0]){
						var project_no   = quantsoftProjlist[l][1];
						var project_name = quantsoftProjlist[l][2];
					 }
				 } // l end 
				
				 for(var m=0; m<quantsoftCategorylist.length; m++){
					 if(cat_id == quantsoftCategorylist[m][0]){
						var category_name = quantsoftCategorylist[m][1];
					
					 }
				 }// m end 
				
				 for(var n=0; n<quantsoftSubCategorylist.length; n++){
					 if(sub_cat_id == quantsoftSubCategorylist[n][0]){
						var subCategory_name = quantsoftSubCategorylist[n][2];
							
					 }
				 }// n end 
			if(proj_id > 4){
			dataTable += ' <div class="border_div_1"></div>\
					<div class="width_50"><label class="view_label">Project ID :</label> <label class="view_label_input">'+project_no+'</label></div>';
			}
			if(proj_id > 4){
			dataTable += ' <div class="width_50"><label class="view_label">Project Name :</label> <label class="view_label_input">'+project_name+'</label></div>';
			}else{
			dataTable += ' <div class="width_50"><label class="view_label">Activity :</label> <label class="view_label_input">'+project_name+'</label></div>';	
			}
			// show following only it's project
		   if(proj_id > 4){
			dataTable += ' <div class="width_50"><label class="view_label">Category :</label> <label class="view_label_input">'+category_name+'</label></div>';
			
			dataTable += ' <div class="width_50"><label class="view_label">Sub Category :</label> <label class="view_label_input">'+subCategory_name+'</label></div>';
			
			dataTable += '	<div class="width_50"><label class="view_label">Drawing Number :</label> <label class="view_label_input">'+empLogActivityInfo[j][6]+'</label></div>';
			
			dataTable += '	<div class="width_50"><label class="view_label">Model Number :</label> <label class="view_label_input">'+empLogActivityInfo[j][7]+'</label></div>';
		   }
			dataTable += '	<div class="width_50"><label class="view_label">Total Hours :</label> <label class="view_label_input">'+empLogActivityInfo[j][8]+'</label></div>';
			
			dataTable += '	<div class="width_50"><label class="view_label">Total Minutes :</label> <label class="view_label_input">'+empLogActivityInfo[j][9]+'</label></div>';
			
			dataTable += '	<div class="width_100"><label class="view_label">Message :</label> <label class="view_label_input_message">'+empLogActivityInfo[j][10]+'.</label></div> <div class="width_100"><textarea id="admin_msg" name="admin_msg" class="admin_notes" placeholder="Admin Notes"></textarea></div>';
			
			dataTable += '	<div class="width_50"><label class="view_label float_left">Status :</label>';
			
			 if(empLogActivityInfo[j][12] == '1'){
					 approve_checked = 'checked';
				 }
				 if(empLogActivityInfo[j][12] == '2'){
					 disapprove_checked = 'checked';
					 
				 }
				 
		
			
			dataTable += '<label class="view_label_input">\
						<input type="radio" '+approve_checked+' id="approve_dts'+j+'" name="approve_dts'+j+'" value="Approve" onclick="approveDailyTimSheet('+empLogActivityInfo[j][0]+');" class="approve_timesheet_btn">\
					<span class="approve_label" >Approve</span>\
					</label>';
					
			dataTable += ' <label class="view_label_input">\
			<input type="radio" '+disapprove_checked+' id="approve_dts'+j+'" name="approve_dts'+j+'" value="Disapprove" onclick="disapproveDailyTimSheet('+empLogActivityInfo[j][0]+');" class="approve_timesheet_btn"> <span class="approve_label">Disapprove</span></label></div>';
			
			
			} // if end 
			}// for loop j end 
				
				
        dataTable += '	<div class="width_100"><button type="button"  data-dismiss="modal" class="btn save_btn_prod">Dismiss</buttont></div>\
		</div>\
        </div>\
      </div>';
	$('#viewtimesheet').html(dataTable);
	$('#viewtimesheet').modal('show');
}//

// Approve Timesheets end 

// add more row @ sub-category 

function addMoreRow(){
	//alert('Hi..testing');
	
	if (count_sc <= 10){
		
	var dataTable = ' <div id="sub_category_area'+count_sc+'"><div class="communication_input card" style="clear:both; margin: 0px">\
            <div class="form-group left_div input-container">\
              <input type="text" id="sub_category_name'+count_sc+'" name="sub_category_name'+count_sc+'" required="required">\
              <label for="To">Sub Category</label>\
              <div class="bar"></div>\
            </div>\
			</div>';
			dataTable += '<div>\
			<a href="#" class="add_row_link_category" onclick="removeOnes('+count_sc+')" title="Remove row"><i class="fa fa-minus" aria-hidden="true"></i></a>';
			dataTable +='</div>\
			</div>';
			
			 $('#count_sc').val(count_sc);
             $('#add_more_sub_category').append(dataTable);
        
			
			count_sc++;
	$('#add_row').modal('hide');
	$('#count_sc').val(count_sc);
	}
}

// remove row @ sub-category
function removeOnes(count_sc){     

   $('#sub_category_area'+count_sc).remove();
    count_sc--;    
	$('#add_row').modal('hide');
}

function timesheetActivityDate(logDate){
	
    var logDate = logDate ;
    var approveTimesheetsData = '' ;	
	getDailyTimesheetInfo(logDate);
	
	for(var i=0; i<dailyTimeSheetInfo.length; i++){	 		
		var admin_id = userProfile[0][0];		
		var project_id = dailyTimeSheetInfo[i][3];
		for(var j=0; j<quantsoftProjlist.length;j++){
			if(quantsoftProjlist[j][0] == project_id){
				var project_incharge = quantsoftProjlist[j][7];
				var project_name = quantsoftProjlist[j][2];
			}
		}//		
		var emp_id = dailyTimeSheetInfo[i][1];
		for(var k=0; k<quantsoftEmplist.length;k++){
			if(quantsoftEmplist[k][0] == emp_id){
				var emp_first_name = quantsoftEmplist[k][1];
				var emp_last_name  = quantsoftEmplist[k][2];
				var emp_id 		   = quantsoftEmplist[k][16];
			}
		}//
		
		if(project_incharge == admin_id){
			
         approveTimesheetsData += ' <tr>\
		      <td>'+dailyTimeSheetInfo[i][2]+'</td>\
              <td>'+emp_first_name+'&nbsp'+emp_last_name+'</td>\
              <td>'+project_name+'</td>';
	approveTimesheetsData += ' <td>'+dailyTimeSheetInfo[i][8]+'h:'+dailyTimeSheetInfo[i][9]+'m</td>';
			  if(dailyTimeSheetInfo[i][12] == '1'){
				  approveTimesheetsData += ' <td class="green_color">Approved</td>';
			  }else if(dailyTimeSheetInfo[i][12] == '2'){
				 approveTimesheetsData += ' <td class="red_color">Disapproved</td>';  
			  }else{
				  approveTimesheetsData += ' <td class="green_color">Yes</td>';
			  }
			  
			  approveTimesheetsData += '<td><a class="calender_icon_link blue_color" onclick="viewtimesheet('+dailyTimeSheetInfo[i][0]+','+dailyTimeSheetInfo[i][1]+','+dailyTimeSheetInfo[i][3]+');" title="View"><i class="fa fa-eye" aria-hidden="true"></i></a></td>\
            </tr>';
		    }
		 }
	$('#timesheet_date').val(logDate);
	$('#viewTimeSheetDataINfo').html(approveTimesheetsData);
}

function allDataSearchByDate(emp_id){
	console.log(empProductivityBySearch);
	var dataTable ='';
	var emp_id = emp_id;
	if(empProductivityBySearch!=''){
		 for(var i=0; i<empProductivityBySearch.length; i++){
				  if(empProductivityBySearch[i][0] == emp_id){
					  var hrs         = parseInt(empProductivityBySearch[i][4]);
					  var min         = parseInt(empProductivityBySearch[i][5]);
					  var proj_no     = '';
					  var proj_name   = '';
					  var proj_totHrs = '';
					  for(var j=0; j<quantsoftProjlist.length; j++){
						  if(quantsoftProjlist[j][0] == empProductivityBySearch[i][3]){
							  proj_no     = quantsoftProjlist[j][1];
							  proj_name   = quantsoftProjlist[j][2];
							  proj_totHrs = quantsoftProjlist[j][4];
						  }
					  }// end j loop
					  
					  if(parseInt(empProductivityBySearch[i][5])>= 60){
						  var new_hrs = parseInt(min/60);
						  hrs = parseInt(hrs) + parseInt(new_hrs);
						  min = parseInt(min) % parseInt(60);
					  }//
					  
					  dataTable +=' <tr>\
					  <td>'+proj_no+'</td>\
					  <td>'+proj_name+'</td>\
					  <td>'+proj_totHrs+'&nbsp;Hrs.</td>\
					  <td>'+hrs+':'+min+'&nbsp;Hrs.</td>\
					  </tr>';
					  
				  }// end main if
			  }//end i loop 
		}else{
			
			dataTable +=' <tr>\
					  <td>No Data..!</td>\
					  <td> </td>\
					  <td> </td>\
					  <td> </td>\
					  </tr>';
					  
		}
	$('#dataBySearch').html(dataTable);		  
}//


function formatAMPM(time) {
     //substring
  var time_R = time;
  var hours  = time_R.substr(0,2);
  
 var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  var minutes = time_R.substr(3,2);
  
 //minutes = minutes < 10 ? '0'+minutes : minutes;
  minutes = minutes < 10 ? minutes : minutes;
  if(hours<10) {
      hours = "0" + hours;
  }
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}