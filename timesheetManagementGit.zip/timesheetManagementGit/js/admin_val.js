var xmlhttp;
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
	xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}


// Define token and version at user site
var adminToken = 'adminquantsoft2015esya';
var adminVersion_007 = 1.00;


var empRegstUrl_007 = 'api_admin_quantsoft_query_007v.php';

var userProfile = [];

var adminProfile = [];

var quantsoftEmplist  = [];

var quantsoftProjlist = [];

var quantsoftCategorylist = [];

var quantsoftSubCategorylist = [];

var quantsoftLeaveTypelist = [];

var quantsoftEmpAppliedLeavelist = [];

var empLogActivityInfo = [];

var dailyTimeSheetInfo = [];

var approvalPenddingTimeSheetInfo = [];

var empProjProductivity = [];

var empProductivityBySearch= [];

var projectProductivity = [];

var empLeaveHistory = [];

var count_sc = 1; // add more row @ sub category initilize to 1

var hrsUtilised = 0; // on analytic page initilize to 0 

var allEmpLeaveHistory = [];

var empMonthlyAttnds = [];

var empMonthlyTimesheet = [];

var quantsoftEmpAttendanceById = [];