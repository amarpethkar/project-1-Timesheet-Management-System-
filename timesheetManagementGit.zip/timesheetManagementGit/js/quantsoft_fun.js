/* Get Leave notification onload admin */
function getLeaveNotiCount(loginId){
	var approve_incharge = loginId;
	var count = '';
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "approve_incharge"      : approve_incharge,
                "METHOD"				: "GET_LEAVE_NOTIFICATION"
            }
        })
        .done(function(data) {
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
				 count = quantsoftResults[3];
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
		
return count;		
}// 

/* Get Time Sheet Approval notification onload */
function getTimShetNotiCount(){
	var count = '';
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_TIMESHEET_NOTIFICATION"
            }
        })
        .done(function(data) {
			
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
				 count = quantsoftResults[3];
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
		
return count;		
}// 

/* Get Time Sheet Disapproval notification Emp onload */
function getTimShetNotiEmpCount(){
	var count = '';
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_TIMESHEET_DISAPRV_NOTIFICATION_EMP"
            }
        })
        .done(function(data) {
			//console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
				 count = quantsoftResults[3];
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
		
return count;		
}// 	


/* Get leave notification Emp onload */
function getLeaveNotiCountEmp(){
	var count = '';
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_LEAVE_NOTIFICATION_EMP"
            }
        })
        .done(function(data) {
			//console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
				 count = quantsoftResults[3];
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
		
return count;		
}// 

// emp leave noti seen 

function updateLeaveNotiEmp(){

		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"METHOD"                : "EMP_NOTI_SEEN"
			}			
			
		})
		.done(function(data){	
		
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				
			}//
		}
	
	})
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
		
}//


/* ONLOG IN GET PROFILE INFO */

// get profile info on logged in 
function getUserProfileInfo(){

	var emp_list    = '';
	var empInfo     = '';
	var userProfile1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_USER_PROFILE"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					emp_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = emp_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             empInfo = emp_list[i].split(/#@#/);
							 userProfile1.push([empInfo[0],empInfo[1],empInfo[2],empInfo[3],empInfo[4],empInfo[5],empInfo[6],empInfo[7],empInfo[8],empInfo[9],empInfo[10],empInfo[11],empInfo[12],empInfo[13],empInfo[14],empInfo[15],empInfo[16],empInfo[17],empInfo[18],empInfo[19],empInfo[20],empInfo[21]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	userProfile = userProfile1;	
} // end get user profile

// get admin profile 
function getAdminInfo(){

	var admin_list    = '';
	var adminInfo     = '';
	var adminProfile1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_ADMIN_PROFILE"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					admin_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = admin_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             adminInfo = admin_list[i].split(/#@#/);
							 adminProfile1.push([adminInfo[0],adminInfo[1],adminInfo[2],adminInfo[3],adminInfo[4],adminInfo[5],adminInfo[6],adminInfo[7]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	adminProfile = adminProfile1;	
} // end get admin profile

// change password 
function changePassword(){
	var old_password 	= $("#old_password").val();
	var new_password 	= $("#new_password").val();
	
	if(old_password!='' && new_password!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"            : adminVersion_007,
                "QUANTSOFTTOKEN"     : adminToken,
				"old_password"		 : old_password,
				"new_password"		 : new_password,
				"METHOD"             : "CHANGE_PASSWORD"
			}			
			
		})		
	.done(function(data){		
		
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){	

			if(quantsoftResult[1] == "SUCCESS"){
				$("#old_password").val('');
				$("#new_password").val('');
				getUserProfileInfo();
				//accountSettings(); // reload page after insertion 
			}if(quantsoftResult[1] == "ERROR"){
				alert('error');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });	
	}else{
		if(old_password!=''){
				$('#old_password').next('label').css('color','#000');
			}else{
				$('#old_password').next('label').css('color','red');
			}
			if(new_password!=''){
				$('#new_password').next('label').css('color','#000');
			}else{
				$('#new_password').next('label').css('color','red');
			}
		
	} // if end
	
}// 

/* DAILY TIMESHEET ENTERY */
// get all log activity 
function getEmpLogActivity(){
	var log_list    = '';
	var logInfo     = '';
	var empLogActivityInfo1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_LOG_ACTIVITY_INFO"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					log_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = log_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             logInfo = log_list[i].split(/#@#/);
							 empLogActivityInfo1.push([logInfo[0],logInfo[1],logInfo[2],logInfo[3],logInfo[4],logInfo[5],logInfo[6],logInfo[7],logInfo[8],logInfo[9],logInfo[10],logInfo[11],logInfo[12],logInfo[13],logInfo[14]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empLogActivityInfo = empLogActivityInfo1;	
}
// get daily timesheet entery 
function getDailyTimesheetInfo(user_date){
	var user_dateR = user_date;
	
	var timesheet_list    = '';
	var timesheetInfo     = '';
	var dailyTimeSheetInfo1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "user_date"        		: user_dateR,
                "METHOD"				: "GET_DAILY_TIMESHEET_INFO"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					timesheet_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = timesheet_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             timesheetInfo = timesheet_list[i].split(/#@#/);
							 dailyTimeSheetInfo1.push([timesheetInfo[0],timesheetInfo[1],timesheetInfo[2],timesheetInfo[3],timesheetInfo[4],timesheetInfo[5],timesheetInfo[6],timesheetInfo[7],timesheetInfo[8],timesheetInfo[9],timesheetInfo[10],timesheetInfo[11],timesheetInfo[12],timesheetInfo[13]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	dailyTimeSheetInfo = dailyTimeSheetInfo1;	
	
} // 

// get approval pendding timesheets 
function getApprovalPenddingTimesheetInfo(){
	var timesheet_list    = '';
	var timesheetInfo     = '';
	var approvalPenddingTimeSheetInfo1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_APPROVAL_PENDDING_TIMESHEETS"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					timesheet_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = timesheet_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             timesheetInfo = timesheet_list[i].split(/#@#/);
							 approvalPenddingTimeSheetInfo1.push([timesheetInfo[0],timesheetInfo[1],timesheetInfo[2],timesheetInfo[3],timesheetInfo[4],timesheetInfo[5],timesheetInfo[6],timesheetInfo[7],timesheetInfo[8],timesheetInfo[9],timesheetInfo[10],timesheetInfo[11],timesheetInfo[12],timesheetInfo[13]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	approvalPenddingTimeSheetInfo = approvalPenddingTimeSheetInfo1;	
	
} // 

// Add daily timesheet 
function addDailyTimesheet(){
	
	var sr_no  					= $("#sr_no").val();
	var timesheet_entry_date  	= $("#timesheet_entry_date").val();
	var project_id			  	= $("#project_id").val();
	var project_category_id	  	= $("#project_category_id").val();
	var project_sub_category_id = $("#project_sub_category_id").val();
	var drawing_no				= $("#drawing_no").val();
	var model_no				= $("#model_no").val();
	var timesheet_hrs			= $("#timesheet_hrs").val();
	var timesheet_min			= $("#timesheet_min").val();
	var timesheet_msg			= $("#timesheet_msg").val();

	if(timesheet_entry_date!='' && project_id!='' && project_category_id!='' && project_sub_category_id!=''  && timesheet_hrs!='' && timesheet_min!=''){

		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               	: adminVersion_007,
                "QUANTSOFTTOKEN"        	: adminToken,
				"sr_no"						: sr_no,
				"timesheet_entry_date"  	: timesheet_entry_date,
				"project_id"	        	: project_id,
				"project_category_id"   	: project_category_id,
				"project_sub_category_id"   : project_sub_category_id,
				"drawing_no" 				: drawing_no,
				"model_no" 			    	: model_no,
				"timesheet_hrs" 	    	: timesheet_hrs,
				"timesheet_min" 	    	: timesheet_min,
				"timesheet_msg" 	    	: timesheet_msg,
				"METHOD"              		: "ADD_EMPLOYEE_DAILY_TIMESHEET"
			}			
			
		})		
	.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#timesheet_entry_date").val('');
				$("#project_id").val('');
				$("#project_category_id").val('');
				$("#project_sub_category_id").val('');
				$("#drawing_no").val('');
				$("#model_no").val('');
				$("#timesheet_hrs").val('');
				$("#timesheet_min").val('');
				$("#timesheet_msg").val('');
				
				getEmpLogActivity();
				weeklyTimesheet(); // reload page after insertion 
				
				$('#msgBox').html('<p>Time-Sheet added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });	
		
	}else{
		if(project_id!=''){
				$('#project_id').prev('span').css('color','#000');
			}else{
				$('#project_id').prev('span').css('color','red');
			}
		if(project_category_id!=''){
				$('#project_category_id').prev('span').css('color','#000');
			}else{
				$('#project_category_id').prev('span').css('color','red');
			}
		if(project_sub_category_id!=''){
				$('#project_sub_category_id').prev('span').css('color','#000');
			}else{
				$('#project_sub_category_id').prev('span').css('color','red');
			}
		if(timesheet_hrs!=''){
				$('#selectTime').prev('span').css('color','#000');
			}else{
				$('#selectTime').prev('span').css('color','red');
			}		
		if(timesheet_min!=''){
				$('#selectTime').prev('span').css('color','#000');
			}else{
				$('#selectTime').prev('span').css('color','red');
			}			
		
	} // if end
	
}//

// add dealy Activity timesheet entry
function addActivityTimesheet(){
	var sr_no  					= $("#sr_no").val();
	var timesheet_entry_date  	= $("#timesheet_entry_date").val();
	var activity_id			  	= $("#activity_id").val();
	var timesheet_hrs			= $("#timesheet_hrs").val();
	var timesheet_min			= $("#timesheet_min").val();
	var timesheet_msg			= $("#timesheet_msg").val();

	if(timesheet_entry_date!='' && activity_id!=''  && timesheet_hrs!='' && timesheet_min!=''){

		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               	: adminVersion_007,
                "QUANTSOFTTOKEN"        	: adminToken,
				"sr_no"						: sr_no,
				"timesheet_entry_date"  	: timesheet_entry_date,
				"activity_id"	        	: activity_id,
				"timesheet_hrs" 	    	: timesheet_hrs,
				"timesheet_min" 	    	: timesheet_min,
				"timesheet_msg" 	    	: timesheet_msg,
				"METHOD"              		: "ADD_EMPLOYEE_DAILY_ACTIVITY_TIMESHEET"
			}			
			
		})		
	.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#timesheet_entry_date").val('');
				$("#activity_id").val('');
				$("#timesheet_hrs").val('');
				$("#timesheet_min").val('');
				$("#timesheet_msg").val('');
				
				getEmpLogActivity();
				weeklyTimesheet(); // reload page after insertion 
				
				$('#msgBox').html('<p>Time-Sheet added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });	
		
	}else{
		if(activity_id!=''){
				$('#activity_id').prev('span').css('color','#000');
			}else{
				$('#activity_id').prev('span').css('color','red');
			}
		if(timesheet_hrs!=''){
				$('#selectTime').prev('span').css('color','#000');
			}else{
				$('#selectTime').prev('span').css('color','red');
			}		
		if(timesheet_min!=''){
				$('#selectTime').prev('span').css('color','#000');
			}else{
				$('#selectTime').prev('span').css('color','red');
			}			
		
	} // if end
	
}//

// edit daily timesheet entery 

// approve daily time sheet
function approveDailyTimSheet(sr_no,logdate){
	var sr_no = sr_no;
	var logdate = $('#timesheet_date').val();
	var admin_msg = $('#admin_msg').val();
	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"sr_no"					: sr_no,
				"admin_msg"				: admin_msg,
                "METHOD"				: "APPROVE_DAILY_TIMESHEET"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){
					getEmpLogActivity();
					$('#msgBox').html('<p>Time-Sheet Approved sucessfully</p>');
				    $('#actionAlertPopup').modal('show');
					setTimeout(function() {
                               // approveTimesheets(); 							   
								$('.modal-backdrop').hide();
								$('#actionAlertPopup').modal('hide');
								$('#viewtimesheet').modal('hide');
								
                            }, 3000);
							alert('hi');
					//timesheetActivityDate(logdate);
					approvalTimesheetsPendding();
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {
			
        });		
  

}//

// disapprove daily time sheet
function disapproveDailyTimSheet(sr_no){
	var sr_no = sr_no;
	var logdate = $('#timesheet_date').val();
	var admin_msg = $('#admin_msg').val();

    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"sr_no"					: sr_no,
				"admin_msg"				: admin_msg,
                "METHOD"				: "DISAPPROVE_DAILY_TIMESHEET"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){	
					getEmpLogActivity();
					$('#msgBox').html('<p>Time-Sheet Disapproved sucessfully</p>');
				    $('#actionAlertPopup').modal('show');
					setTimeout(function() {
                                //approveTimesheets(); 
								$('.modal-backdrop').hide();
								$('#actionAlertPopup').modal('hide');
								$('#viewtimesheet').modal('hide');
                            }, 3000);
					//timesheetActivityDate(logdate);
					approvalTimesheetsPendding();
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
		
}//

// get employee productivity on each project 

function empProjProductivity(){
	
	var prod_list    = '';
	var prodInfo     = '';
	var empProjProductivity1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_PROJ_PRODUCTIVITY"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					prod_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = prod_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             prodInfo = prod_list[i].split(/#@#/);
							 empProjProductivity1.push([prodInfo[0],prodInfo[1],prodInfo[2],prodInfo[3],prodInfo[4],prodInfo[5]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empProjProductivity = empProjProductivity1;	

}// 


function empProjProductivityTest(){
	
	var prod_list    = '';
	var prodInfo     = '';
	var empProjProductivity1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_PROJ_PRODUCTIVITY"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					prod_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = prod_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             prodInfo = prod_list[i].split(/#@#/);
							 empProjProductivity1.push([prodInfo[0],prodInfo[1],prodInfo[2],prodInfo[3],prodInfo[4],prodInfo[5]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empProjProductivity = empProjProductivity1;	

}// 

// get emp productivity by date 

function empProductivityByDate(emp_id){
	
	var emp_id 			= emp_id;
	var emp_from_date  	= $("#emp_from_date").val();
	var emp_to_date  	= $("#emp_to_date").val();
	var search_list    = '';
	var searchInfo     = '';
	//alert(emp_to_date);
	var empProductivityBySearch1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "emp_id"        		: emp_id,
                "emp_from_date"         : emp_from_date,
                "emp_to_date"           : emp_to_date,
                "METHOD"				: "GET_EMP_PRODUCTIVITY_BY_SEARCH"
            }
        })
        .done(function(data) {
console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					search_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = search_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             searchInfo = search_list[i].split(/#@#/);
							 empProductivityBySearch1.push([searchInfo[0],searchInfo[1],searchInfo[2],searchInfo[3],searchInfo[4],searchInfo[5]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empProductivityBySearch = empProductivityBySearch1;	
	allDataSearchByDate(emp_id);
	
}//

// all in all each project productivity
function project_productivity(){
	
	var projProd_list    = '';
	var projProdInfo     = '';
	var projectProductivity1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_PROJECT_PRODUCTIVITY"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					projProd_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = projProd_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             projProdInfo = projProd_list[i].split(/#@#/);
							 projectProductivity1.push([projProdInfo[0],projProdInfo[1],projProdInfo[2]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	projectProductivity = projectProductivity1;	

}// 

/* MY PACKAGE */

// get applied leave details 
function getUserAppliedLeaveInfo(){
	var leave_list    = '';
	var leaveInfo     = '';
	var quantsoftEmpAppliedLeavelist1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_APPLIED_LEAVE_INFO"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					leave_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = leave_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             leaveInfo = leave_list[i].split(/#@#/);
							 quantsoftEmpAppliedLeavelist1.push([leaveInfo[0],leaveInfo[1],leaveInfo[2],leaveInfo[3],leaveInfo[4],leaveInfo[5],leaveInfo[6],leaveInfo[7],leaveInfo[8],leaveInfo[9],leaveInfo[10],leaveInfo[11]]);
						}
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftEmpAppliedLeavelist = quantsoftEmpAppliedLeavelist1;	
} // end get allpied leave details 


// get applied leave details by search date 
function getLeaveBySearchDate(leaveSearchDate){
	
	var leaveSearchDate    = leaveSearchDate;

	var leave_list    = '';
	var leaveInfo     = '';
	var quantsoftEmpAppliedLeavelistByDate1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "leaveSearchDate"        : leaveSearchDate,
                "METHOD"				: "GET_APPLIED_LEAVE_INFO_BYDATE"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					leave_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = leave_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             leaveInfo = leave_list[i].split(/#@#/);
							 quantsoftEmpAppliedLeavelistByDate1.push([leaveInfo[0],leaveInfo[1],leaveInfo[2],leaveInfo[3],leaveInfo[4],leaveInfo[5],leaveInfo[6],leaveInfo[7],leaveInfo[8],leaveInfo[9],leaveInfo[10],leaveInfo[11]]);
						}
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftEmpAppliedLeavelistByDate = quantsoftEmpAppliedLeavelistByDate1;	
} // end get allpied leave details by search date 

// apply leave 

function applyLeave(){
	var no_of_days  	  = $("#no_of_days").val();
	var from_date  		  = $("#from_date").val();
	var to_date  		  = $("#to_date").val();
	var leave_type_id  	  = $("#leave_type_id").val();
	var leave_msg  		  = $("#leave_msg").val();
	var leave_incharge_id = $("#leave_incharge_id").val();
	
	
	if(no_of_days!='' && from_date!='' && to_date!='' && leave_type_id!='' && leave_msg!=''&& leave_incharge_id!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"no_of_days"		    : no_of_days,
				"from_date"		        : from_date,
				"to_date"		        : to_date,
				"leave_type_id"		    : leave_type_id,
				"leave_msg"		        : leave_msg,
				"leave_incharge_id"		: leave_incharge_id,
				"METHOD"                : "APPLY_FOR_LEAVE"
			}			
		})
		.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#no_of_days").val('');
				$("#from_date").val('');
				$("#to_date").val('');
				$("#leave_type_id").val('');
				$("#leave_msg").val('');
				$("#leave_incharge_id").val('');
				
				$('.modal-backdrop').hide();
				myPackage(); // back to my package
				$('#msgBox').html('<p>Your leave has been applied sucessfully.</p>');
				$('#actionAlertPopup').modal('show');
				
			}
		}
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	}else{
		if(no_of_days!=''){
				$('#no_of_days').prev(span).css('color','#000');
			}else{
				$('#no_of_days').prev(span).css('color','red');
			}
		if(from_date!=''){
				$('#from_date').next('label').css('color','#000');
			}else{
				$('#from_date').next('label').css('color','red');
			}
		if(to_date!=''){
				$('#to_date').next('label').css('color','#000');
			}else{
				$('#to_date').next('label').css('color','red');
			}
		if(leave_type_id!=''){
				$('#leave_type_id').next('label').css('color','#000');
			}else{
				$('#leave_type_id').next('label').css('color','red');
			}
		if(leave_incharge_id!=''){
				$('#leave_incharge_id_lable').css('color','#000');
			}else{
				$('#leave_incharge_id_lable').css('color','red');
			}	
		if(leave_msg!=''){
				$('#leave_msg').next('label').css('color','#000');
			}else{
				$('#leave_msg').next('label').css('color','red');
			}	
	
	}// if end 
	
}// function end 

// leave Request Accept
function leaveRequestAccept(leave_id){
	var leave_id = leave_id
	var emp_id   = $("#emp_id").val();


	if(emp_id!='' && leave_id!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"emp_id"		    	: emp_id,
				"leave_id"              : leave_id,
				"METHOD"                : "LEAVE_REQUEST_ACCEPT"
			}			
			
		})
		.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				
				getUserAppliedLeaveInfo();
				leaveApproval();
			}
		}
	
	})
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
	
	}
}//

// Leave Request Reject 

function leaveRequestReject(){
	var emp_id  			= $("#emp_id").val();
	var leave_applied_id  	= $("#leave_applied_id").val();

	if(emp_id!='' && leave_applied_id!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"emp_id"		    	: emp_id,
				"leave_applied_id"      : leave_applied_id,
				"METHOD"                : "LEAVE_REQUEST_REJECT"
			}			
			
		})
		.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				
				getUserAppliedLeaveInfo();
				leaveApproval();
			}
		}
	
	})
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });	
	
	}
}//

//get employee leaves history by id 
function getEmpLeaveHistory(){

	var leave_list    = '';
	var leaveInfo     = '';
	var empLeaveHistory1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_LEAVE_HISTORY"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					leave_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = leave_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             leaveInfo = leave_list[i].split(/#@#/);
							 empLeaveHistory1.push([leaveInfo[0],leaveInfo[1],leaveInfo[2],leaveInfo[3],leaveInfo[4],leaveInfo[5],leaveInfo[6],leaveInfo[7],leaveInfo[8],leaveInfo[9]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empLeaveHistory = empLeaveHistory1;	

} // end get employee leaves history by id


//get all employee leaves history 
function getAllEmpLeaveHistory(){

	var leave_list    = '';
	var leaveInfo     = '';
	var allEmpLeaveHistory1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_ALL_EMP_LEAVE_HISTORY"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					leave_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = leave_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             leaveInfo = leave_list[i].split(/#@#/);
							 allEmpLeaveHistory1.push([leaveInfo[0],leaveInfo[1],leaveInfo[2],leaveInfo[3],leaveInfo[4],leaveInfo[5],leaveInfo[6],leaveInfo[7],leaveInfo[8],leaveInfo[9]]);
						}
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	allEmpLeaveHistory = allEmpLeaveHistory1;	
} // end get all employee leaves history 


// delte applied leave by employee 
function deleteApplyLeave(leave_id){
	var leave_id = leave_id;
	
	if(leave_id!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"leave_id"		    	: leave_id,
				"METHOD"                : "DELETE_APPLIED_LEAVE"
			}			
		})
		.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				getUserAppliedLeaveInfo();				
				leaveHistory();
			}
		}
	})
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {
        });	
	}
	
}//

/* EMPLOYEE DIRECTORY */
// Get emp details 

function get_emp_info_details(){
	var emp_list    = '';
	var empInfo     = '';
	var quantsoftEmplist1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_INFO_DETAILS"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					emp_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = emp_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             empInfo = emp_list[i].split(/#@#/);
							 quantsoftEmplist1.push([empInfo[0],empInfo[1],empInfo[2],empInfo[3],empInfo[4],empInfo[5],empInfo[6],empInfo[7],empInfo[8],empInfo[9],empInfo[10],empInfo[11],empInfo[12],empInfo[13],empInfo[14],empInfo[15],empInfo[16],empInfo[17],empInfo[18],empInfo[19],empInfo[20],empInfo[21],empInfo[22],empInfo[23]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftEmplist = quantsoftEmplist1;	
} // end get emp details 

// add new employee 
function addNewQuantsoftEmp(){

	var emp_first_name  	= $("#emp_first_name").val();
	var emp_last_name   	= $("#emp_last_name").val();
	var emp_gender		 	= $("#emp_gender").val();
	var emp_email_id	 	= $("#emp_email_id").val();
	var emp_mobile_no	 	= $("#emp_mobile_no").val();
	var emp_blood_grp	 	= $("#emp_blood_grp").val();
	var emp_city		 	= $("#emp_city").val();
	var emp_state		 	= $("#emp_state").val();
	var emp_country		 	= $("#emp_country").val();
	var emp_pincode		 	= $("#emp_pincode").val();
	var emp_emges_cont_name = $("#emp_emges_cont_name").val();
	var emp_emges_cont_no	= $("#emp_emges_cont_no").val();
	var emp_start_date		= $("#emp_start_date").val();
	var emp_title			= $("#emp_title").val();
	var emp_team			= $("#emp_team").val();
	var employee_id		    = $("#employee_id").val();
	var emp_intial_password = $("#emp_intial_password").val();
	var access_type			= $("#access_type").val();
	var emp_dob			    = $("#emp_dob").val();
	var emp_id			    = $("#emp_id").val();
	
	
	if(emp_first_name!='' && emp_last_name!='' && emp_gender!='' && emp_email_id!='' && emp_mobile_no!='' && emp_city!='' && emp_state!='' && emp_country!='' && emp_pincode!='' && emp_emges_cont_name!='' && emp_emges_cont_no!='' && emp_start_date!='' && emp_title!='' && emp_team!='' && employee_id!='' && emp_intial_password!='' && access_type!='' && emp_dob!=''){
	
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data: {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"emp_id"		        : emp_id,
				"emp_first_name"		: emp_first_name,
				"emp_last_name"			: emp_last_name,
				"emp_gender"			: emp_gender,
				"emp_email_id"			: emp_email_id,
				"emp_mobile_no"			: emp_mobile_no,
				"emp_blood_grp"			: emp_blood_grp,
				"emp_city"				: emp_city,
				"emp_state"				: emp_state,
				"emp_country"			: emp_country,
				"emp_pincode"			: emp_pincode,
				"emp_emges_cont_name"	: emp_emges_cont_name,
				"emp_emges_cont_no"		: emp_emges_cont_no,
				"emp_start_date"		: emp_start_date,
				"emp_title"				: emp_title,
				"emp_team"				: emp_team,
				"employee_id"			: employee_id,
				"emp_intial_password"	: emp_intial_password,
				"access_type"			: access_type,
				"emp_dob"			    : emp_dob,
				"METHOD"                : "ADD_NEW_QUANTSOFT_EMPLOYEE"
			}			
			
		})		
	.done(function(data){		

		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#emp_first_name").val('');
				$("#emp_last_name").val('');
				$("#emp_gender").val('');
				$("#emp_email_id").val('');
				$("#emp_mobile_no").val('');
				$("#emp_blood_grp").val('');
				$("#emp_city").val('');
				$("#emp_state").val('');
				$("#emp_country").val('');
				$("#emp_pincode").val('');
				$("#emp_emges_cont_name").val('');
				$("#emp_emges_cont_no").val('');
				$("#emp_start_date").val('');
				$("#emp_title").val('');
				$("#emp_team").val('');
				$("#employee_id").val('');
				$("#emp_intial_password").val('');
				$("#access_type").val('');
				$("#emp_dob").val('');
				
				$('#msgBox').html('<p>Employee added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });	
		
	}else{
		if(emp_first_name!=''){
				$('#emp_first_name').next('label').css('color','#000');
			}else{
				$('#emp_first_name').next('label').css('color','red');
			}
		if(emp_last_name!=''){
				$('#emp_last_name').next('label').css('color','#000');
			}else{
				$('#emp_last_name').next('label').css('color','red');
			}
		if(emp_gender!=''){
				$('#emp_gender').prev('span').css('color','#000');
			}else{
				$('#emp_gender').prev('span').css('color','red');
			}
		if(emp_email_id!=''){
				$('#emp_email_id').next('label').css('color','#000');
			}else{
				$('#emp_email_id').next('label').css('color','red');
			}	
		if(emp_mobile_no!=''){
				$('#emp_mobile_no').next('label').css('color','#000');
			}else{
				$('#emp_mobile_no').next('label').css('color','red');
			}	
		if(emp_city!=''){
				$('#emp_city').next('label').css('color','#000');
			}else{
				$('#emp_city').next('label').css('color','red');
			}	
		if(emp_state!=''){
				$('#emp_state').next('label').css('color','#000');
			}else{
				$('#emp_state').next('label').css('color','red');
			}	
		if(emp_country!=''){
				$('#emp_country').prev('span').css('color','#000');
			}else{
				$('#emp_country').prev('span').css('color','red');
			}
		if(emp_pincode!=''){
				$('#emp_pincode').next('label').css('color','#000');
			}else{
				$('#emp_pincode').next('label').css('color','red');
			}	
		if(emp_emges_cont_name!=''){
				$('#emp_emges_cont_name').next('label').css('color','#000');
			}else{
				$('#emp_emges_cont_name').next('label').css('color','red');
			}	
		if(emp_emges_cont_no!=''){
				$('#emp_emges_cont_no').next('label').css('color','#000');
			}else{
				$('#emp_emges_cont_no').next('label').css('color','red');
			}
		if(emp_start_date!=''){
				$('#emp_start_date').prev('span').css('color','#000');
			}else{
				$('#emp_start_date').prev('span').css('color','red');
			}
		if(emp_title!=''){
				$('#emp_title').prev('span').css('color','#000');
			}else{
				$('#emp_title').prev('span').css('color','red');
			}
		if(emp_team!=''){
				$('#emp_team').prev('span').css('color','#000');
			}else{
				$('#emp_team').prev('span').css('color','red');
			}
		if(employee_id!=''){
				$('#employee_id').next('label').css('color','#000');
			}else{
				$('#employee_id').next('label').css('color','red');
			}
		if(emp_emges_cont_no!=''){
				$('#emp_intial_password').next('label').css('color','#000');
			}else{
				$('#emp_intial_password').next('label').css('color','red');
			}	
		if(access_type!=''){
				$('#access_type').prev('span').css('color','#000');
			}else{
				$('#access_type').prev('span').css('color','red');
			}	
		if(emp_dob!=''){
				$('#emp_dob').prev('span').css('color','#000');
			}else{
				$('#emp_dob').prev('span').css('color','red');
			}	
	} // if end 
	get_emp_info_details();
	if(emp_id!=''){
		employeeDirectory();
			$('#msgBox').html('<p>Employee added sucessfully</p>');
			$('#actionAlertPopup').modal('show');
	}
	
} // add and edit function end 

function delete_emp_info_details(emp_id){	
	
	var emp_id = emp_id;
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"emp_id"		        : emp_id,
                "METHOD"				: "DELETE_EMP_INFO_DETAILS"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){	
						$('.modal-backdrop').hide();
						$('#terminate_confirm').hide();
						$('#terminate_confirm').html('');
						get_emp_info_details();	// get back all emp after deletion 					
						employeeDirectory();    // show updated emp directory 
						
						$('#msgBox').html('<p>Employee Terminited sucessfully</p>');
						$('#actionAlertPopup').modal('show');
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	
} // end delete function 


/* EMPLOYEE DIRECTORY */
// get Quantsoft Project Details 

function get_project_info_details(){
	var proj_list    = '';
	var projInfo     = '';
	var quantsoftProjlist1 = [];	
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_PROJ_INFO_DETAILS"
            }
        })
        .done(function(data) {		 
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					proj_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = proj_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             projInfo = proj_list[i].split(/#@#/);							 
							 quantsoftProjlist1.push([projInfo[0],projInfo[1],projInfo[2],projInfo[3],projInfo[4],projInfo[5],projInfo[6],projInfo[7],projInfo[8],projInfo[9]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftProjlist = quantsoftProjlist1;	
} // end get Project details 

// Add Quantsoft Project 

function addQuantsoftProject(){
	var project_no  		 = $("#project_no").val();
	var project_name  		 = $("#project_name").val();
	var project_start_date 	 = $("#project_start_date").val();
	var project_allcated_hrs = $("#project_allcated_hrs").val();
	var project_incharge     = $("#project_incharge").val();
	var project_id			 = $("#project_id").val();

	
	if(project_no!='' && project_name!=''&& project_start_date!=''&& project_start_date!=''&& project_allcated_hrs!='' && project_incharge!=''){
		
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"project_id"		    : project_id,
				"project_no"		    : project_no,
				"project_name"		    : project_name,
				"project_start_date"	: project_start_date,
				"project_allcated_hrs"	: project_allcated_hrs,			
				"project_incharge"	    : project_incharge,			
				"METHOD"                : "ADD_NEW_QUANTSOFT_PROJECT"
				
			}
			
		})
	.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#project_no").val('');
				$("#project_name").val('');
				$("#project_start_date").val('');
				$("#project_allcated_hrs").val('');
				$("#project_incharge").val('');
				$("#project_id").val('');
				$('#msgBox').html('<p>Project added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				
				get_project_info_details();
				projectDirectory();
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	}else{
		if(project_no!=''){
				$('#project_no_lable').css('color','#000');
			}else{
				$('#project_no_lable').css('color','red');
			}
		if(project_name!=''){
				$('#project_name').next('label').css('color','#000');
			}else{
				$('#project_name').next('label').css('color','red');
			}
		if(project_start_date!=''){
				$('#project_start_date_label').css('color','#000');
			}else{
				$('#project_start_date_label').css('color','red');
			}
		if(project_allcated_hrs!=''){
				$('#project_allcated_hrs').next('label').css('color','#000');
			}else{
				$('#project_allcated_hrs').next('label').css('color','red');
			}	
		if(project_incharge!=''){
				$('#project_incharge').prev('span').css('color','#000');
			}else{
				$('#project_incharge').prev('span').css('color','red');
			}	
	
	} // if end 
	
	get_project_info_details();
	if(project_id!=''){
		projectDirectory();
				$('#msgBox').html('<p>Project added sucessfully</p>');
				$('#actionAlertPopup').modal('show');		
	}
	
} // function end 

// active project 
function activeProject(project_id){
	var project_id = project_id;
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"project_id"			: project_id,
                "METHOD"				: "ACTIVE_PROJECT"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					
					get_project_info_details();
					projectDirectory();
					
					$('#msgBox').html('<p>Project Activated sucessfully</p>');
				    $('#actionAlertPopup').modal('show');
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	
}//

// deactive project 
function deactiveProject(project_id){
	var project_id = project_id;
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"project_id"			: project_id,
                "METHOD"				: "DEACTIVE_PROJECT"
            }
        })
        .done(function(data) {
	
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
						
					get_project_info_details();
					projectDirectory();
					
				$('#msgBox').html('<p>Project Deactivated sucessfully</p>');
				$('#actionAlertPopup').modal('show');
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	
}//

/* Category */

// get Category Info

function get_category_info(){
	var category_list    = '';
	var categoryInfo     = '';
	var quantsoftCategorylist1 = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_CATEGORY_INFO"
            }
        })
        .done(function(data) {	
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					category_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = category_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             categoryInfo = category_list[i].split(/#@#/);							 
							 quantsoftCategorylist1.push([categoryInfo[0],categoryInfo[1],categoryInfo[2]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftCategorylist = quantsoftCategorylist1;	
} // end get category type details 

//add category

function addNewCategory(){
	
	var category_name  = $("#category_name").val();
	
	if(category_name!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"category_name"		    : category_name,
				"METHOD"                : "ADD_NEW_CATEGORY"
			}
			
		})
		.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
	
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#category_name").val('');
				
				$('.modal-backdrop').hide();
				$('#addcategory').hide();
				$('#addcategory').html('');
				get_category_info();	// get back all category after new addition  					
			 	settings();    // show updated category directory 
				
				$('#msgBox').html('<p>New Category added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	}else{
		if(category_name!=''){
				$('#category_name').next('label').css('color','#000');
			}else{
				$('#category_name').next('label').css('color','red');
			}
			
		
	}// if end 
	
} // 

// edit category 
function editCategory(cat_id){
	var cat_id = cat_id;
	var category_name = $("#category_name").val();
	
	if(cat_id!='' && category_name!=''){
		
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"cat_id"			    : cat_id,
				"category_name"     	: category_name,
				"METHOD"                : "EDIT_CATEGORY"
			}
		})
		.done(function(data){	
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#category_name").val('');
				get_category_info();
				categoryList();// reload page after successful insertion 
				$('#msgBox').html('<p>Category edited sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				$('.modal-backdrop').hide();
			}
		}
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {
    });
	}else{
		if(category_name!=''){
				$('#category_name').prev('span').css('color','#000');
			}else{
				$('#category_name').prev('span').css('color','red');
			}
	}// if end 
	
}//

// delete category
function delete_category_type(cat_id){
	var cat_id = cat_id;
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"cat_id"			    : cat_id,
                "METHOD"				: "REMOVE_CATEGORY"
            }
        })
        .done(function(data) {
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){	
				get_category_info();
				categoryList();
				$('#msgBox').html('<p>Category and all Sub Category Removed sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				$('.modal-backdrop').hide();
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {
        });	
	
}//

// edit sub category 
function editSubCategory(sub_cat_id){
	var sub_cat_id = sub_cat_id;
	var sub_category_name = $("#sub_category_name").val();
	
	if(sub_cat_id!='' && sub_category_name!=''){
		
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"sub_cat_id"		    : sub_cat_id,
				"sub_category_name"     : sub_category_name,
				"METHOD"                : "EDIT_SUB_CATEGORY"
			}
		})
		.done(function(data){	
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#category_name").val('');
				get_category_info();
				categoryList();// reload page after successful insertion 
				$('#msgBox').html('<p>Sub-Category edited sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				$('.modal-backdrop').hide();
			}
		}
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {
    });
	}else{
		if(category_name!=''){
				$('#category_name').prev('span').css('color','#000');
			}else{
				$('#category_name').prev('span').css('color','red');
			}
	}// if end 
	
}//

// delete sub category
function delete_sub_category_type(sub_cat_id){
	var sub_cat_id = sub_cat_id;
	$.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"sub_cat_id"			: sub_cat_id,
                "METHOD"				: "REMOVE_SUB_CATEGORY"
            }
        })
        .done(function(data) {
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){	
				get_category_info();
				categoryList();
				$('#msgBox').html('<p>Sub Category Removed sucessfully</p>');
				$('#actionAlertPopup').modal('show');
				$('.modal-backdrop').hide();
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {
        });	
}//

/* Sub Category */

// get sub Category Info
function get_sub_category_info(){
	var sub_category_list      = '';
	var subCategoryInfo        = '';
	var quantsoftSubCategorylist1 = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_SUB_CATEGORY_INFO"
            }
        })
        .done(function(data) {	
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					sub_category_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = sub_category_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             subCategoryInfo = sub_category_list[i].split(/#@#/);							 
							 quantsoftSubCategorylist1.push([subCategoryInfo[0],subCategoryInfo[1],subCategoryInfo[2]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftSubCategorylist = quantsoftSubCategorylist1;	
} // end get sub category details 


// add sub category 

function addSubCategoryRow(){
	
	var category_id           = $("#category_id").val();
	var count_sc              = $("#count_sc").val();
	var sub_category_name     = '';
	var sub_category_nameSTR  = '';
	
	for(var i=0; i <count_sc; i++){
		sub_category_name  = $("#sub_category_name"+i).val();
		
		if(sub_category_name!='' && typeof sub_category_name!=="undefined"){
			sub_category_nameSTR = sub_category_nameSTR+sub_category_name+'@@@@';
			$('#sub_category_name'+i).next('label').css('color','#b5b5b5');
		}else{			
			$('#sub_category_name'+i).next('label').css('color','red');
		}
		
	}// end for loop 
	
	
	if(category_id!='' && sub_category_nameSTR!=''){
		
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"category_id"			: category_id,
				"sub_category_nameSTR"	: sub_category_nameSTR,
				"METHOD"                : "ADD_NEW_SUB_CATEGORY"
				
			}
			
		})
		.done(function(data){	
	
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
		
		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#category_id").val('');
				$("#sub_category_name").val('');
				
				settings();// reload page after successful insertion 
				$('#msgBox').html('<p>New Sub-Category added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	
	}else{
		if(category_id!=''){
				$('#category_id').prev('span').css('color','#000');
			}else{
				$('#category_id').prev('span').css('color','red');
			}
		
	}// if end 
	
}// function end 

/* TYPE OF LEAVE */

// get leave type details

function get_leave_type_info(){
	var leave_list    = '';
	var leaveInfo     = '';
	var quantsoftLeaveTypelist1 = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_LEAVE_TYPE_INFO"
            }
        })
        .done(function(data) {		 
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					leave_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = leave_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             leaveInfo = leave_list[i].split(/#@#/);							 
							 quantsoftLeaveTypelist1.push([leaveInfo[0],leaveInfo[1],leaveInfo[2],leaveInfo[3]]);
						}
						
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftLeaveTypelist = quantsoftLeaveTypelist1;	
} // end get leave type details 

// add leave type 

function addLeaveType(){
	var leave_type_name  = $("#leave_type_name").val();
	var no_of_days  = $("#no_of_days").val();
	
	if(leave_type_name!='' && no_of_days!=''){
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"leave_type_name"		: leave_type_name,
				"no_of_days"			: no_of_days,
				"METHOD"                : "ADD_NEW_LEAVE_TYPE"
			}
			
		})
		.done(function(data){			
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);

		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#leave_type_name").val('');
				
				$('.modal-backdrop').hide();
				$('#addLeave').hide();
				$('#addLeave').html('');
				get_leave_type_info();	// get back all leave types after new addition  					
				leaveTypes();    // show updated leave directory 
				
				$('#msgBox').html('<p> Leave type added sucessfully</p>');
				$('#actionAlertPopup').modal('show');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	}else{
		if(leave_type_name!=''){
				$('#leave_type_name').next('label').css('color','#000');
			}else{
				$('#leave_type_name').next('label').css('color','red');
			}
			
	}// if end
}// function end 

// delete leave type 
function delete_leave_type(leave_id){	
	
	var leave_id = leave_id;
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"leave_id"		        : leave_id,
                "METHOD"				: "DELETE_LEAVE_TYPE"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);
			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){	
						$('.modal-backdrop').hide();
						$('#terminate_confirm_settings').hide();
						$('#terminate_confirm_settings').html('');
						get_leave_type_info();	// get back all leave types after deletion 					
						leaveTypes();    // show updated leave directory 
						
						$('#msgBox').html('<p> Leave type removed sucessfully</p>');
						$('#actionAlertPopup').modal('show');
					
                } // SUCCESS
            }
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	
} // end delete function 

// assign leaves to employee 
function assignLeaveToEmp(){
	var leave_emp_id = $("#leave_emp_id").val();
	var leave_id     = $("#leave_id").val();
	var no_of_days   = $("#no_of_days").val();

		if(leave_emp_id!='' && leave_id!=''&& no_of_days!=''){
		
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"leave_emp_id"		    : leave_emp_id,
				"leave_id"		     	: leave_id,
				"no_of_days"		    : no_of_days,
				"METHOD"                : "ASSIGN_LEAVE_DAYS_TO_EMP"
			}
		})
		.done(function(data){	
			console.log(data);
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);

		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#leave_id").val('');
				$("#no_of_days").val('');
				
				$('.modal-backdrop').hide();
				$('#addLeave').hide();
				$('#addLeave').html('');
				//get_leave_type_info();	// get back all leave types after new addition  					
				assignLeave();    // show updated leave directory 
				
				$('#msgBox').html('<p> Leaves assigned sucessfully!</p>');
				$('#actionAlertPopup').modal('show');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	}else{
		if(leave_id!=''){
				$('#leave_id').next('label').css('color','#000');
			}else{
				$('#leave_id').next('label').css('color','red');
			}
		if(no_of_days!=''){
				$('#no_of_days').next('label').css('color','#000');
			}else{
				$('#no_of_days').next('label').css('color','red');
			}
			
	}// if end
}//

// get emp's leave quota 
function getEmpLeavesQuota(){

	var leaveQuota_list    = '';
	var leaveQuotaInfo       = '';
	var quantsoftEmpleaveQuota1 = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_LEAVE_QUOTA"
            }
        })
        .done(function(data) {	
			//console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					leaveQuota_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = leaveQuota_list.length-1;
					for (var i = 0; i<totalDR; i++) {
                             leaveQuotaInfo = leaveQuota_list[i].split(/#@#/);
							 quantsoftEmpleaveQuota1.push([leaveQuotaInfo[0],leaveQuotaInfo[1],leaveQuotaInfo[2],leaveQuotaInfo[3]]);
						}
                } // SUCCESS
            }
			
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {
        });		
	quantsoftEmpleaveQuota = quantsoftEmpleaveQuota1;
}//

// add manual attendance by admin 
function addManualAttendance(){
	var punching_code = $("#punching_code").val();
	var log_date      = $("#log_date").val();
	var log_time      = $("#log_time").val();

		if(punching_code!='' && log_date!=''&& log_time!=''){
		
		$.ajax({
			type: "POST",
			url: empRegstUrl_007,
			async: false,
			data  : {
				"VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
				"punching_code"		    : punching_code,
				"log_date"		     	: log_date,
				"log_time"		        : log_time,
				"METHOD"                : "ADD_MANUAL_ATTENDANCE"
			}
		})
		.done(function(data){	
			console.log(data);
		var quantsoftResult =  data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);

		if(quantsoftResult){			
			if(quantsoftResult[1] == "SUCCESS"){
				$("#punching_code").val('');
				$("#log_date").val('');
				$("#log_time").val('');
				
				$('#msgBox').html('<p> Attendance added sucessfully!</p>');
				$('#actionAlertPopup').modal('show');
			}
		}
	
	})
	.fail(function(data) {
		window.location.href='index.php?status=4';
    })
    .always(function() {

    });
	}else{
		if(punching_code!=''){
				$('#punching_code').next('label').css('color','#000');
			}else{
				$('#punching_code').next('label').css('color','red');
			}
		if(log_date!=''){
				$('#log_date').prev('span').css('color','#000');
			}else{
				$('#log_date').prev('span').css('color','red');
			}
		if(log_time!=''){
				$('#log_time').prev('span').css('color','#000');
			}else{
				$('#log_time').prev('span').css('color','red');
			}
			
	}// if end
}//


// get emp attendance by date 
function getEmpAttendance(attendance_date){
	var attendance_date    = attendance_date;
	//alert(attendance_date);
	var attendance_list    = '';
	var attendanceInfo     = '';
	var quantsoftEmpAttendance1 = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "attendance_date"       : attendance_date,
                "METHOD"				: "GET_EMP_ATTENDANCE"
            }
        })
        .done(function(data) {	
			//console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					attendance_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = attendance_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             attendanceInfo = attendance_list[i].split(/#@#/);
							 quantsoftEmpAttendance1.push([attendanceInfo[0],attendanceInfo[1],attendanceInfo[2],attendanceInfo[3],attendanceInfo[4]]);
						}
                } // SUCCESS
            }
			
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftEmpAttendance = quantsoftEmpAttendance1;	
	viewSelecetedDateAttendence();
}//

// get emp attendance by id
function getEmpAttendanceByIdAjax(){

	var attendance_list    = '';
	var attendanceInfo     = '';
	var quantsoftEmpAttendanceById1 = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"               : adminVersion_007,
                "QUANTSOFTTOKEN"        : adminToken,
                "METHOD"				: "GET_EMP_ATTENDANCE_BY_ID"
            }
        })
        .done(function(data) {	
			//console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					attendance_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = attendance_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             attendanceInfo = attendance_list[i].split(/#@#/);
							 quantsoftEmpAttendanceById1.push([attendanceInfo[0],attendanceInfo[1],attendanceInfo[2],attendanceInfo[3],attendanceInfo[4]]);
						}
                } // SUCCESS
            }
			
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	quantsoftEmpAttendanceById = quantsoftEmpAttendanceById1;	

}//


// get monthly attendance by emp id and month 
function viewMonthlyEmpAttendance(){
	var emp_id              = $("#emp_id").val();
	var attendance_month    = $("#attendance_month").val();
	// required split and substring
	var res 				= attendance_month.split("-");
	var punching_code 		= emp_id.substring(7);
    var attendance_year 	= res[0];
    var attendance_month 	= res[1];
	//
	var monthly_attnds_list = '';
	var monthlyAttndsInfo   = '';
	var empMonthlyAttnds1   = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"          : adminVersion_007,
                "QUANTSOFTTOKEN"   : adminToken,
                "punching_code"	   : punching_code,
                "attendance_year"  : attendance_year,
                "attendance_month" : attendance_month,
                "METHOD"		   : "GET_EMP_MONTHLY_ATTENDANCE"
            }
        })
        .done(function(data) {	
			console.log(data);
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					monthly_attnds_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = monthly_attnds_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             monthlyAttndsInfo = monthly_attnds_list[i].split(/#@#/);
							 empMonthlyAttnds1.push([monthlyAttndsInfo[0],monthlyAttndsInfo[1],monthlyAttndsInfo[2],monthlyAttndsInfo[3],monthlyAttndsInfo[4]]);
						}
                } // SUCCESS
            }
			
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empMonthlyAttnds = empMonthlyAttnds1;
	monthlyAttendanceView(emp_id);
}//

// get emp timesheet by id, year, and month
function viewMonthlyEmpTimesheet(emp_id){
	var emp_id         = emp_id;
	var report_date    = $("#report_date").val();
	
	// required split and substring
	var res 				= report_date.split("-");
    var timesheet_year 	= res[0];
    var timesheet_month 	= res[1];
	//
	var monthly_attnds_list = '';
	var monthlyAttndsInfo   = '';
	var empMonthlyTimesheet1   = [];
    $.ajax({
            type: "POST",
            url: empRegstUrl_007,
			async: false,
            data: {
                "VERSION"          : adminVersion_007,
                "QUANTSOFTTOKEN"   : adminToken,
                "emp_id"		   : emp_id,
                "timesheet_year"   : timesheet_year,
                "timesheet_month"  : timesheet_month,
                "METHOD"		   : "GET_EMP_MONTHLY_TIMESHEET"
            }
        })
        .done(function(data) {
		
            var quantsoftResults = data.match(/RESULT=(\w+)&REQUEST=(\w+)&RESPONSE=(.+)/);			
            if (quantsoftResults){
                if (quantsoftResults[1] == "SUCCESS"){				
					monthly_attnds_list = quantsoftResults[3].split(/@@@@/);
					 var totalDR = monthly_attnds_list.length-1;
					for (var i = 0; i < totalDR; i++) {
                             monthlyAttndsInfo = monthly_attnds_list[i].split(/#@#/);
							 empMonthlyTimesheet1.push([monthlyAttndsInfo[0],monthlyAttndsInfo[1],monthlyAttndsInfo[2],monthlyAttndsInfo[3],monthlyAttndsInfo[4],monthlyAttndsInfo[5],monthlyAttndsInfo[6],monthlyAttndsInfo[7],monthlyAttndsInfo[8],monthlyAttndsInfo[9],monthlyAttndsInfo[10],monthlyAttndsInfo[11],monthlyAttndsInfo[12],monthlyAttndsInfo[13],monthlyAttndsInfo[14]]);
						}
                } // SUCCESS
            }
			
        })
        .fail(function(data) {
			window.location.href='index.php?status=4';
        })
        .always(function() {

        });		
	empMonthlyTimesheet = empMonthlyTimesheet1;
	reportDataBymonth();
}//