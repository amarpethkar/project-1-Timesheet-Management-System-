<?php
//Start session
include_once('classes/session_query.php');
$session = new dbSession();
$session_id = session_id();
$data = $session->read($session_id);
//session_start();

$user_type = $_SESSION['SESS_USER_TYPE'];
$user_access_type = $_SESSION['SESS_USER_ACCESS_TYPE'];
$name = $_SESSION['SESS_USER_NAME'];
$id = $_SESSION['SESS_USER_ID'];
$username = $_SESSION['SESS_USER_EMAIL'];  // if its admin than un=email and if it is emp than un=emp_id
$last_logged_time =	$_SESSION['SESS_DATE'];

include_once('classes/query_class.php');
$qc = new queryClass();


//Check whether the session variable SESS_MEMBER_ID is present or not
if(!isset($id) || (trim($username))=='') {
header("location: index.php?status=3");
exit();
}
?>